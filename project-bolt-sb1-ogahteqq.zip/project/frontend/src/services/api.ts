import axios from 'axios';

// API Configuration
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('authToken');
      localStorage.removeItem('currentUser');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// API Response Types
interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  errors?: any[];
}

interface PaginatedResponse<T> {
  success: boolean;
  data: {
    [key: string]: T[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  };
}

// Authentication API
export const authAPI = {
  login: async (username: string, password: string): Promise<ApiResponse> => {
    const response = await api.post('/auth/login', { username, password });
    return response.data;
  },

  getProfile: async (): Promise<ApiResponse> => {
    const response = await api.get('/auth/profile');
    return response.data;
  },

  changePassword: async (currentPassword: string, newPassword: string): Promise<ApiResponse> => {
    const response = await api.put('/auth/change-password', {
      currentPassword,
      newPassword,
    });
    return response.data;
  },
};

// Students API
export const studentsAPI = {
  getAll: async (params?: {
    page?: number;
    limit?: number;
    search?: string;
    department_id?: string;
  }): Promise<PaginatedResponse<any>> => {
    const response = await api.get('/students', { params });
    return response.data;
  },

  getById: async (id: number): Promise<ApiResponse> => {
    const response = await api.get(`/students/${id}`);
    return response.data;
  },

  create: async (studentData: any): Promise<ApiResponse> => {
    const response = await api.post('/students', studentData);
    return response.data;
  },

  update: async (id: number, studentData: any): Promise<ApiResponse> => {
    const response = await api.put(`/students/${id}`, studentData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/students/${id}`);
    return response.data;
  },

  getAcademicData: async (studentId: number): Promise<ApiResponse> => {
    const response = await api.get(`/students/${studentId}/academic-data`);
    return response.data;
  },
};

// Teachers API
export const teachersAPI = {
  getAll: async (params?: {
    page?: number;
    limit?: number;
    search?: string;
    department_id?: string;
  }): Promise<PaginatedResponse<any>> => {
    const response = await api.get('/teachers', { params });
    return response.data;
  },

  getById: async (id: number): Promise<ApiResponse> => {
    const response = await api.get(`/teachers/${id}`);
    return response.data;
  },

  create: async (teacherData: any): Promise<ApiResponse> => {
    const response = await api.post('/teachers', teacherData);
    return response.data;
  },

  update: async (id: number, teacherData: any): Promise<ApiResponse> => {
    const response = await api.put(`/teachers/${id}`, teacherData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/teachers/${id}`);
    return response.data;
  },
};

// Departments API
export const departmentsAPI = {
  getAll: async (): Promise<ApiResponse> => {
    const response = await api.get('/departments');
    return response.data;
  },

  getById: async (id: number): Promise<ApiResponse> => {
    const response = await api.get(`/departments/${id}`);
    return response.data;
  },

  create: async (departmentData: any): Promise<ApiResponse> => {
    const response = await api.post('/departments', departmentData);
    return response.data;
  },

  update: async (id: number, departmentData: any): Promise<ApiResponse> => {
    const response = await api.put(`/departments/${id}`, departmentData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/departments/${id}`);
    return response.data;
  },
};

// Classrooms API
export const classroomsAPI = {
  getAll: async (params?: { department_id?: string }): Promise<ApiResponse> => {
    const response = await api.get('/classrooms', { params });
    return response.data;
  },

  getById: async (id: number): Promise<ApiResponse> => {
    const response = await api.get(`/classrooms/${id}`);
    return response.data;
  },

  create: async (classroomData: any): Promise<ApiResponse> => {
    const response = await api.post('/classrooms', classroomData);
    return response.data;
  },

  update: async (id: number, classroomData: any): Promise<ApiResponse> => {
    const response = await api.put(`/classrooms/${id}`, classroomData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/classrooms/${id}`);
    return response.data;
  },
};

// Subjects API
export const subjectsAPI = {
  getAll: async (params?: { department_id?: string }): Promise<ApiResponse> => {
    const response = await api.get('/subjects', { params });
    return response.data;
  },

  getById: async (id: number): Promise<ApiResponse> => {
    const response = await api.get(`/subjects/${id}`);
    return response.data;
  },

  create: async (subjectData: any): Promise<ApiResponse> => {
    const response = await api.post('/subjects', subjectData);
    return response.data;
  },

  update: async (id: number, subjectData: any): Promise<ApiResponse> => {
    const response = await api.put(`/subjects/${id}`, subjectData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/subjects/${id}`);
    return response.data;
  },
};

// Schedule API
export const scheduleAPI = {
  getAll: async (params?: { day_of_week?: string; teacher_id?: string }): Promise<ApiResponse> => {
    const response = await api.get('/schedule', { params });
    return response.data;
  },

  getById: async (id: number): Promise<ApiResponse> => {
    const response = await api.get(`/schedule/${id}`);
    return response.data;
  },

  create: async (scheduleData: any): Promise<ApiResponse> => {
    const response = await api.post('/schedule', scheduleData);
    return response.data;
  },

  update: async (id: number, scheduleData: any): Promise<ApiResponse> => {
    const response = await api.put(`/schedule/${id}`, scheduleData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/schedule/${id}`);
    return response.data;
  },
};

// Enrollment API
export const enrollmentAPI = {
  getAll: async (params?: { student_id?: string; subject_id?: string }): Promise<ApiResponse> => {
    const response = await api.get('/enrollment', { params });
    return response.data;
  },

  create: async (enrollmentData: any): Promise<ApiResponse> => {
    const response = await api.post('/enrollment', enrollmentData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/enrollment/${id}`);
    return response.data;
  },
};

// Attendance API
export const attendanceAPI = {
  getAll: async (params?: {
    student_id?: string;
    subject_id?: string;
    date?: string;
    status?: string;
  }): Promise<ApiResponse> => {
    const response = await api.get('/attendance', { params });
    return response.data;
  },

  getById: async (id: number): Promise<ApiResponse> => {
    const response = await api.get(`/attendance/${id}`);
    return response.data;
  },

  create: async (attendanceData: any): Promise<ApiResponse> => {
    const response = await api.post('/attendance', attendanceData);
    return response.data;
  },

  update: async (id: number, attendanceData: any): Promise<ApiResponse> => {
    const response = await api.put(`/attendance/${id}`, attendanceData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/attendance/${id}`);
    return response.data;
  },
};

// Grades API
export const gradesAPI = {
  getAll: async (params?: {
    student_id?: string;
    subject_id?: string;
    grade_type?: string;
  }): Promise<ApiResponse> => {
    const response = await api.get('/grades', { params });
    return response.data;
  },

  getById: async (id: number): Promise<ApiResponse> => {
    const response = await api.get(`/grades/${id}`);
    return response.data;
  },

  create: async (gradeData: any): Promise<ApiResponse> => {
    const response = await api.post('/grades', gradeData);
    return response.data;
  },

  update: async (id: number, gradeData: any): Promise<ApiResponse> => {
    const response = await api.put(`/grades/${id}`, gradeData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/grades/${id}`);
    return response.data;
  },
};

// Fees API
export const feesAPI = {
  getAll: async (params?: {
    student_id?: string;
    status?: string;
    fee_type?: string;
  }): Promise<ApiResponse> => {
    const response = await api.get('/fees', { params });
    return response.data;
  },

  getById: async (id: number): Promise<ApiResponse> => {
    const response = await api.get(`/fees/${id}`);
    return response.data;
  },

  create: async (feeData: any): Promise<ApiResponse> => {
    const response = await api.post('/fees', feeData);
    return response.data;
  },

  update: async (id: number, feeData: any): Promise<ApiResponse> => {
    const response = await api.put(`/fees/${id}`, feeData);
    return response.data;
  },

  delete: async (id: number): Promise<ApiResponse> => {
    const response = await api.delete(`/fees/${id}`);
    return response.data;
  },
};

// Generations API
export const generationsAPI = {
  getAll: async (): Promise<ApiResponse> => {
    const response = await api.get('/generations');
    return response.data;
  },
};

// Export default api instance for custom requests
export default api;