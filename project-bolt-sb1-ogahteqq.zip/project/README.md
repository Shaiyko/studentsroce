# School Management System

A comprehensive full-stack School Management System with role-based access control, built with React + TypeScript frontend and Node.js + MySQL backend.

## 🌟 Features

### Frontend (React + TypeScript + Material UI)
- **Role-Based Authentication**: Admin and Student portals with different access levels
- **Admin Dashboard**: Complete CRUD operations for all entities
- **Student Portal**: Personal academic information view
- **Responsive Design**: Mobile-first approach with Material UI
- **Real-time Data**: Live updates and statistics
- **Professional UI**: Modern design with smooth animations

### Backend (Node.js + Express + MySQL)
- **RESTful API**: Complete REST API with proper HTTP methods
- **JWT Authentication**: Secure token-based authentication
- **Role-Based Access Control**: Admin, Student, and Teacher roles
- **Data Validation**: Comprehensive input validation
- **Database Transactions**: Atomic operations for data consistency
- **Security Features**: Rate limiting, CORS, password hashing

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- MySQL (v8.0 or higher)
- npm or yarn

### Backend Setup

1. **Navigate to backend directory**
   ```bash
   cd backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment configuration**
   ```bash
   cp .env.example .env
   ```
   
   Update `.env` with your MySQL credentials:
   ```env
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=your_password
   DB_NAME=school_management
   JWT_SECRET=your_super_secret_jwt_key_here
   ```

4. **Database setup**
   ```bash
   npm run migrate
   ```

5. **Start backend server**
   ```bash
   npm run dev
   ```
   
   Backend will run on `http://localhost:5000`

### Frontend Setup

1. **Navigate to frontend directory**
   ```bash
   cd frontend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment configuration**
   ```bash
   cp .env.example .env
   ```
   
   Update `.env`:
   ```env
   VITE_API_URL=http://localhost:5000/api
   ```

4. **Start frontend development server**
   ```bash
   npm run dev
   ```
   
   Frontend will run on `http://localhost:5173`

## 🔐 Demo Accounts

### Admin Access
- **Username**: `admin`
- **Password**: `password`
- **Features**: Full CRUD access to all entities

### Student Access
- **Username**: `john.doe`
- **Password**: `password`
- **Features**: View personal academic information

### Teacher Access
- **Username**: `dr.wilson`
- **Password**: `password`
- **Features**: Teacher-specific functionality

## 📊 System Architecture

### Database Schema
```
Users ──┐
        ├── Students ──┬── Enrollment ──── Subjects
        └── Teachers   ├── Attendance
                       ├── Grades
                       └── Fees

Departments ──┬── Classrooms
              ├── Subjects
              ├── Students
              └── Teachers

Generations ──── Students

Schedule ──┬── Subjects
           ├── Teachers
           └── Classrooms
```

### API Endpoints

#### Authentication
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/change-password` - Change password

#### Students (Admin Only)
- `GET /api/students` - Get all students
- `POST /api/students` - Create student
- `PUT /api/students/:id` - Update student
- `DELETE /api/students/:id` - Delete student

#### Student Portal
- `GET /api/students/:id/academic-data` - Get student's academic data

## 🎯 Key Features

### Admin Dashboard
- **Statistics Overview**: Real-time metrics and KPIs
- **Student Management**: Complete CRUD operations
- **Teacher Management**: Faculty administration
- **Academic Management**: Subjects, schedules, grades
- **Financial Management**: Fee tracking and payments
- **Attendance Tracking**: Comprehensive attendance system

### Student Portal
- **Personal Profile**: Student information and academic details
- **Weekly Schedule**: Class timetable with teacher and room info
- **Grades Overview**: Academic performance with GPA calculation
- **Attendance Records**: Attendance history with visual charts
- **Fee Management**: Payment status and outstanding balances

### Technical Features
- **Responsive Design**: Works on all device sizes
- **Data Persistence**: MySQL database with proper relationships
- **Security**: JWT authentication, password hashing, rate limiting
- **Validation**: Comprehensive input validation on both ends
- **Error Handling**: Proper error messages and status codes
- **Performance**: Optimized queries with indexing and pagination

## 🛠 Technology Stack

### Frontend
- **React 18**: Modern React with hooks
- **TypeScript**: Type-safe development
- **Material UI**: Professional component library
- **Vite**: Fast build tool and dev server
- **Axios**: HTTP client for API calls
- **React Router**: Client-side routing

### Backend
- **Node.js**: JavaScript runtime
- **Express.js**: Web framework
- **MySQL**: Relational database
- **JWT**: Authentication tokens
- **bcryptjs**: Password hashing
- **express-validator**: Input validation
- **helmet**: Security headers
- **cors**: Cross-origin resource sharing

## 📁 Project Structure

```
school-management-system/
├── frontend/                 # React frontend
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── context/         # React context providers
│   │   ├── services/        # API service layer
│   │   ├── types/           # TypeScript type definitions
│   │   └── data/            # Mock data (fallback)
│   └── package.json
├── backend/                  # Node.js backend
│   ├── config/              # Database configuration
│   ├── controllers/         # Route controllers
│   ├── middleware/          # Express middleware
│   ├── routes/              # API routes
│   ├── database/            # SQL schema and seeds
│   ├── scripts/             # Migration scripts
│   └── package.json
└── README.md
```

## 🔧 Development

### Adding New Features

1. **Backend**: Add controller, route, and validation
2. **Frontend**: Create components and integrate API
3. **Database**: Update schema if needed
4. **Testing**: Test with demo data

### Database Changes

1. Update `backend/database/schema.sql`
2. Update `backend/database/seed.sql`
3. Run migration: `npm run migrate`

## 🚀 Deployment

### Backend Deployment
1. Set production environment variables
2. Use process manager (PM2)
3. Configure reverse proxy (Nginx)
4. Set up SSL certificates

### Frontend Deployment
1. Build production bundle: `npm run build`
2. Deploy to static hosting (Netlify, Vercel)
3. Update API URL in environment

## 📈 Performance Features

- **Database Indexing**: Optimized query performance
- **Connection Pooling**: Efficient database connections
- **Pagination**: Large dataset handling
- **Lazy Loading**: Component-level code splitting
- **Caching**: Response caching for static data

## 🔒 Security Features

- **JWT Authentication**: Secure token-based auth
- **Password Hashing**: bcrypt for secure passwords
- **Rate Limiting**: API abuse prevention
- **Input Validation**: Comprehensive validation
- **SQL Injection Prevention**: Parameterized queries
- **CORS Protection**: Configured cross-origin policies

## 📞 Support

For issues and questions:
1. Check the console logs
2. Verify database connection
3. Ensure all environment variables are set
4. Check API endpoint documentation

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Make changes with tests
4. Submit pull request

## 📄 License

This project is licensed under the MIT License.

---

**Built with ❤️ for educational purposes**