import { 
  Generation, 
  Department, 
  Classroom, 
  Student, 
  Teacher, 
  Subject, 
  Schedule, 
  Enrollment, 
  Attendance, 
  Grade, 
  Fee 
} from '../types';

export const initialGenerations: Generation[] = [
  { id: 1, name: "2020-2024", start_year: 2020, end_year: 2024 },
  { id: 2, name: "2021-2025", start_year: 2021, end_year: 2025 },
  { id: 3, name: "2022-2026", start_year: 2022, end_year: 2026 },
];

export const initialDepartments: Department[] = [
  { id: 1, name: "Computer Science" },
  { id: 2, name: "Mathematics" },
  { id: 3, name: "Physics" },
  { id: 4, name: "Chemistry" },
  { id: 5, name: "Biology" },
];

export const initialClassrooms: Classroom[] = [
  { id: 1, name: "CS-101", capacity: 30, department_id: 1 },
  { id: 2, name: "MATH-201", capacity: 40, department_id: 2 },
  { id: 3, name: "PHY-301", capacity: 25, department_id: 3 },
  { id: 4, name: "CHEM-401", capacity: 35, department_id: 4 },
  { id: 5, name: "BIO-501", capacity: 28, department_id: 5 },
];

export const initialStudents: Student[] = [
  {
    id: 1,
    first_name: "John",
    last_name: "Doe",
    gender: "Male",
    dob: "2001-05-15",
    department_id: 1,
    classroom_id: 1,
    generation_id: 2
  },
  {
    id: 2,
    first_name: "Jane",
    last_name: "Smith",
    gender: "Female",
    dob: "2000-08-22",
    department_id: 1,
    classroom_id: 1,
    generation_id: 2
  },
  {
    id: 3,
    first_name: "Mike",
    last_name: "Johnson",
    gender: "Male",
    dob: "2002-01-10",
    department_id: 2,
    classroom_id: 2,
    generation_id: 3
  },
  {
    id: 4,
    first_name: "Sarah",
    last_name: "Williams",
    gender: "Female",
    dob: "2001-11-03",
    department_id: 3,
    classroom_id: 3,
    generation_id: 2
  },
  {
    id: 5,
    first_name: "David",
    last_name: "Brown",
    gender: "Male",
    dob: "2000-07-18",
    department_id: 4,
    classroom_id: 4,
    generation_id: 1
  }
];

export const initialTeachers: Teacher[] = [
  { id: 1, first_name: "Dr. Sarah", last_name: "Wilson", department_id: 1 },
  { id: 2, first_name: "Prof. David", last_name: "Brown", department_id: 1 },
  { id: 3, first_name: "Dr. Lisa", last_name: "Anderson", department_id: 2 },
  { id: 4, first_name: "Prof. Robert", last_name: "Taylor", department_id: 3 },
  { id: 5, first_name: "Dr. Emily", last_name: "Davis", department_id: 4 },
  { id: 6, first_name: "Prof. Michael", last_name: "Miller", department_id: 5 },
];

export const initialSubjects: Subject[] = [
  { id: 1, name: "Data Structures", department_id: 1 },
  { id: 2, name: "Algorithms", department_id: 1 },
  { id: 3, name: "Database Systems", department_id: 1 },
  { id: 4, name: "Linear Algebra", department_id: 2 },
  { id: 5, name: "Calculus II", department_id: 2 },
  { id: 6, name: "Quantum Physics", department_id: 3 },
  { id: 7, name: "Organic Chemistry", department_id: 4 },
  { id: 8, name: "Cell Biology", department_id: 5 },
];

export const initialSchedule: Schedule[] = [
  {
    id: 1,
    subject_id: 1,
    teacher_id: 1,
    classroom_id: 1,
    day_of_week: "Monday",
    start_time: "09:00",
    end_time: "10:30"
  },
  {
    id: 2,
    subject_id: 2,
    teacher_id: 2,
    classroom_id: 1,
    day_of_week: "Monday",
    start_time: "11:00",
    end_time: "12:30"
  },
  {
    id: 3,
    subject_id: 3,
    teacher_id: 1,
    classroom_id: 1,
    day_of_week: "Tuesday",
    start_time: "09:00",
    end_time: "10:30"
  },
  {
    id: 4,
    subject_id: 4,
    teacher_id: 3,
    classroom_id: 2,
    day_of_week: "Wednesday",
    start_time: "14:00",
    end_time: "15:30"
  },
  {
    id: 5,
    subject_id: 1,
    teacher_id: 1,
    classroom_id: 1,
    day_of_week: "Thursday",
    start_time: "09:00",
    end_time: "10:30"
  },
  {
    id: 6,
    subject_id: 2,
    teacher_id: 2,
    classroom_id: 1,
    day_of_week: "Friday",
    start_time: "11:00",
    end_time: "12:30"
  }
];

export const initialEnrollment: Enrollment[] = [
  { id: 1, student_id: 1, subject_id: 1 },
  { id: 2, student_id: 1, subject_id: 2 },
  { id: 3, student_id: 1, subject_id: 3 },
  { id: 4, student_id: 1, subject_id: 4 },
  { id: 5, student_id: 2, subject_id: 1 },
  { id: 6, student_id: 2, subject_id: 2 },
  { id: 7, student_id: 3, subject_id: 4 },
  { id: 8, student_id: 3, subject_id: 5 },
];

export const initialAttendance: Attendance[] = [
  {
    id: 1,
    student_id: 1,
    subject_id: 1,
    schedule_id: 1,
    date: "2024-01-15",
    status: "Present"
  },
  {
    id: 2,
    student_id: 1,
    subject_id: 2,
    schedule_id: 2,
    date: "2024-01-15",
    status: "Present"
  },
  {
    id: 3,
    student_id: 1,
    subject_id: 1,
    schedule_id: 5,
    date: "2024-01-18",
    status: "Late"
  },
  {
    id: 4,
    student_id: 1,
    subject_id: 3,
    schedule_id: 3,
    date: "2024-01-16",
    status: "Absent"
  },
  {
    id: 5,
    student_id: 1,
    subject_id: 4,
    schedule_id: 4,
    date: "2024-01-17",
    status: "Present"
  },
  {
    id: 6,
    student_id: 2,
    subject_id: 1,
    schedule_id: 1,
    date: "2024-01-15",
    status: "Present"
  },
  {
    id: 7,
    student_id: 2,
    subject_id: 2,
    schedule_id: 2,
    date: "2024-01-15",
    status: "Absent"
  }
];

export const initialGrades: Grade[] = [
  { id: 1, student_id: 1, subject_id: 1, attendance_id: 1, grade: 85.5 },
  { id: 2, student_id: 1, subject_id: 2, attendance_id: 2, grade: 92.0 },
  { id: 3, student_id: 1, subject_id: 3, attendance_id: 4, grade: 78.5 },
  { id: 4, student_id: 1, subject_id: 4, attendance_id: 5, grade: 88.0 },
  { id: 5, student_id: 2, subject_id: 1, attendance_id: 6, grade: 91.5 },
  { id: 6, student_id: 2, subject_id: 2, attendance_id: 7, grade: 76.0 },
];

export const initialFees: Fee[] = [
  {
    id: 1,
    student_id: 1,
    amount: 2500.00,
    due_date: "2024-01-15",
    status: "Paid"
  },
  {
    id: 2,
    student_id: 1,
    amount: 2500.00,
    due_date: "2024-04-15",
    status: "Unpaid"
  },
  {
    id: 3,
    student_id: 1,
    amount: 500.00,
    due_date: "2024-02-01",
    status: "Paid"
  },
  {
    id: 4,
    student_id: 2,
    amount: 2500.00,
    due_date: "2024-01-15",
    status: "Paid"
  },
  {
    id: 5,
    student_id: 2,
    amount: 2500.00,
    due_date: "2024-04-15",
    status: "Unpaid"
  }
];