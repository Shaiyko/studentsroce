import React from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { CssBaseline } from '@mui/material';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider } from './context/DataContext';
import { LoginForm } from './components/Auth/LoginForm';
import { AdminLayout } from './components/Layout/AdminLayout';
import { StudentDashboard } from './components/Student/StudentDashboard';
import { Dashboard } from './components/Dashboard/Dashboard';
import { StudentList } from './components/Students/StudentList';
import { TeacherList } from './components/Teachers/TeacherList';
import { DepartmentList } from './components/Departments/DepartmentList';
import { ClassroomList } from './components/Classrooms/ClassroomList';
import { SubjectList } from './components/Subjects/SubjectList';
import { ScheduleList } from './components/Schedule/ScheduleList';
import { EnrollmentList } from './components/Enrollment/EnrollmentList';
import { AttendanceList } from './components/Attendance/AttendanceList';
import { GradeList } from './components/Grades/GradeList';
import { FeeList } from './components/Fees/FeeList';
import { useState } from 'react';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          textTransform: 'none',
          fontWeight: 600,
        },
      },
    },
    MuiTableHead: {
      styleOverrides: {
        root: {
          '& .MuiTableCell-head': {
            backgroundColor: '#f8f9fa',
            fontWeight: 600,
          },
        },
      },
    },
  },
});

const AppContent: React.FC = () => {
  const { user, isAdmin, isStudent } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');

  if (!user) {
    return <LoginForm />;
  }

  if (isStudent) {
    return <StudentDashboard />;
  }

  if (isAdmin) {
    const renderCurrentPage = () => {
      switch (currentPage) {
        case 'dashboard':
          return <Dashboard />;
        case 'students':
          return <StudentList />;
        case 'teachers':
          return <TeacherList />;
        case 'departments':
          return <DepartmentList />;
        case 'classrooms':
          return <ClassroomList />;
        case 'subjects':
          return <SubjectList />;
        case 'schedule':
          return <ScheduleList />;
        case 'enrollment':
          return <EnrollmentList />;
        case 'attendance':
          return <AttendanceList />;
        case 'grades':
          return <GradeList />;
        case 'fees':
          return <FeeList />;
        default:
          return <Dashboard />;
      }
    };

    return (
      <AdminLayout currentPage={currentPage} onPageChange={setCurrentPage}>
        {renderCurrentPage()}
      </AdminLayout>
    );
  }

  return <LoginForm />;
};

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <DataProvider>
          <AppContent />
        </DataProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;