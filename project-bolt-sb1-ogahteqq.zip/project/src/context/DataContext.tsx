import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import {
  Generation,
  Department,
  Classroom,
  Student,
  Teacher,
  Subject,
  Schedule,
  Enrollment,
  Attendance,
  Grade,
  Fee
} from '../types';
import {
  studentsAPI,
  teachersAPI,
  departmentsAPI,
  classroomsAPI,
  subjectsAPI,
  scheduleAPI,
  enrollmentAPI,
  attendanceAPI,
  gradesAPI,
  feesAPI,
  generationsAPI
} from '../services/api';
import { useAuth } from './AuthContext';

interface DataContextType {
  // Data
  generations: Generation[];
  departments: Department[];
  classrooms: Classroom[];
  students: Student[];
  teachers: Teacher[];
  subjects: Subject[];
  schedule: Schedule[];
  enrollment: Enrollment[];
  attendance: Attendance[];
  grades: Grade[];
  fees: Fee[];
  
  // Loading states
  loading: boolean;
  
  // CRUD operations
  addStudent: (student: Omit<Student, 'id'>) => Promise<void>;
  updateStudent: (id: number, student: Omit<Student, 'id'>) => Promise<void>;
  deleteStudent: (id: number) => Promise<void>;
  
  addTeacher: (teacher: Omit<Teacher, 'id'>) => Promise<void>;
  updateTeacher: (id: number, teacher: Omit<Teacher, 'id'>) => Promise<void>;
  deleteTeacher: (id: number) => Promise<void>;
  
  addDepartment: (department: Omit<Department, 'id'>) => Promise<void>;
  updateDepartment: (id: number, department: Omit<Department, 'id'>) => Promise<void>;
  deleteDepartment: (id: number) => Promise<void>;
  
  addClassroom: (classroom: Omit<Classroom, 'id'>) => Promise<void>;
  updateClassroom: (id: number, classroom: Omit<Classroom, 'id'>) => Promise<void>;
  deleteClassroom: (id: number) => Promise<void>;
  
  addSubject: (subject: Omit<Subject, 'id'>) => Promise<void>;
  updateSubject: (id: number, subject: Omit<Subject, 'id'>) => Promise<void>;
  deleteSubject: (id: number) => Promise<void>;
  
  addSchedule: (schedule: Omit<Schedule, 'id'>) => Promise<void>;
  updateSchedule: (id: number, schedule: Omit<Schedule, 'id'>) => Promise<void>;
  deleteSchedule: (id: number) => Promise<void>;
  
  addEnrollment: (enrollment: Omit<Enrollment, 'id'>) => Promise<void>;
  deleteEnrollment: (id: number) => Promise<void>;
  
  addAttendance: (attendance: Omit<Attendance, 'id'>) => Promise<void>;
  updateAttendance: (id: number, attendance: Omit<Attendance, 'id'>) => Promise<void>;
  deleteAttendance: (id: number) => Promise<void>;
  
  addGrade: (grade: Omit<Grade, 'id'>) => Promise<void>;
  updateGrade: (id: number, grade: Omit<Grade, 'id'>) => Promise<void>;
  deleteGrade: (id: number) => Promise<void>;
  
  addFee: (fee: Omit<Fee, 'id'>) => Promise<void>;
  updateFee: (id: number, fee: Omit<Fee, 'id'>) => Promise<void>;
  deleteFee: (id: number) => Promise<void>;
  
  // Refresh functions
  refreshData: () => Promise<void>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

interface DataProviderProps {
  children: ReactNode;
}

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  const { user } = useAuth();
  const [generations, setGenerations] = useState<Generation[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [classrooms, setClassrooms] = useState<Classroom[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [schedule, setSchedule] = useState<Schedule[]>([]);
  const [enrollment, setEnrollment] = useState<Enrollment[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [fees, setFees] = useState<Fee[]>([]);
  const [loading, setLoading] = useState(false);

  // Load initial data when user is authenticated
  useEffect(() => {
    if (user) {
      refreshData();
    }
  }, [user]);

  const refreshData = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      // Load all data in parallel
      const promises = [
        generationsAPI.getAll().catch(err => ({ success: false, error: err })),
        departmentsAPI.getAll().catch(err => ({ success: false, error: err })),
        classroomsAPI.getAll().catch(err => ({ success: false, error: err })),
        studentsAPI.getAll().catch(err => ({ success: false, error: err })),
        teachersAPI.getAll().catch(err => ({ success: false, error: err })),
        subjectsAPI.getAll().catch(err => ({ success: false, error: err })),
        scheduleAPI.getAll().catch(err => ({ success: false, error: err })),
        enrollmentAPI.getAll().catch(err => ({ success: false, error: err })),
        attendanceAPI.getAll().catch(err => ({ success: false, error: err })),
        gradesAPI.getAll().catch(err => ({ success: false, error: err })),
        feesAPI.getAll().catch(err => ({ success: false, error: err }))
      ];

      const [
        generationsRes,
        departmentsRes,
        classroomsRes,
        studentsRes,
        teachersRes,
        subjectsRes,
        scheduleRes,
        enrollmentRes,
        attendanceRes,
        gradesRes,
        feesRes
      ] = await Promise.all(promises);

      // Update state with successful responses
      if (generationsRes.success) setGenerations(generationsRes.data || []);
      if (departmentsRes.success) setDepartments(departmentsRes.data || []);
      if (classroomsRes.success) setClassrooms(classroomsRes.data || []);
      if (studentsRes.success) setStudents(studentsRes.data?.students || studentsRes.data || []);
      if (teachersRes.success) setTeachers(teachersRes.data?.teachers || teachersRes.data || []);
      if (subjectsRes.success) setSubjects(subjectsRes.data || []);
      if (scheduleRes.success) setSchedule(scheduleRes.data || []);
      if (enrollmentRes.success) setEnrollment(enrollmentRes.data || []);
      if (attendanceRes.success) setAttendance(attendanceRes.data || []);
      if (gradesRes.success) setGrades(gradesRes.data || []);
      if (feesRes.success) setFees(feesRes.data || []);

    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Student CRUD
  const addStudent = async (student: Omit<Student, 'id'>) => {
    try {
      const response = await studentsAPI.create(student);
      if (response.success) {
        await refreshData(); // Refresh all data to get updated relationships
      }
    } catch (error) {
      console.error('Error adding student:', error);
      throw error;
    }
  };

  const updateStudent = async (id: number, student: Omit<Student, 'id'>) => {
    try {
      const response = await studentsAPI.update(id, student);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error updating student:', error);
      throw error;
    }
  };

  const deleteStudent = async (id: number) => {
    try {
      const response = await studentsAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting student:', error);
      throw error;
    }
  };

  // Teacher CRUD
  const addTeacher = async (teacher: Omit<Teacher, 'id'>) => {
    try {
      const response = await teachersAPI.create(teacher);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error adding teacher:', error);
      throw error;
    }
  };

  const updateTeacher = async (id: number, teacher: Omit<Teacher, 'id'>) => {
    try {
      const response = await teachersAPI.update(id, teacher);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error updating teacher:', error);
      throw error;
    }
  };

  const deleteTeacher = async (id: number) => {
    try {
      const response = await teachersAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting teacher:', error);
      throw error;
    }
  };

  // Department CRUD
  const addDepartment = async (department: Omit<Department, 'id'>) => {
    try {
      const response = await departmentsAPI.create(department);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error adding department:', error);
      throw error;
    }
  };

  const updateDepartment = async (id: number, department: Omit<Department, 'id'>) => {
    try {
      const response = await departmentsAPI.update(id, department);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error updating department:', error);
      throw error;
    }
  };

  const deleteDepartment = async (id: number) => {
    try {
      const response = await departmentsAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting department:', error);
      throw error;
    }
  };

  // Classroom CRUD
  const addClassroom = async (classroom: Omit<Classroom, 'id'>) => {
    try {
      const response = await classroomsAPI.create(classroom);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error adding classroom:', error);
      throw error;
    }
  };

  const updateClassroom = async (id: number, classroom: Omit<Classroom, 'id'>) => {
    try {
      const response = await classroomsAPI.update(id, classroom);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error updating classroom:', error);
      throw error;
    }
  };

  const deleteClassroom = async (id: number) => {
    try {
      const response = await classroomsAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting classroom:', error);
      throw error;
    }
  };

  // Subject CRUD
  const addSubject = async (subject: Omit<Subject, 'id'>) => {
    try {
      const response = await subjectsAPI.create(subject);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error adding subject:', error);
      throw error;
    }
  };

  const updateSubject = async (id: number, subject: Omit<Subject, 'id'>) => {
    try {
      const response = await subjectsAPI.update(id, subject);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error updating subject:', error);
      throw error;
    }
  };

  const deleteSubject = async (id: number) => {
    try {
      const response = await subjectsAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting subject:', error);
      throw error;
    }
  };

  // Schedule CRUD
  const addSchedule = async (scheduleItem: Omit<Schedule, 'id'>) => {
    try {
      const response = await scheduleAPI.create(scheduleItem);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error adding schedule:', error);
      throw error;
    }
  };

  const updateSchedule = async (id: number, scheduleItem: Omit<Schedule, 'id'>) => {
    try {
      const response = await scheduleAPI.update(id, scheduleItem);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error updating schedule:', error);
      throw error;
    }
  };

  const deleteSchedule = async (id: number) => {
    try {
      const response = await scheduleAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting schedule:', error);
      throw error;
    }
  };

  // Enrollment CRUD
  const addEnrollment = async (enrollmentItem: Omit<Enrollment, 'id'>) => {
    try {
      const response = await enrollmentAPI.create(enrollmentItem);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error adding enrollment:', error);
      throw error;
    }
  };

  const deleteEnrollment = async (id: number) => {
    try {
      const response = await enrollmentAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting enrollment:', error);
      throw error;
    }
  };

  // Attendance CRUD
  const addAttendance = async (attendanceItem: Omit<Attendance, 'id'>) => {
    try {
      const response = await attendanceAPI.create(attendanceItem);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error adding attendance:', error);
      throw error;
    }
  };

  const updateAttendance = async (id: number, attendanceItem: Omit<Attendance, 'id'>) => {
    try {
      const response = await attendanceAPI.update(id, attendanceItem);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error updating attendance:', error);
      throw error;
    }
  };

  const deleteAttendance = async (id: number) => {
    try {
      const response = await attendanceAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting attendance:', error);
      throw error;
    }
  };

  // Grade CRUD
  const addGrade = async (grade: Omit<Grade, 'id'>) => {
    try {
      const response = await gradesAPI.create(grade);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error adding grade:', error);
      throw error;
    }
  };

  const updateGrade = async (id: number, grade: Omit<Grade, 'id'>) => {
    try {
      const response = await gradesAPI.update(id, grade);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error updating grade:', error);
      throw error;
    }
  };

  const deleteGrade = async (id: number) => {
    try {
      const response = await gradesAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting grade:', error);
      throw error;
    }
  };

  // Fee CRUD
  const addFee = async (fee: Omit<Fee, 'id'>) => {
    try {
      const response = await feesAPI.create(fee);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error adding fee:', error);
      throw error;
    }
  };

  const updateFee = async (id: number, fee: Omit<Fee, 'id'>) => {
    try {
      const response = await feesAPI.update(id, fee);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error updating fee:', error);
      throw error;
    }
  };

  const deleteFee = async (id: number) => {
    try {
      const response = await feesAPI.delete(id);
      if (response.success) {
        await refreshData();
      }
    } catch (error) {
      console.error('Error deleting fee:', error);
      throw error;
    }
  };

  return (
    <DataContext.Provider
      value={{
        generations,
        departments,
        classrooms,
        students,
        teachers,
        subjects,
        schedule,
        enrollment,
        attendance,
        grades,
        fees,
        loading,
        addStudent,
        updateStudent,
        deleteStudent,
        addTeacher,
        updateTeacher,
        deleteTeacher,
        addDepartment,
        updateDepartment,
        deleteDepartment,
        addClassroom,
        updateClassroom,
        deleteClassroom,
        addSubject,
        updateSubject,
        deleteSubject,
        addSchedule,
        updateSchedule,
        deleteSchedule,
        addEnrollment,
        deleteEnrollment,
        addAttendance,
        updateAttendance,
        deleteAttendance,
        addGrade,
        updateGrade,
        deleteGrade,
        addFee,
        updateFee,
        deleteFee,
        refreshData,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};