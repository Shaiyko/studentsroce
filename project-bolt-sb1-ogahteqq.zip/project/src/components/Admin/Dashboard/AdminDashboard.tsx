import React from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip
} from '@mui/material';
import {
  People as PeopleIcon,
  School as SchoolIcon,
  Class as ClassIcon,
  Assignment as AssignmentIcon,
  EventAvailable as AttendanceIcon,
  Payment as PaymentIcon,
  TrendingUp as TrendingUpIcon,
  Warning as WarningIcon
} from '@mui/icons-material';
import { useData } from '../../../context/DataContext';

export const AdminDashboard: React.FC = () => {
  const { 
    students, 
    teachers, 
    departments, 
    subjects, 
    attendance, 
    grades, 
    fees 
  } = useData();

  // Calculate statistics
  const totalStudents = students.length;
  const totalTeachers = teachers.length;
  const totalDepartments = departments.length;
  const totalSubjects = subjects.length;

  const presentToday = attendance.filter(a => 
    a.date === new Date().toISOString().split('T')[0] && a.status === 'Present'
  ).length;

  const averageGrade = grades.length > 0 
    ? grades.reduce((sum, g) => sum + g.grade, 0) / grades.length 
    : 0;

  const unpaidFees = fees.filter(f => f.status === 'Unpaid');
  const totalUnpaidAmount = unpaidFees.reduce((sum, f) => sum + f.amount, 0);

  const recentActivities = [
    { text: 'New student John Doe enrolled', time: '2 hours ago', type: 'info' },
    { text: 'Grade updated for Mathematics', time: '4 hours ago', type: 'success' },
    { text: 'Fee payment overdue for 3 students', time: '1 day ago', type: 'warning' },
    { text: 'New teacher Sarah Wilson added', time: '2 days ago', type: 'info' },
  ];

  const StatCard = ({ title, value, icon, color = 'primary' }: any) => (
    <Card elevation={2} sx={{ height: '100%' }}>
      <CardContent>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box>
            <Typography color="text.secondary" gutterBottom variant="h6">
              {title}
            </Typography>
            <Typography variant="h3" component="div" sx={{ fontWeight: 'bold', color: `${color}.main` }}>
              {value}
            </Typography>
          </Box>
          <Box sx={{ color: `${color}.main` }}>
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
        Admin Dashboard
      </Typography>

      {/* Statistics Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Students"
            value={totalStudents}
            icon={<PeopleIcon sx={{ fontSize: 40 }} />}
            color="primary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Teachers"
            value={totalTeachers}
            icon={<SchoolIcon sx={{ fontSize: 40 }} />}
            color="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Departments"
            value={totalDepartments}
            icon={<ClassIcon sx={{ fontSize: 40 }} />}
            color="info"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Subjects"
            value={totalSubjects}
            icon={<AssignmentIcon sx={{ fontSize: 40 }} />}
            color="warning"
          />
        </Grid>
      </Grid>

      {/* Performance Metrics */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Present Today"
            value={presentToday}
            icon={<AttendanceIcon sx={{ fontSize: 40 }} />}
            color="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Average Grade"
            value={`${averageGrade.toFixed(1)}%`}
            icon={<TrendingUpIcon sx={{ fontSize: 40 }} />}
            color="info"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Unpaid Fees"
            value={unpaidFees.length}
            icon={<WarningIcon sx={{ fontSize: 40 }} />}
            color="error"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Outstanding Amount"
            value={`$${totalUnpaidAmount.toFixed(2)}`}
            icon={<PaymentIcon sx={{ fontSize: 40 }} />}
            color="error"
          />
        </Grid>
      </Grid>

      {/* Recent Activities and Quick Stats */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" component="h2" gutterBottom sx={{ fontWeight: 'bold' }}>
                Recent Activities
              </Typography>
              <List>
                {recentActivities.map((activity, index) => (
                  <ListItem key={index} divider={index < recentActivities.length - 1}>
                    <ListItemIcon>
                      {activity.type === 'warning' ? (
                        <WarningIcon color="warning" />
                      ) : activity.type === 'success' ? (
                        <TrendingUpIcon color="success" />
                      ) : (
                        <PeopleIcon color="primary" />
                      )}
                    </ListItemIcon>
                    <ListItemText
                      primary={activity.text}
                      secondary={activity.time}
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={6}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" component="h2" gutterBottom sx={{ fontWeight: 'bold' }}>
                Quick Overview
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="body1">Active Enrollments</Typography>
                    <Chip label="24" color="primary" />
                  </Box>
                </Paper>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="body1">Scheduled Classes</Typography>
                    <Chip label="18" color="info" />
                  </Box>
                </Paper>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="body1">Attendance Rate</Typography>
                    <Chip label="87%" color="success" />
                  </Box>
                </Paper>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="body1">Fee Collection</Typography>
                    <Chip label="92%" color="warning" />
                  </Box>
                </Paper>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};