import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  Typography,
  Box
} from '@mui/material';
import { useData } from '../../context/DataContext';
import { Grade } from '../../types';

interface GradeFormProps {
  open: boolean;
  onClose: () => void;
  grade?: Grade | null;
  onSuccess: (message: string) => void;
}

export const GradeForm: React.FC<GradeFormProps> = ({ open, onClose, grade, onSuccess }) => {
  const { students, subjects, attendance, addGrade, updateGrade } = useData();
  
  const [formData, setFormData] = useState({
    student_id: '',
    subject_id: '',
    attendance_id: '',
    grade: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (grade) {
      setFormData({
        student_id: grade.student_id.toString(),
        subject_id: grade.subject_id.toString(),
        attendance_id: grade.attendance_id.toString(),
        grade: grade.grade.toString()
      });
    } else {
      setFormData({
        student_id: '',
        subject_id: '',
        attendance_id: '',
        grade: ''
      });
    }
    setErrors({});
  }, [grade, open]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.student_id) {
      newErrors.student_id = 'Student is required';
    }
    if (!formData.subject_id) {
      newErrors.subject_id = 'Subject is required';
    }
    if (!formData.attendance_id) {
      newErrors.attendance_id = 'Attendance record is required';
    }
    if (!formData.grade || parseFloat(formData.grade) < 0 || parseFloat(formData.grade) > 100) {
      newErrors.grade = 'Valid grade (0-100) is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const gradeData = {
      student_id: parseInt(formData.student_id),
      subject_id: parseInt(formData.subject_id),
      attendance_id: parseInt(formData.attendance_id),
      grade: parseFloat(formData.grade)
    };

    if (grade) {
      updateGrade(grade.id, gradeData);
      onSuccess('Grade updated successfully');
    } else {
      addGrade(gradeData);
      onSuccess('Grade added successfully');
    }
  };

  const availableAttendance = attendance.filter(a => 
    (!formData.student_id || a.student_id.toString() === formData.student_id) &&
    (!formData.subject_id || a.subject_id.toString() === formData.subject_id)
  );

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        {grade ? 'Edit Grade' : 'Add New Grade'}
      </DialogTitle>
      <DialogContent>
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            {grade ? 'Update the grade information.' : 'Assign a grade to a student for a specific subject.'}
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.student_id}>
                <InputLabel>Student</InputLabel>
                <Select
                  value={formData.student_id}
                  label="Student"
                  onChange={(e) => {
                    handleChange('student_id', e.target.value);
                    handleChange('attendance_id', ''); // Reset attendance when student changes
                  }}
                >
                  {students.map(student => (
                    <MenuItem key={student.id} value={student.id.toString()}>
                      {student.first_name} {student.last_name}
                    </MenuItem>
                  ))}
                </Select>
                {errors.student_id && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.student_id}
                  </Alert>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.subject_id}>
                <InputLabel>Subject</InputLabel>
                <Select
                  value={formData.subject_id}
                  label="Subject"
                  onChange={(e) => {
                    handleChange('subject_id', e.target.value);
                    handleChange('attendance_id', ''); // Reset attendance when subject changes
                  }}
                >
                  {subjects.map(subject => (
                    <MenuItem key={subject.id} value={subject.id.toString()}>
                      {subject.name}
                    </MenuItem>
                  ))}
                </Select>
                {errors.subject_id && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.subject_id}
                  </Alert>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.attendance_id}>
                <InputLabel>Attendance Record</InputLabel>
                <Select
                  value={formData.attendance_id}
                  label="Attendance Record"
                  onChange={(e) => handleChange('attendance_id', e.target.value)}
                  disabled={!formData.student_id || !formData.subject_id}
                >
                  {availableAttendance.map(attendanceRecord => (
                    <MenuItem key={attendanceRecord.id} value={attendanceRecord.id.toString()}>
                      {attendanceRecord.date} - {attendanceRecord.status}
                    </MenuItem>
                  ))}
                </Select>
                {errors.attendance_id && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.attendance_id}
                  </Alert>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Grade"
                type="number"
                value={formData.grade}
                onChange={(e) => handleChange('grade', e.target.value)}
                error={!!errors.grade}
                helperText={errors.grade || 'Enter grade as percentage (0-100)'}
                inputProps={{ min: 0, max: 100, step: 0.1 }}
              />
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
      <DialogActions sx={{ p: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">
          {grade ? 'Update' : 'Add'} Grade
        </Button>
      </DialogActions>
    </Dialog>
  );
};