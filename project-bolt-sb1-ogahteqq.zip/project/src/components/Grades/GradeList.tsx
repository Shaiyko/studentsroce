import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Alert,
  LinearProgress
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon
} from '@mui/icons-material';
import { useData } from '../../context/DataContext';
import { GradeForm } from './GradeForm';

export const GradeList: React.FC = () => {
  const { 
    grades, 
    students,
    subjects,
    attendance,
    deleteGrade 
  } = useData();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [openForm, setOpenForm] = useState(false);
  const [editingGrade, setEditingGrade] = useState<any>(null);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; grade: any }>({
    open: false,
    grade: null
  });
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success'
  });

  const getStudentName = (id: number) => {
    const student = students.find(s => s.id === id);
    return student ? `${student.first_name} ${student.last_name}` : 'Unknown';
  };

  const getSubjectName = (id: number) => {
    return subjects.find(s => s.id === id)?.name || 'Unknown';
  };

  const getGradeColor = (grade: number) => {
    if (grade >= 90) return 'success';
    if (grade >= 80) return 'info';
    if (grade >= 70) return 'warning';
    return 'error';
  };

  const getGradeLetter = (grade: number) => {
    if (grade >= 90) return 'A';
    if (grade >= 80) return 'B';
    if (grade >= 70) return 'C';
    if (grade >= 60) return 'D';
    return 'F';
  };

  const filteredGrades = grades.filter(grade => {
    const studentName = getStudentName(grade.student_id).toLowerCase();
    const subjectName = getSubjectName(grade.subject_id).toLowerCase();
    const search = searchTerm.toLowerCase();
    
    const matchesSearch = studentName.includes(search) || subjectName.includes(search);
    const matchesSubject = !subjectFilter || grade.subject_id.toString() === subjectFilter;
    
    return matchesSearch && matchesSubject;
  });

  const handleEdit = (grade: any) => {
    setEditingGrade(grade);
    setOpenForm(true);
  };

  const handleDelete = (grade: any) => {
    setDeleteDialog({ open: true, grade });
  };

  const confirmDelete = () => {
    if (deleteDialog.grade) {
      deleteGrade(deleteDialog.grade.id);
      setDeleteDialog({ open: false, grade: null });
      setSnackbar({
        open: true,
        message: 'Grade deleted successfully',
        severity: 'success'
      });
    }
  };

  const handleCloseForm = () => {
    setOpenForm(false);
    setEditingGrade(null);
  };

  const handleFormSuccess = (message: string) => {
    setSnackbar({
      open: true,
      message,
      severity: 'success'
    });
    handleCloseForm();
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Grades Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpenForm(true)}
          sx={{ borderRadius: 2 }}
        >
          Add Grade
        </Button>
      </Box>

      {/* Search and Filter */}
      <Card elevation={2} sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                placeholder="Search by student or subject..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />
                }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Filter by Subject</InputLabel>
                <Select
                  value={subjectFilter}
                  label="Filter by Subject"
                  onChange={(e) => setSubjectFilter(e.target.value)}
                >
                  <MenuItem value="">All Subjects</MenuItem>
                  {subjects.map(subject => (
                    <MenuItem key={subject.id} value={subject.id.toString()}>
                      {subject.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={2}>
              <Typography variant="body2" color="text.secondary">
                {filteredGrades.length} grades found
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Grades Table */}
      <Card elevation={2}>
        <CardContent>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 'bold' }}>ID</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Student</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Subject</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Grade</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Letter</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Performance</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredGrades.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      <Typography color="text.secondary" sx={{ py: 4 }}>
                        No grades found
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredGrades.map((grade) => (
                    <TableRow key={grade.id} hover>
                      <TableCell>
                        <Chip label={grade.id} size="small" color="primary" />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                          {getStudentName(grade.student_id)}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                          {getSubjectName(grade.subject_id)}
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <Typography 
                          variant="h6" 
                          sx={{ 
                            fontWeight: 'bold',
                            color: `${getGradeColor(grade.grade)}.main`
                          }}
                        >
                          {grade.grade}%
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <Chip
                          label={getGradeLetter(grade.grade)}
                          color={getGradeColor(grade.grade)}
                          size="small"
                          sx={{ fontWeight: 'bold' }}
                        />
                      </TableCell>
                      <TableCell align="center">
                        <Box sx={{ width: 100 }}>
                          <LinearProgress
                            variant="determinate"
                            value={Math.min(grade.grade, 100)}
                            color={getGradeColor(grade.grade)}
                            sx={{ height: 6, borderRadius: 3 }}
                          />
                        </Box>
                      </TableCell>
                      <TableCell align="center">
                        <IconButton
                          size="small"
                          onClick={() => handleEdit(grade)}
                          sx={{ mr: 1 }}
                        >
                          <EditIcon />
                        </IconButton>
                        <IconButton
                          size="small"
                          onClick={() => handleDelete(grade)}
                          color="error"
                        >
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Grade Form Dialog */}
      <GradeForm
        open={openForm}
        onClose={handleCloseForm}
        grade={editingGrade}
        onSuccess={handleFormSuccess}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog({ open: false, grade: null })}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this grade?
          </Typography>
          {deleteDialog.grade && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="body2">
                <strong>Student:</strong> {getStudentName(deleteDialog.grade.student_id)}
              </Typography>
              <Typography variant="body2">
                <strong>Subject:</strong> {getSubjectName(deleteDialog.grade.subject_id)}
              </Typography>
              <Typography variant="body2">
                <strong>Grade:</strong> {deleteDialog.grade.grade}%
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog({ open: false, grade: null })}>
            Cancel
          </Button>
          <Button onClick={confirmDelete} color="error" variant="contained">
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success/Error Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};