import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert
} from '@mui/material';
import { useData } from '../../context/DataContext';
import { Student } from '../../types';

interface StudentFormProps {
  open: boolean;
  onClose: () => void;
  student?: Student | null;
  onSuccess: (message: string) => void;
}

export const StudentForm: React.FC<StudentFormProps> = ({ open, onClose, student, onSuccess }) => {
  const { departments, classrooms, generations, addStudent, updateStudent } = useData();
  
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    gender: 'Male' as 'Male' | 'Female' | 'Other',
    dob: '',
    department_id: '',
    classroom_id: '',
    generation_id: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (student) {
      setFormData({
        first_name: student.first_name,
        last_name: student.last_name,
        gender: student.gender,
        dob: student.dob,
        department_id: student.department_id.toString(),
        classroom_id: student.classroom_id.toString(),
        generation_id: student.generation_id.toString()
      });
    } else {
      setFormData({
        first_name: '',
        last_name: '',
        gender: 'Male',
        dob: '',
        department_id: '',
        classroom_id: '',
        generation_id: ''
      });
    }
    setErrors({});
  }, [student, open]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.first_name.trim()) {
      newErrors.first_name = 'First name is required';
    }
    if (!formData.last_name.trim()) {
      newErrors.last_name = 'Last name is required';
    }
    if (!formData.dob) {
      newErrors.dob = 'Date of birth is required';
    }
    if (!formData.department_id) {
      newErrors.department_id = 'Department is required';
    }
    if (!formData.classroom_id) {
      newErrors.classroom_id = 'Classroom is required';
    }
    if (!formData.generation_id) {
      newErrors.generation_id = 'Generation is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const studentData = {
      first_name: formData.first_name.trim(),
      last_name: formData.last_name.trim(),
      gender: formData.gender,
      dob: formData.dob,
      department_id: parseInt(formData.department_id),
      classroom_id: parseInt(formData.classroom_id),
      generation_id: parseInt(formData.generation_id)
    };

    if (student) {
      updateStudent(student.id, studentData);
      onSuccess('Student updated successfully');
    } else {
      addStudent(studentData);
      onSuccess('Student added successfully');
    }
  };

  const availableClassrooms = classrooms.filter(
    classroom => !formData.department_id || classroom.department_id.toString() === formData.department_id
  );

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        {student ? 'Edit Student' : 'Add New Student'}
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={2} sx={{ mt: 1 }}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="First Name"
              value={formData.first_name}
              onChange={(e) => handleChange('first_name', e.target.value)}
              error={!!errors.first_name}
              helperText={errors.first_name}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Last Name"
              value={formData.last_name}
              onChange={(e) => handleChange('last_name', e.target.value)}
              error={!!errors.last_name}
              helperText={errors.last_name}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.gender}>
              <InputLabel>Gender</InputLabel>
              <Select
                value={formData.gender}
                label="Gender"
                onChange={(e) => handleChange('gender', e.target.value)}
              >
                <MenuItem value="Male">Male</MenuItem>
                <MenuItem value="Female">Female</MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Date of Birth"
              type="date"
              value={formData.dob}
              onChange={(e) => handleChange('dob', e.target.value)}
              InputLabelProps={{ shrink: true }}
              error={!!errors.dob}
              helperText={errors.dob}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.department_id}>
              <InputLabel>Department</InputLabel>
              <Select
                value={formData.department_id}
                label="Department"
                onChange={(e) => {
                  handleChange('department_id', e.target.value);
                  handleChange('classroom_id', ''); // Reset classroom when department changes
                }}
              >
                {departments.map(dept => (
                  <MenuItem key={dept.id} value={dept.id.toString()}>
                    {dept.name}
                  </MenuItem>
                ))}
              </Select>
              {errors.department_id && (
                <Alert severity="error" sx={{ mt: 1 }}>
                  {errors.department_id}
                </Alert>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.classroom_id}>
              <InputLabel>Classroom</InputLabel>
              <Select
                value={formData.classroom_id}
                label="Classroom"
                onChange={(e) => handleChange('classroom_id', e.target.value)}
                disabled={!formData.department_id}
              >
                {availableClassrooms.map(classroom => (
                  <MenuItem key={classroom.id} value={classroom.id.toString()}>
                    {classroom.name} (Capacity: {classroom.capacity})
                  </MenuItem>
                ))}
              </Select>
              {errors.classroom_id && (
                <Alert severity="error" sx={{ mt: 1 }}>
                  {errors.classroom_id}
                </Alert>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth error={!!errors.generation_id}>
              <InputLabel>Generation</InputLabel>
              <Select
                value={formData.generation_id}
                label="Generation"
                onChange={(e) => handleChange('generation_id', e.target.value)}
              >
                {generations.map(gen => (
                  <MenuItem key={gen.id} value={gen.id.toString()}>
                    {gen.name} ({gen.start_year} - {gen.end_year})
                  </MenuItem>
                ))}
              </Select>
              {errors.generation_id && (
                <Alert severity="error" sx={{ mt: 1 }}>
                  {errors.generation_id}
                </Alert>
              )}
            </FormControl>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ p: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">
          {student ? 'Update' : 'Add'} Student
        </Button>
      </DialogActions>
    </Dialog>
  );
};