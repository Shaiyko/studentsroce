import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Alert
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon
} from '@mui/icons-material';
import { useData } from '../../context/DataContext';
import { SubjectForm } from './SubjectForm';

export const SubjectList: React.FC = () => {
  const { 
    subjects, 
    departments,
    enrollment,
    deleteSubject 
  } = useData();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [openForm, setOpenForm] = useState(false);
  const [editingSubject, setEditingSubject] = useState<any>(null);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; subject: any }>({
    open: false,
    subject: null
  });
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success'
  });

  const getDepartmentName = (id: number) => {
    return departments.find(d => d.id === id)?.name || 'Unknown';
  };

  const getEnrollmentCount = (subjectId: number) => {
    return enrollment.filter(e => e.subject_id === subjectId).length;
  };

  const filteredSubjects = subjects.filter(subject => {
    const matchesSearch = subject.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = !departmentFilter || subject.department_id.toString() === departmentFilter;
    
    return matchesSearch && matchesDepartment;
  });

  const handleEdit = (subject: any) => {
    setEditingSubject(subject);
    setOpenForm(true);
  };

  const handleDelete = (subject: any) => {
    setDeleteDialog({ open: true, subject });
  };

  const confirmDelete = () => {
    if (deleteDialog.subject) {
      const enrollmentCount = getEnrollmentCount(deleteDialog.subject.id);
      
      if (enrollmentCount > 0) {
        setSnackbar({
          open: true,
          message: 'Cannot delete subject with existing enrollments',
          severity: 'error'
        });
      } else {
        deleteSubject(deleteDialog.subject.id);
        setSnackbar({
          open: true,
          message: 'Subject deleted successfully',
          severity: 'success'
        });
      }
      setDeleteDialog({ open: false, subject: null });
    }
  };

  const handleCloseForm = () => {
    setOpenForm(false);
    setEditingSubject(null);
  };

  const handleFormSuccess = (message: string) => {
    setSnackbar({
      open: true,
      message,
      severity: 'success'
    });
    handleCloseForm();
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Subjects Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpenForm(true)}
          sx={{ borderRadius: 2 }}
        >
          Add Subject
        </Button>
      </Box>

      {/* Search and Filter */}
      <Card elevation={2} sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                placeholder="Search subjects..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />
                }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Filter by Department</InputLabel>
                <Select
                  value={departmentFilter}
                  label="Filter by Department"
                  onChange={(e) => setDepartmentFilter(e.target.value)}
                >
                  <MenuItem value="">All Departments</MenuItem>
                  {departments.map(dept => (
                    <MenuItem key={dept.id} value={dept.id.toString()}>
                      {dept.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={2}>
              <Typography variant="body2" color="text.secondary">
                {filteredSubjects.length} subjects found
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Subjects Table */}
      <Card elevation={2}>
        <CardContent>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 'bold' }}>ID</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Subject Name</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Department</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Enrolled Students</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredSubjects.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} align="center">
                      <Typography color="text.secondary" sx={{ py: 4 }}>
                        No subjects found
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredSubjects.map((subject) => (
                    <TableRow key={subject.id} hover>
                      <TableCell>
                        <Chip label={subject.id} size="small" color="primary" />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                          {subject.name}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip 
                          label={getDepartmentName(subject.department_id)} 
                          size="small" 
                          color="info"
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell align="center">
                        <Chip 
                          label={getEnrollmentCount(subject.id)} 
                          size="small" 
                          color="success"
                        />
                      </TableCell>
                      <TableCell align="center">
                        <IconButton
                          size="small"
                          onClick={() => handleEdit(subject)}
                          sx={{ mr: 1 }}
                        >
                          <EditIcon />
                        </IconButton>
                        <IconButton
                          size="small"
                          onClick={() => handleDelete(subject)}
                          color="error"
                        >
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Subject Form Dialog */}
      <SubjectForm
        open={openForm}
        onClose={handleCloseForm}
        subject={editingSubject}
        onSuccess={handleFormSuccess}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog({ open: false, subject: null })}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete subject "{deleteDialog.subject?.name}"?
          </Typography>
          {deleteDialog.subject && getEnrollmentCount(deleteDialog.subject.id) > 0 && (
            <Alert severity="warning" sx={{ mt: 2 }}>
              This subject has {getEnrollmentCount(deleteDialog.subject.id)} enrolled students. 
              Cannot delete subject with existing enrollments.
            </Alert>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog({ open: false, subject: null })}>
            Cancel
          </Button>
          <Button 
            onClick={confirmDelete} 
            color="error" 
            variant="contained"
            disabled={deleteDialog.subject && getEnrollmentCount(deleteDialog.subject.id) > 0}
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success/Error Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};