import React from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Paper,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Chip,
  LinearProgress,
  CircularProgress
} from '@mui/material';
import {
  People as PeopleIcon,
  School as SchoolIcon,
  Class as ClassIcon,
  Assignment as AssignmentIcon,
  EventAvailable as AttendanceIcon,
  Payment as PaymentIcon,
  TrendingUp as TrendingUpIcon,
  Warning as WarningIcon,
  CheckCircle as CheckCircleIcon
} from '@mui/icons-material';
import { useData } from '../../context/DataContext';

export const Dashboard: React.FC = () => {
  const { 
    students, 
    teachers, 
    departments, 
    subjects, 
    classrooms,
    attendance, 
    grades, 
    fees,
    enrollment,
    loading
  } = useData();

  // Show loading state
  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="400px">
        <CircularProgress size={60} />
        <Typography variant="h6" sx={{ ml: 2 }}>
          Loading dashboard data...
        </Typography>
      </Box>
    );
  }

  // Calculate statistics with safe fallbacks
  const totalStudents = students?.length || 0;
  const totalTeachers = teachers?.length || 0;
  const totalDepartments = departments?.length || 0;
  const totalSubjects = subjects?.length || 0;
  const totalClassrooms = classrooms?.length || 0;
  const totalEnrollments = enrollment?.length || 0;

  const presentToday = attendance?.filter(a => 
    a.date === new Date().toISOString().split('T')[0] && a.status === 'Present'
  ).length || 0;

  const averageGrade = grades?.length > 0 
    ? grades.reduce((sum, g) => sum + g.grade, 0) / grades.length 
    : 0;

  const unpaidFees = fees?.filter(f => f.status === 'Unpaid') || [];
  const totalUnpaidAmount = unpaidFees.reduce((sum, f) => sum + f.amount, 0);
  const totalFeesAmount = fees?.reduce((sum, f) => sum + f.amount, 0) || 0;
  const paidFeesAmount = fees?.filter(f => f.status === 'Paid').reduce((sum, f) => sum + f.amount, 0) || 0;
  const feeCollectionRate = totalFeesAmount > 0 ? (paidFeesAmount / totalFeesAmount) * 100 : 0;

  const attendanceRate = attendance?.length > 0 
    ? (attendance.filter(a => a.status === 'Present').length / attendance.length) * 100 
    : 0;

  const recentActivities = [
    { text: 'New student enrolled in Computer Science', time: '2 hours ago', type: 'success' },
    { text: 'Grade updated for Mathematics course', time: '4 hours ago', type: 'info' },
    { text: 'Fee payment overdue for 3 students', time: '1 day ago', type: 'warning' },
    { text: 'New teacher added to Physics department', time: '2 days ago', type: 'success' },
    { text: 'Classroom capacity updated', time: '3 days ago', type: 'info' },
  ];

  const StatCard = ({ title, value, icon, color = 'primary', subtitle }: any) => (
    <Card elevation={2} sx={{ height: '100%' }}>
      <CardContent>
        <Box display="flex" alignItems="center" justifyContent="space-between">
          <Box>
            <Typography color="text.secondary" gutterBottom variant="body2" sx={{ fontWeight: 500 }}>
              {title}
            </Typography>
            <Typography variant="h3" component="div" sx={{ fontWeight: 'bold', color: `${color}.main`, mb: 1 }}>
              {value}
            </Typography>
            {subtitle && (
              <Typography variant="body2" color="text.secondary">
                {subtitle}
              </Typography>
            )}
          </Box>
          <Box sx={{ color: `${color}.main` }}>
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 4 }}>
        Dashboard Overview
      </Typography>

      {/* Main Statistics Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Students"
            value={totalStudents}
            subtitle={`${totalEnrollments} enrollments`}
            icon={<PeopleIcon sx={{ fontSize: 40 }} />}
            color="primary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Teachers"
            value={totalTeachers}
            subtitle={`${totalDepartments} departments`}
            icon={<SchoolIcon sx={{ fontSize: 40 }} />}
            color="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Subjects"
            value={totalSubjects}
            subtitle={`${totalClassrooms} classrooms`}
            icon={<AssignmentIcon sx={{ fontSize: 40 }} />}
            color="info"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Departments"
            value={totalDepartments}
            subtitle="Active departments"
            icon={<ClassIcon sx={{ fontSize: 40 }} />}
            color="warning"
          />
        </Grid>
      </Grid>

      {/* Performance Metrics */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                  Attendance Rate
                </Typography>
                <AttendanceIcon color="success" />
              </Box>
              <Typography variant="h4" sx={{ fontWeight: 'bold', color: 'success.main', mb: 1 }}>
                {attendanceRate.toFixed(1)}%
              </Typography>
              <LinearProgress 
                variant="determinate" 
                value={Math.min(attendanceRate, 100)} 
                color="success"
                sx={{ height: 8, borderRadius: 4 }}
              />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                  Average Grade
                </Typography>
                <TrendingUpIcon color="info" />
              </Box>
              <Typography variant="h4" sx={{ fontWeight: 'bold', color: 'info.main', mb: 1 }}>
                {averageGrade.toFixed(1)}%
              </Typography>
              <LinearProgress 
                variant="determinate" 
                value={Math.min(averageGrade, 100)} 
                color="info"
                sx={{ height: 8, borderRadius: 4 }}
              />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent>
              <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
                <Typography variant="body2" color="text.secondary" sx={{ fontWeight: 500 }}>
                  Fee Collection
                </Typography>
                <PaymentIcon color="warning" />
              </Box>
              <Typography variant="h4" sx={{ fontWeight: 'bold', color: 'warning.main', mb: 1 }}>
                {feeCollectionRate.toFixed(1)}%
              </Typography>
              <LinearProgress 
                variant="determinate" 
                value={Math.min(feeCollectionRate, 100)} 
                color="warning"
                sx={{ height: 8, borderRadius: 4 }}
              />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Unpaid Fees"
            value={`$${totalUnpaidAmount.toFixed(2)}`}
            subtitle={`${unpaidFees.length} students`}
            icon={<WarningIcon sx={{ fontSize: 40 }} />}
            color="error"
          />
        </Grid>
      </Grid>

      {/* Recent Activities and Quick Stats */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" component="h2" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
                Recent Activities
              </Typography>
              <List>
                {recentActivities.map((activity, index) => (
                  <ListItem key={index} divider={index < recentActivities.length - 1}>
                    <ListItemIcon>
                      {activity.type === 'warning' ? (
                        <WarningIcon color="warning" />
                      ) : activity.type === 'success' ? (
                        <CheckCircleIcon color="success" />
                      ) : (
                        <TrendingUpIcon color="info" />
                      )}
                    </ListItemIcon>
                    <ListItemText
                      primary={activity.text}
                      secondary={activity.time}
                      primaryTypographyProps={{ fontWeight: 500 }}
                    />
                  </ListItem>
                ))}
              </List>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" component="h2" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
                Quick Overview
              </Typography>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="body1" sx={{ fontWeight: 500 }}>Active Enrollments</Typography>
                    <Chip label={totalEnrollments} color="primary" />
                  </Box>
                </Paper>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="body1" sx={{ fontWeight: 500 }}>Total Classrooms</Typography>
                    <Chip label={totalClassrooms} color="info" />
                  </Box>
                </Paper>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="body1" sx={{ fontWeight: 500 }}>Attendance Records</Typography>
                    <Chip label={attendance?.length || 0} color="success" />
                  </Box>
                </Paper>
                <Paper variant="outlined" sx={{ p: 2 }}>
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="body1" sx={{ fontWeight: 500 }}>Grade Records</Typography>
                    <Chip label={grades?.length || 0} color="warning" />
                  </Box>
                </Paper>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};