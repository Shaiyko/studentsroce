import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Alert
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon
} from '@mui/icons-material';
import { useData } from '../../context/DataContext';
import { ScheduleForm } from './ScheduleForm';

export const ScheduleList: React.FC = () => {
  const { 
    schedule, 
    subjects,
    teachers,
    classrooms,
    deleteSchedule 
  } = useData();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [dayFilter, setDayFilter] = useState('');
  const [openForm, setOpenForm] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<any>(null);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; schedule: any }>({
    open: false,
    schedule: null
  });
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success'
  });

  const getSubjectName = (id: number) => {
    return subjects.find(s => s.id === id)?.name || 'Unknown';
  };

  const getTeacherName = (id: number) => {
    const teacher = teachers.find(t => t.id === id);
    return teacher ? `${teacher.first_name} ${teacher.last_name}` : 'Unknown';
  };

  const getClassroomName = (id: number) => {
    return classrooms.find(c => c.id === id)?.name || 'Unknown';
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour24 = parseInt(hours);
    const hour12 = hour24 > 12 ? hour24 - 12 : hour24 === 0 ? 12 : hour24;
    const ampm = hour24 >= 12 ? 'PM' : 'AM';
    return `${hour12}:${minutes} ${ampm}`;
  };

  const filteredSchedule = schedule.filter(item => {
    const subjectName = getSubjectName(item.subject_id).toLowerCase();
    const teacherName = getTeacherName(item.teacher_id).toLowerCase();
    const classroomName = getClassroomName(item.classroom_id).toLowerCase();
    const search = searchTerm.toLowerCase();
    
    const matchesSearch = subjectName.includes(search) || teacherName.includes(search) || classroomName.includes(search);
    const matchesDay = !dayFilter || item.day_of_week === dayFilter;
    
    return matchesSearch && matchesDay;
  });

  const handleEdit = (scheduleItem: any) => {
    setEditingSchedule(scheduleItem);
    setOpenForm(true);
  };

  const handleDelete = (scheduleItem: any) => {
    setDeleteDialog({ open: true, schedule: scheduleItem });
  };

  const confirmDelete = () => {
    if (deleteDialog.schedule) {
      deleteSchedule(deleteDialog.schedule.id);
      setDeleteDialog({ open: false, schedule: null });
      setSnackbar({
        open: true,
        message: 'Schedule deleted successfully',
        severity: 'success'
      });
    }
  };

  const handleCloseForm = () => {
    setOpenForm(false);
    setEditingSchedule(null);
  };

  const handleFormSuccess = (message: string) => {
    setSnackbar({
      open: true,
      message,
      severity: 'success'
    });
    handleCloseForm();
  };

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Schedule Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpenForm(true)}
          sx={{ borderRadius: 2 }}
        >
          Add Schedule
        </Button>
      </Box>

      {/* Search and Filter */}
      <Card elevation={2} sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                placeholder="Search by subject, teacher, or classroom..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />
                }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Filter by Day</InputLabel>
                <Select
                  value={dayFilter}
                  label="Filter by Day"
                  onChange={(e) => setDayFilter(e.target.value)}
                >
                  <MenuItem value="">All Days</MenuItem>
                  {daysOfWeek.map(day => (
                    <MenuItem key={day} value={day}>
                      {day}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={2}>
              <Typography variant="body2" color="text.secondary">
                {filteredSchedule.length} schedules found
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Schedule Table */}
      <Card elevation={2}>
        <CardContent>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 'bold' }}>ID</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Subject</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Teacher</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Classroom</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Day</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Time</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredSchedule.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      <Typography color="text.secondary" sx={{ py: 4 }}>
                        No schedule found
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredSchedule
                    .sort((a, b) => {
                      const dayOrder = daysOfWeek.indexOf(a.day_of_week) - daysOfWeek.indexOf(b.day_of_week);
                      if (dayOrder !== 0) return dayOrder;
                      return a.start_time.localeCompare(b.start_time);
                    })
                    .map((item) => (
                      <TableRow key={item.id} hover>
                        <TableCell>
                          <Chip label={item.id} size="small" color="primary" />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                            {getSubjectName(item.subject_id)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" color="text.secondary">
                            {getTeacherName(item.teacher_id)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip 
                            label={getClassroomName(item.classroom_id)} 
                            size="small" 
                            color="info"
                            variant="outlined"
                          />
                        </TableCell>
                        <TableCell>
                          <Chip 
                            label={item.day_of_week} 
                            size="small" 
                            color="success"
                          />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                            {formatTime(item.start_time)} - {formatTime(item.end_time)}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <IconButton
                            size="small"
                            onClick={() => handleEdit(item)}
                            sx={{ mr: 1 }}
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton
                            size="small"
                            onClick={() => handleDelete(item)}
                            color="error"
                          >
                            <DeleteIcon />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Schedule Form Dialog */}
      <ScheduleForm
        open={openForm}
        onClose={handleCloseForm}
        schedule={editingSchedule}
        onSuccess={handleFormSuccess}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog({ open: false, schedule: null })}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this schedule entry?
          </Typography>
          {deleteDialog.schedule && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="body2">
                <strong>Subject:</strong> {getSubjectName(deleteDialog.schedule.subject_id)}
              </Typography>
              <Typography variant="body2">
                <strong>Teacher:</strong> {getTeacherName(deleteDialog.schedule.teacher_id)}
              </Typography>
              <Typography variant="body2">
                <strong>Time:</strong> {deleteDialog.schedule.day_of_week} {formatTime(deleteDialog.schedule.start_time)} - {formatTime(deleteDialog.schedule.end_time)}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog({ open: false, schedule: null })}>
            Cancel
          </Button>
          <Button onClick={confirmDelete} color="error" variant="contained">
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success/Error Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};