import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert
} from '@mui/material';
import { useData } from '../../context/DataContext';
import { Schedule } from '../../types';

interface ScheduleFormProps {
  open: boolean;
  onClose: () => void;
  schedule?: Schedule | null;
  onSuccess: (message: string) => void;
}

export const ScheduleForm: React.FC<ScheduleFormProps> = ({ open, onClose, schedule, onSuccess }) => {
  const { subjects, teachers, classrooms, addSchedule, updateSchedule } = useData();
  
  const [formData, setFormData] = useState({
    subject_id: '',
    teacher_id: '',
    classroom_id: '',
    day_of_week: '',
    start_time: '',
    end_time: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  useEffect(() => {
    if (schedule) {
      setFormData({
        subject_id: schedule.subject_id.toString(),
        teacher_id: schedule.teacher_id.toString(),
        classroom_id: schedule.classroom_id.toString(),
        day_of_week: schedule.day_of_week,
        start_time: schedule.start_time,
        end_time: schedule.end_time
      });
    } else {
      setFormData({
        subject_id: '',
        teacher_id: '',
        classroom_id: '',
        day_of_week: '',
        start_time: '',
        end_time: ''
      });
    }
    setErrors({});
  }, [schedule, open]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.subject_id) {
      newErrors.subject_id = 'Subject is required';
    }
    if (!formData.teacher_id) {
      newErrors.teacher_id = 'Teacher is required';
    }
    if (!formData.classroom_id) {
      newErrors.classroom_id = 'Classroom is required';
    }
    if (!formData.day_of_week) {
      newErrors.day_of_week = 'Day of week is required';
    }
    if (!formData.start_time) {
      newErrors.start_time = 'Start time is required';
    }
    if (!formData.end_time) {
      newErrors.end_time = 'End time is required';
    }
    if (formData.start_time && formData.end_time && formData.start_time >= formData.end_time) {
      newErrors.end_time = 'End time must be after start time';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const scheduleData = {
      subject_id: parseInt(formData.subject_id),
      teacher_id: parseInt(formData.teacher_id),
      classroom_id: parseInt(formData.classroom_id),
      day_of_week: formData.day_of_week as any,
      start_time: formData.start_time,
      end_time: formData.end_time
    };

    if (schedule) {
      updateSchedule(schedule.id, scheduleData);
      onSuccess('Schedule updated successfully');
    } else {
      addSchedule(scheduleData);
      onSuccess('Schedule added successfully');
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        {schedule ? 'Edit Schedule' : 'Add New Schedule'}
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={2} sx={{ mt: 1 }}>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.subject_id}>
              <InputLabel>Subject</InputLabel>
              <Select
                value={formData.subject_id}
                label="Subject"
                onChange={(e) => handleChange('subject_id', e.target.value)}
              >
                {subjects.map(subject => (
                  <MenuItem key={subject.id} value={subject.id.toString()}>
                    {subject.name}
                  </MenuItem>
                ))}
              </Select>
              {errors.subject_id && (
                <Alert severity="error" sx={{ mt: 1 }}>
                  {errors.subject_id}
                </Alert>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.teacher_id}>
              <InputLabel>Teacher</InputLabel>
              <Select
                value={formData.teacher_id}
                label="Teacher"
                onChange={(e) => handleChange('teacher_id', e.target.value)}
              >
                {teachers.map(teacher => (
                  <MenuItem key={teacher.id} value={teacher.id.toString()}>
                    {teacher.first_name} {teacher.last_name}
                  </MenuItem>
                ))}
              </Select>
              {errors.teacher_id && (
                <Alert severity="error" sx={{ mt: 1 }}>
                  {errors.teacher_id}
                </Alert>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.classroom_id}>
              <InputLabel>Classroom</InputLabel>
              <Select
                value={formData.classroom_id}
                label="Classroom"
                onChange={(e) => handleChange('classroom_id', e.target.value)}
              >
                {classrooms.map(classroom => (
                  <MenuItem key={classroom.id} value={classroom.id.toString()}>
                    {classroom.name}
                  </MenuItem>
                ))}
              </Select>
              {errors.classroom_id && (
                <Alert severity="error" sx={{ mt: 1 }}>
                  {errors.classroom_id}
                </Alert>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.day_of_week}>
              <InputLabel>Day of Week</InputLabel>
              <Select
                value={formData.day_of_week}
                label="Day of Week"
                onChange={(e) => handleChange('day_of_week', e.target.value)}
              >
                {daysOfWeek.map(day => (
                  <MenuItem key={day} value={day}>
                    {day}
                  </MenuItem>
                ))}
              </Select>
              {errors.day_of_week && (
                <Alert severity="error" sx={{ mt: 1 }}>
                  {errors.day_of_week}
                </Alert>
              )}
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Start Time"
              type="time"
              value={formData.start_time}
              onChange={(e) => handleChange('start_time', e.target.value)}
              InputLabelProps={{ shrink: true }}
              error={!!errors.start_time}
              helperText={errors.start_time}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="End Time"
              type="time"
              value={formData.end_time}
              onChange={(e) => handleChange('end_time', e.target.value)}
              InputLabelProps={{ shrink: true }}
              error={!!errors.end_time}
              helperText={errors.end_time}
            />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ p: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">
          {schedule ? 'Update' : 'Add'} Schedule
        </Button>
      </DialogActions>
    </Dialog>
  );
};