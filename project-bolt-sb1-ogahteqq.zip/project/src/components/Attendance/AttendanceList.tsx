import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Alert
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon
} from '@mui/icons-material';
import { useData } from '../../context/DataContext';
import { AttendanceForm } from './AttendanceForm';

export const AttendanceList: React.FC = () => {
  const { 
    attendance, 
    students,
    subjects,
    schedule,
    deleteAttendance 
  } = useData();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [openForm, setOpenForm] = useState(false);
  const [editingAttendance, setEditingAttendance] = useState<any>(null);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; attendance: any }>({
    open: false,
    attendance: null
  });
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success'
  });

  const getStudentName = (id: number) => {
    const student = students.find(s => s.id === id);
    return student ? `${student.first_name} ${student.last_name}` : 'Unknown';
  };

  const getSubjectName = (id: number) => {
    return subjects.find(s => s.id === id)?.name || 'Unknown';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Present':
        return 'success';
      case 'Absent':
        return 'error';
      case 'Late':
        return 'warning';
      case 'Excused':
        return 'info';
      default:
        return 'default';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const filteredAttendance = attendance.filter(item => {
    const studentName = getStudentName(item.student_id).toLowerCase();
    const subjectName = getSubjectName(item.subject_id).toLowerCase();
    const search = searchTerm.toLowerCase();
    
    const matchesSearch = studentName.includes(search) || subjectName.includes(search);
    const matchesStatus = !statusFilter || item.status === statusFilter;
    const matchesDate = !dateFilter || item.date === dateFilter;
    
    return matchesSearch && matchesStatus && matchesDate;
  });

  const handleEdit = (attendanceItem: any) => {
    setEditingAttendance(attendanceItem);
    setOpenForm(true);
  };

  const handleDelete = (attendanceItem: any) => {
    setDeleteDialog({ open: true, attendance: attendanceItem });
  };

  const confirmDelete = () => {
    if (deleteDialog.attendance) {
      deleteAttendance(deleteDialog.attendance.id);
      setDeleteDialog({ open: false, attendance: null });
      setSnackbar({
        open: true,
        message: 'Attendance record deleted successfully',
        severity: 'success'
      });
    }
  };

  const handleCloseForm = () => {
    setOpenForm(false);
    setEditingAttendance(null);
  };

  const handleFormSuccess = (message: string) => {
    setSnackbar({
      open: true,
      message,
      severity: 'success'
    });
    handleCloseForm();
  };

  const statusOptions = ['Present', 'Absent', 'Late', 'Excused'];

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Attendance Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpenForm(true)}
          sx={{ borderRadius: 2 }}
        >
          Record Attendance
        </Button>
      </Box>

      {/* Search and Filter */}
      <Card elevation={2} sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                placeholder="Search by student or subject..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />
                }}
              />
            </Grid>
            <Grid item xs={12} md={3}>
              <FormControl fullWidth>
                <InputLabel>Filter by Status</InputLabel>
                <Select
                  value={statusFilter}
                  label="Filter by Status"
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <MenuItem value="">All Status</MenuItem>
                  {statusOptions.map(status => (
                    <MenuItem key={status} value={status}>
                      {status}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={3}>
              <TextField
                fullWidth
                label="Filter by Date"
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12} md={2}>
              <Typography variant="body2" color="text.secondary">
                {filteredAttendance.length} records found
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Attendance Table */}
      <Card elevation={2}>
        <CardContent>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 'bold' }}>ID</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Student</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Subject</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Date</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Status</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredAttendance.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} align="center">
                      <Typography color="text.secondary" sx={{ py: 4 }}>
                        No attendance records found
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredAttendance
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map((item) => (
                      <TableRow key={item.id} hover>
                        <TableCell>
                          <Chip label={item.id} size="small" color="primary" />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                            {getStudentName(item.student_id)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                            {getSubjectName(item.subject_id)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {formatDate(item.date)}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <Chip
                            label={item.status}
                            color={getStatusColor(item.status)}
                            size="small"
                            sx={{ fontWeight: 'bold' }}
                          />
                        </TableCell>
                        <TableCell align="center">
                          <IconButton
                            size="small"
                            onClick={() => handleEdit(item)}
                            sx={{ mr: 1 }}
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton
                            size="small"
                            onClick={() => handleDelete(item)}
                            color="error"
                          >
                            <DeleteIcon />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Attendance Form Dialog */}
      <AttendanceForm
        open={openForm}
        onClose={handleCloseForm}
        attendance={editingAttendance}
        onSuccess={handleFormSuccess}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog({ open: false, attendance: null })}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this attendance record?
          </Typography>
          {deleteDialog.attendance && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="body2">
                <strong>Student:</strong> {getStudentName(deleteDialog.attendance.student_id)}
              </Typography>
              <Typography variant="body2">
                <strong>Subject:</strong> {getSubjectName(deleteDialog.attendance.subject_id)}
              </Typography>
              <Typography variant="body2">
                <strong>Date:</strong> {formatDate(deleteDialog.attendance.date)}
              </Typography>
              <Typography variant="body2">
                <strong>Status:</strong> {deleteDialog.attendance.status}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog({ open: false, attendance: null })}>
            Cancel
          </Button>
          <Button onClick={confirmDelete} color="error" variant="contained">
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success/Error Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};