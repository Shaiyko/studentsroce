import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  Typography,
  Box
} from '@mui/material';
import { useData } from '../../context/DataContext';
import { Attendance } from '../../types';

interface AttendanceFormProps {
  open: boolean;
  onClose: () => void;
  attendance?: Attendance | null;
  onSuccess: (message: string) => void;
}

export const AttendanceForm: React.FC<AttendanceFormProps> = ({ open, onClose, attendance, onSuccess }) => {
  const { students, subjects, schedule, addAttendance, updateAttendance } = useData();
  
  const [formData, setFormData] = useState({
    student_id: '',
    subject_id: '',
    schedule_id: '',
    date: '',
    status: 'Present' as 'Present' | 'Absent' | 'Late' | 'Excused'
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  const statusOptions: Array<'Present' | 'Absent' | 'Late' | 'Excused'> = ['Present', 'Absent', 'Late', 'Excused'];

  useEffect(() => {
    if (attendance) {
      setFormData({
        student_id: attendance.student_id.toString(),
        subject_id: attendance.subject_id.toString(),
        schedule_id: attendance.schedule_id.toString(),
        date: attendance.date,
        status: attendance.status
      });
    } else {
      setFormData({
        student_id: '',
        subject_id: '',
        schedule_id: '',
        date: new Date().toISOString().split('T')[0],
        status: 'Present'
      });
    }
    setErrors({});
  }, [attendance, open]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.student_id) {
      newErrors.student_id = 'Student is required';
    }
    if (!formData.subject_id) {
      newErrors.subject_id = 'Subject is required';
    }
    if (!formData.schedule_id) {
      newErrors.schedule_id = 'Schedule is required';
    }
    if (!formData.date) {
      newErrors.date = 'Date is required';
    }
    if (!formData.status) {
      newErrors.status = 'Status is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const attendanceData = {
      student_id: parseInt(formData.student_id),
      subject_id: parseInt(formData.subject_id),
      schedule_id: parseInt(formData.schedule_id),
      date: formData.date,
      status: formData.status
    };

    if (attendance) {
      updateAttendance(attendance.id, attendanceData);
      onSuccess('Attendance updated successfully');
    } else {
      addAttendance(attendanceData);
      onSuccess('Attendance recorded successfully');
    }
  };

  const availableSchedule = schedule.filter(s => 
    !formData.subject_id || s.subject_id.toString() === formData.subject_id
  );

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        {attendance ? 'Edit Attendance' : 'Record Attendance'}
      </DialogTitle>
      <DialogContent>
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            {attendance ? 'Update the attendance record.' : 'Record student attendance for a specific class.'}
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.student_id}>
                <InputLabel>Student</InputLabel>
                <Select
                  value={formData.student_id}
                  label="Student"
                  onChange={(e) => handleChange('student_id', e.target.value)}
                >
                  {students.map(student => (
                    <MenuItem key={student.id} value={student.id.toString()}>
                      {student.first_name} {student.last_name}
                    </MenuItem>
                  ))}
                </Select>
                {errors.student_id && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.student_id}
                  </Alert>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.subject_id}>
                <InputLabel>Subject</InputLabel>
                <Select
                  value={formData.subject_id}
                  label="Subject"
                  onChange={(e) => {
                    handleChange('subject_id', e.target.value);
                    handleChange('schedule_id', ''); // Reset schedule when subject changes
                  }}
                >
                  {subjects.map(subject => (
                    <MenuItem key={subject.id} value={subject.id.toString()}>
                      {subject.name}
                    </MenuItem>
                  ))}
                </Select>
                {errors.subject_id && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.subject_id}
                  </Alert>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.schedule_id}>
                <InputLabel>Schedule</InputLabel>
                <Select
                  value={formData.schedule_id}
                  label="Schedule"
                  onChange={(e) => handleChange('schedule_id', e.target.value)}
                  disabled={!formData.subject_id}
                >
                  {availableSchedule.map(scheduleItem => (
                    <MenuItem key={scheduleItem.id} value={scheduleItem.id.toString()}>
                      {scheduleItem.day_of_week} {scheduleItem.start_time} - {scheduleItem.end_time}
                    </MenuItem>
                  ))}
                </Select>
                {errors.schedule_id && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.schedule_id}
                  </Alert>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Date"
                type="date"
                value={formData.date}
                onChange={(e) => handleChange('date', e.target.value)}
                InputLabelProps={{ shrink: true }}
                error={!!errors.date}
                helperText={errors.date}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth error={!!errors.status}>
                <InputLabel>Status</InputLabel>
                <Select
                  value={formData.status}
                  label="Status"
                  onChange={(e) => handleChange('status', e.target.value)}
                >
                  {statusOptions.map(status => (
                    <MenuItem key={status} value={status}>
                      {status}
                    </MenuItem>
                  ))}
                </Select>
                {errors.status && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.status}
                  </Alert>
                )}
              </FormControl>
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
      <DialogActions sx={{ p: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">
          {attendance ? 'Update' : 'Record'} Attendance
        </Button>
      </DialogActions>
    </Dialog>
  );
};