import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  Typography,
  Box
} from '@mui/material';
import { useData } from '../../context/DataContext';

interface EnrollmentFormProps {
  open: boolean;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

export const EnrollmentForm: React.FC<EnrollmentFormProps> = ({ open, onClose, onSuccess }) => {
  const { students, subjects, enrollment, addEnrollment } = useData();
  
  const [formData, setFormData] = useState({
    student_id: '',
    subject_id: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (open) {
      setFormData({
        student_id: '',
        subject_id: ''
      });
      setErrors({});
    }
  }, [open]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.student_id) {
      newErrors.student_id = 'Student is required';
    }
    if (!formData.subject_id) {
      newErrors.subject_id = 'Subject is required';
    }

    // Check if enrollment already exists
    if (formData.student_id && formData.subject_id) {
      const existingEnrollment = enrollment.find(e => 
        e.student_id === parseInt(formData.student_id) && 
        e.subject_id === parseInt(formData.subject_id)
      );
      if (existingEnrollment) {
        newErrors.subject_id = 'Student is already enrolled in this subject';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const enrollmentData = {
      student_id: parseInt(formData.student_id),
      subject_id: parseInt(formData.subject_id)
    };

    addEnrollment(enrollmentData);
    onSuccess('Student enrolled successfully');
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        Enroll Student in Subject
      </DialogTitle>
      <DialogContent>
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Select a student and subject to create a new enrollment.
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.student_id}>
                <InputLabel>Student</InputLabel>
                <Select
                  value={formData.student_id}
                  label="Student"
                  onChange={(e) => handleChange('student_id', e.target.value)}
                >
                  {students.map(student => (
                    <MenuItem key={student.id} value={student.id.toString()}>
                      {student.first_name} {student.last_name} (ID: {student.id})
                    </MenuItem>
                  ))}
                </Select>
                {errors.student_id && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.student_id}
                  </Alert>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.subject_id}>
                <InputLabel>Subject</InputLabel>
                <Select
                  value={formData.subject_id}
                  label="Subject"
                  onChange={(e) => handleChange('subject_id', e.target.value)}
                >
                  {subjects.map(subject => (
                    <MenuItem key={subject.id} value={subject.id.toString()}>
                      {subject.name}
                    </MenuItem>
                  ))}
                </Select>
                {errors.subject_id && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.subject_id}
                  </Alert>
                )}
              </FormControl>
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
      <DialogActions sx={{ p: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">
          Enroll Student
        </Button>
      </DialogActions>
    </Dialog>
  );
};