import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Grid
} from '@mui/material';
import { useData } from '../../context/DataContext';
import { Department } from '../../types';

interface DepartmentFormProps {
  open: boolean;
  onClose: () => void;
  department?: Department | null;
  onSuccess: (message: string) => void;
}

export const DepartmentForm: React.FC<DepartmentFormProps> = ({ open, onClose, department, onSuccess }) => {
  const { addDepartment, updateDepartment } = useData();
  
  const [formData, setFormData] = useState({
    name: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (department) {
      setFormData({
        name: department.name
      });
    } else {
      setFormData({
        name: ''
      });
    }
    setErrors({});
  }, [department, open]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Department name is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const departmentData = {
      name: formData.name.trim()
    };

    if (department) {
      updateDepartment(department.id, departmentData);
      onSuccess('Department updated successfully');
    } else {
      addDepartment(departmentData);
      onSuccess('Department added successfully');
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        {department ? 'Edit Department' : 'Add New Department'}
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={2} sx={{ mt: 1 }}>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Department Name"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              error={!!errors.name}
              helperText={errors.name}
              placeholder="e.g., Computer Science, Mathematics"
            />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ p: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">
          {department ? 'Update' : 'Add'} Department
        </Button>
      </DialogActions>
    </Dialog>
  );
};