import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  Snackbar,
  Alert
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon
} from '@mui/icons-material';
import { useData } from '../../context/DataContext';
import { DepartmentForm } from './DepartmentForm';

export const DepartmentList: React.FC = () => {
  const { 
    departments, 
    students,
    teachers,
    subjects,
    classrooms,
    deleteDepartment 
  } = useData();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [openForm, setOpenForm] = useState(false);
  const [editingDepartment, setEditingDepartment] = useState<any>(null);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; department: any }>({
    open: false,
    department: null
  });
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success'
  });

  const getStudentCount = (departmentId: number) => {
    return students.filter(s => s.department_id === departmentId).length;
  };

  const getTeacherCount = (departmentId: number) => {
    return teachers.filter(t => t.department_id === departmentId).length;
  };

  const getSubjectCount = (departmentId: number) => {
    return subjects.filter(s => s.department_id === departmentId).length;
  };

  const getClassroomCount = (departmentId: number) => {
    return classrooms.filter(c => c.department_id === departmentId).length;
  };

  const filteredDepartments = departments.filter(department => 
    department.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleEdit = (department: any) => {
    setEditingDepartment(department);
    setOpenForm(true);
  };

  const handleDelete = (department: any) => {
    setDeleteDialog({ open: true, department });
  };

  const confirmDelete = () => {
    if (deleteDialog.department) {
      const studentCount = getStudentCount(deleteDialog.department.id);
      const teacherCount = getTeacherCount(deleteDialog.department.id);
      
      if (studentCount > 0 || teacherCount > 0) {
        setSnackbar({
          open: true,
          message: 'Cannot delete department with existing students or teachers',
          severity: 'error'
        });
      } else {
        deleteDepartment(deleteDialog.department.id);
        setSnackbar({
          open: true,
          message: 'Department deleted successfully',
          severity: 'success'
        });
      }
      setDeleteDialog({ open: false, department: null });
    }
  };

  const handleCloseForm = () => {
    setOpenForm(false);
    setEditingDepartment(null);
  };

  const handleFormSuccess = (message: string) => {
    setSnackbar({
      open: true,
      message,
      severity: 'success'
    });
    handleCloseForm();
  };

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Departments Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpenForm(true)}
          sx={{ borderRadius: 2 }}
        >
          Add Department
        </Button>
      </Box>

      {/* Search */}
      <Card elevation={2} sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={8}>
              <TextField
                fullWidth
                placeholder="Search departments..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />
                }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="text.secondary">
                {filteredDepartments.length} departments found
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Departments Table */}
      <Card elevation={2}>
        <CardContent>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 'bold' }}>ID</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Department Name</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Students</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Teachers</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Subjects</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Classrooms</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredDepartments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      <Typography color="text.secondary" sx={{ py: 4 }}>
                        No departments found
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredDepartments.map((department) => (
                    <TableRow key={department.id} hover>
                      <TableCell>
                        <Chip label={department.id} size="small" color="primary" />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                          {department.name}
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <Chip 
                          label={getStudentCount(department.id)} 
                          size="small" 
                          color="info"
                        />
                      </TableCell>
                      <TableCell align="center">
                        <Chip 
                          label={getTeacherCount(department.id)} 
                          size="small" 
                          color="success"
                        />
                      </TableCell>
                      <TableCell align="center">
                        <Chip 
                          label={getSubjectCount(department.id)} 
                          size="small" 
                          color="warning"
                        />
                      </TableCell>
                      <TableCell align="center">
                        <Chip 
                          label={getClassroomCount(department.id)} 
                          size="small" 
                          color="secondary"
                        />
                      </TableCell>
                      <TableCell align="center">
                        <IconButton
                          size="small"
                          onClick={() => handleEdit(department)}
                          sx={{ mr: 1 }}
                        >
                          <EditIcon />
                        </IconButton>
                        <IconButton
                          size="small"
                          onClick={() => handleDelete(department)}
                          color="error"
                        >
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Department Form Dialog */}
      <DepartmentForm
        open={openForm}
        onClose={handleCloseForm}
        department={editingDepartment}
        onSuccess={handleFormSuccess}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog({ open: false, department: null })}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete department "{deleteDialog.department?.name}"?
          </Typography>
          {deleteDialog.department && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="body2" color="text.secondary">
                This department has:
              </Typography>
              <Typography variant="body2">
                • {getStudentCount(deleteDialog.department.id)} students
              </Typography>
              <Typography variant="body2">
                • {getTeacherCount(deleteDialog.department.id)} teachers
              </Typography>
              <Typography variant="body2">
                • {getSubjectCount(deleteDialog.department.id)} subjects
              </Typography>
              <Typography variant="body2">
                • {getClassroomCount(deleteDialog.department.id)} classrooms
              </Typography>
              {(getStudentCount(deleteDialog.department.id) > 0 || getTeacherCount(deleteDialog.department.id) > 0) && (
                <Alert severity="warning" sx={{ mt: 2 }}>
                  Cannot delete department with existing students or teachers
                </Alert>
              )}
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog({ open: false, department: null })}>
            Cancel
          </Button>
          <Button 
            onClick={confirmDelete} 
            color="error" 
            variant="contained"
            disabled={deleteDialog.department && (getStudentCount(deleteDialog.department.id) > 0 || getTeacherCount(deleteDialog.department.id) > 0)}
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success/Error Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};