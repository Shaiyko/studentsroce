import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert
} from '@mui/material';
import { useData } from '../../context/DataContext';
import { Classroom } from '../../types';

interface ClassroomFormProps {
  open: boolean;
  onClose: () => void;
  classroom?: Classroom | null;
  onSuccess: (message: string) => void;
}

export const ClassroomForm: React.FC<ClassroomFormProps> = ({ open, onClose, classroom, onSuccess }) => {
  const { departments, addClassroom, updateClassroom } = useData();
  
  const [formData, setFormData] = useState({
    name: '',
    capacity: '',
    department_id: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (classroom) {
      setFormData({
        name: classroom.name,
        capacity: classroom.capacity.toString(),
        department_id: classroom.department_id.toString()
      });
    } else {
      setFormData({
        name: '',
        capacity: '',
        department_id: ''
      });
    }
    setErrors({});
  }, [classroom, open]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Classroom name is required';
    }
    if (!formData.capacity || parseInt(formData.capacity) <= 0) {
      newErrors.capacity = 'Valid capacity is required';
    }
    if (!formData.department_id) {
      newErrors.department_id = 'Department is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const classroomData = {
      name: formData.name.trim(),
      capacity: parseInt(formData.capacity),
      department_id: parseInt(formData.department_id)
    };

    if (classroom) {
      updateClassroom(classroom.id, classroomData);
      onSuccess('Classroom updated successfully');
    } else {
      addClassroom(classroomData);
      onSuccess('Classroom added successfully');
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        {classroom ? 'Edit Classroom' : 'Add New Classroom'}
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={2} sx={{ mt: 1 }}>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Classroom Name"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              error={!!errors.name}
              helperText={errors.name}
              placeholder="e.g., CS-101, MATH-201"
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Capacity"
              type="number"
              value={formData.capacity}
              onChange={(e) => handleChange('capacity', e.target.value)}
              error={!!errors.capacity}
              helperText={errors.capacity}
              inputProps={{ min: 1 }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth error={!!errors.department_id}>
              <InputLabel>Department</InputLabel>
              <Select
                value={formData.department_id}
                label="Department"
                onChange={(e) => handleChange('department_id', e.target.value)}
              >
                {departments.map(dept => (
                  <MenuItem key={dept.id} value={dept.id.toString()}>
                    {dept.name}
                  </MenuItem>
                ))}
              </Select>
              {errors.department_id && (
                <Alert severity="error" sx={{ mt: 1 }}>
                  {errors.department_id}
                </Alert>
              )}
            </FormControl>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions sx={{ p: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">
          {classroom ? 'Update' : 'Add'} Classroom
        </Button>
      </DialogActions>
    </Dialog>
  );
};