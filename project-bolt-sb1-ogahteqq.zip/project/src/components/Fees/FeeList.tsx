import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Snackbar,
  Alert
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon
} from '@mui/icons-material';
import { useData } from '../../context/DataContext';
import { FeeForm } from './FeeForm';

export const FeeList: React.FC = () => {
  const { 
    fees, 
    students,
    deleteFee 
  } = useData();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [openForm, setOpenForm] = useState(false);
  const [editingFee, setEditingFee] = useState<any>(null);
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; fee: any }>({
    open: false,
    fee: null
  });
  const [snackbar, setSnackbar] = useState<{ open: boolean; message: string; severity: 'success' | 'error' }>({
    open: false,
    message: '',
    severity: 'success'
  });

  const getStudentName = (id: number) => {
    const student = students.find(s => s.id === id);
    return student ? `${student.first_name} ${student.last_name}` : 'Unknown';
  };

  const getStatusColor = (status: string) => {
    return status === 'Paid' ? 'success' : 'error';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const isOverdue = (dueDateString: string, status: string) => {
    if (status === 'Paid') return false;
    const dueDate = new Date(dueDateString);
    const today = new Date();
    return dueDate < today;
  };

  const filteredFees = fees.filter(fee => {
    const studentName = getStudentName(fee.student_id).toLowerCase();
    const search = searchTerm.toLowerCase();
    
    const matchesSearch = studentName.includes(search);
    const matchesStatus = !statusFilter || fee.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const handleEdit = (fee: any) => {
    setEditingFee(fee);
    setOpenForm(true);
  };

  const handleDelete = (fee: any) => {
    setDeleteDialog({ open: true, fee });
  };

  const confirmDelete = () => {
    if (deleteDialog.fee) {
      deleteFee(deleteDialog.fee.id);
      setDeleteDialog({ open: false, fee: null });
      setSnackbar({
        open: true,
        message: 'Fee record deleted successfully',
        severity: 'success'
      });
    }
  };

  const handleCloseForm = () => {
    setOpenForm(false);
    setEditingFee(null);
  };

  const handleFormSuccess = (message: string) => {
    setSnackbar({
      open: true,
      message,
      severity: 'success'
    });
    handleCloseForm();
  };

  const statusOptions = ['Paid', 'Unpaid'];

  // Calculate totals
  const totalAmount = fees.reduce((sum, fee) => sum + fee.amount, 0);
  const paidAmount = fees.filter(f => f.status === 'Paid').reduce((sum, fee) => sum + fee.amount, 0);
  const unpaidAmount = fees.filter(f => f.status === 'Unpaid').reduce((sum, fee) => sum + fee.amount, 0);
  const overdueAmount = fees.filter(f => f.status === 'Unpaid' && isOverdue(f.due_date, f.status)).reduce((sum, fee) => sum + fee.amount, 0);

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1" sx={{ fontWeight: 'bold' }}>
          Fees Management
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setOpenForm(true)}
          sx={{ borderRadius: 2 }}
        >
          Add Fee Record
        </Button>
      </Box>

      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="primary.main" sx={{ fontWeight: 'bold' }}>
                {formatCurrency(totalAmount)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Total Fees
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="success.main" sx={{ fontWeight: 'bold' }}>
                {formatCurrency(paidAmount)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Paid
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="error.main" sx={{ fontWeight: 'bold' }}>
                {formatCurrency(unpaidAmount)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Outstanding
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="warning.main" sx={{ fontWeight: 'bold' }}>
                {formatCurrency(overdueAmount)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Overdue
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Search and Filter */}
      <Card elevation={2} sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                placeholder="Search by student name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />
                }}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Filter by Status</InputLabel>
                <Select
                  value={statusFilter}
                  label="Filter by Status"
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <MenuItem value="">All Status</MenuItem>
                  {statusOptions.map(status => (
                    <MenuItem key={status} value={status}>
                      {status}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={2}>
              <Typography variant="body2" color="text.secondary">
                {filteredFees.length} records found
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Fees Table */}
      <Card elevation={2}>
        <CardContent>
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 'bold' }}>ID</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Student</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Amount</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Due Date</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Status</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Remarks</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredFees.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} align="center">
                      <Typography color="text.secondary" sx={{ py: 4 }}>
                        No fee records found
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredFees
                    .sort((a, b) => new Date(b.due_date).getTime() - new Date(a.due_date).getTime())
                    .map((fee) => (
                      <TableRow 
                        key={fee.id} 
                        hover
                        sx={{
                          backgroundColor: isOverdue(fee.due_date, fee.status) 
                            ? 'error.light' 
                            : 'inherit'
                        }}
                      >
                        <TableCell>
                          <Chip label={fee.id} size="small" color="primary" />
                        </TableCell>
                        <TableCell>
                          <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                            {getStudentName(fee.student_id)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography 
                            variant="h6" 
                            sx={{ 
                              fontWeight: 'bold',
                              color: fee.status === 'Paid' ? 'success.main' : 'error.main'
                            }}
                          >
                            {formatCurrency(fee.amount)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2">
                            {formatDate(fee.due_date)}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <Chip
                            label={fee.status}
                            color={getStatusColor(fee.status)}
                            size="small"
                            sx={{ fontWeight: 'bold' }}
                          />
                        </TableCell>
                        <TableCell align="center">
                          {isOverdue(fee.due_date, fee.status) && (
                            <Chip
                              label="OVERDUE"
                              color="error"
                              size="small"
                              variant="outlined"
                              sx={{ fontWeight: 'bold' }}
                            />
                          )}
                        </TableCell>
                        <TableCell align="center">
                          <IconButton
                            size="small"
                            onClick={() => handleEdit(fee)}
                            sx={{ mr: 1 }}
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton
                            size="small"
                            onClick={() => handleDelete(fee)}
                            color="error"
                          >
                            <DeleteIcon />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Fee Form Dialog */}
      <FeeForm
        open={openForm}
        onClose={handleCloseForm}
        fee={editingFee}
        onSuccess={handleFormSuccess}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialog.open} onClose={() => setDeleteDialog({ open: false, fee: null })}>
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete this fee record?
          </Typography>
          {deleteDialog.fee && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="body2">
                <strong>Student:</strong> {getStudentName(deleteDialog.fee.student_id)}
              </Typography>
              <Typography variant="body2">
                <strong>Amount:</strong> {formatCurrency(deleteDialog.fee.amount)}
              </Typography>
              <Typography variant="body2">
                <strong>Due Date:</strong> {formatDate(deleteDialog.fee.due_date)}
              </Typography>
              <Typography variant="body2">
                <strong>Status:</strong> {deleteDialog.fee.status}
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog({ open: false, fee: null })}>
            Cancel
          </Button>
          <Button onClick={confirmDelete} color="error" variant="contained">
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success/Error Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};