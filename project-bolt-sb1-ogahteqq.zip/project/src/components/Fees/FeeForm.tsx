import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  Typography,
  Box
} from '@mui/material';
import { useData } from '../../context/DataContext';
import { Fee } from '../../types';

interface FeeFormProps {
  open: boolean;
  onClose: () => void;
  fee?: Fee | null;
  onSuccess: (message: string) => void;
}

export const FeeForm: React.FC<FeeFormProps> = ({ open, onClose, fee, onSuccess }) => {
  const { students, addFee, updateFee } = useData();
  
  const [formData, setFormData] = useState({
    student_id: '',
    amount: '',
    due_date: '',
    status: 'Unpaid' as 'Paid' | 'Unpaid'
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});

  const statusOptions: Array<'Paid' | 'Unpaid'> = ['Paid', 'Unpaid'];

  useEffect(() => {
    if (fee) {
      setFormData({
        student_id: fee.student_id.toString(),
        amount: fee.amount.toString(),
        due_date: fee.due_date,
        status: fee.status
      });
    } else {
      setFormData({
        student_id: '',
        amount: '',
        due_date: '',
        status: 'Unpaid'
      });
    }
    setErrors({});
  }, [fee, open]);

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.student_id) {
      newErrors.student_id = 'Student is required';
    }
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Valid amount is required';
    }
    if (!formData.due_date) {
      newErrors.due_date = 'Due date is required';
    }
    if (!formData.status) {
      newErrors.status = 'Status is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const feeData = {
      student_id: parseInt(formData.student_id),
      amount: parseFloat(formData.amount),
      due_date: formData.due_date,
      status: formData.status
    };

    if (fee) {
      updateFee(fee.id, feeData);
      onSuccess('Fee record updated successfully');
    } else {
      addFee(feeData);
      onSuccess('Fee record added successfully');
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ fontWeight: 'bold' }}>
        {fee ? 'Edit Fee Record' : 'Add New Fee Record'}
      </DialogTitle>
      <DialogContent>
        <Box sx={{ mt: 2 }}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            {fee ? 'Update the fee record information.' : 'Create a new fee record for a student.'}
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.student_id}>
                <InputLabel>Student</InputLabel>
                <Select
                  value={formData.student_id}
                  label="Student"
                  onChange={(e) => handleChange('student_id', e.target.value)}
                >
                  {students.map(student => (
                    <MenuItem key={student.id} value={student.id.toString()}>
                      {student.first_name} {student.last_name}
                    </MenuItem>
                  ))}
                </Select>
                {errors.student_id && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.student_id}
                  </Alert>
                )}
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Amount"
                type="number"
                value={formData.amount}
                onChange={(e) => handleChange('amount', e.target.value)}
                error={!!errors.amount}
                helperText={errors.amount}
                inputProps={{ min: 0, step: 0.01 }}
                InputProps={{
                  startAdornment: <Typography sx={{ mr: 1 }}>$</Typography>
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Due Date"
                type="date"
                value={formData.due_date}
                onChange={(e) => handleChange('due_date', e.target.value)}
                InputLabelProps={{ shrink: true }}
                error={!!errors.due_date}
                helperText={errors.due_date}
              />
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth error={!!errors.status}>
                <InputLabel>Status</InputLabel>
                <Select
                  value={formData.status}
                  label="Status"
                  onChange={(e) => handleChange('status', e.target.value)}
                >
                  {statusOptions.map(status => (
                    <MenuItem key={status} value={status}>
                      {status}
                    </MenuItem>
                  ))}
                </Select>
                {errors.status && (
                  <Alert severity="error" sx={{ mt: 1 }}>
                    {errors.status}
                  </Alert>
                )}
              </FormControl>
            </Grid>
          </Grid>
        </Box>
      </DialogContent>
      <DialogActions sx={{ p: 3 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} variant="contained">
          {fee ? 'Update' : 'Add'} Fee Record
        </Button>
      </DialogActions>
    </Dialog>
  );
};