import React, { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Box,
  TextField,
  Grid,
  Select,
  MenuItem,
  FormControl,
  InputLabel
} from '@mui/material';
import { PieChart } from '@mui/x-charts/PieChart';
import { useStudent } from '../context/StudentContext';
import { useData } from '../../../context/DataContext';

export const AttendanceView: React.FC = () => {
  const { studentData } = useStudent();
  const { subjects } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');

  if (!studentData) {
    return (
      <Typography variant="h6" color="error">
        No student data available
      </Typography>
    );
  }

  const getSubjectName = (subjectId: number) => {
    return subjects.find(s => s.id === subjectId)?.name || 'Unknown Subject';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Present':
        return 'success';
      case 'Absent':
        return 'error';
      case 'Late':
        return 'warning';
      case 'Excused':
        return 'info';
      default:
        return 'default';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const filteredAttendance = studentData.attendance.filter(record => {
    const subjectName = getSubjectName(record.subject_id).toLowerCase();
    const search = searchTerm.toLowerCase();
    const statusMatch = statusFilter === 'All' || record.status === statusFilter;
    
    return subjectName.includes(search) && statusMatch;
  });

  // Calculate attendance statistics
  const attendanceStats = {
    Present: studentData.attendance.filter(a => a.status === 'Present').length,
    Absent: studentData.attendance.filter(a => a.status === 'Absent').length,
    Late: studentData.attendance.filter(a => a.status === 'Late').length,
    Excused: studentData.attendance.filter(a => a.status === 'Excused').length,
  };

  const totalClasses = studentData.attendance.length;
  const attendanceRate = totalClasses > 0 
    ? ((attendanceStats.Present + attendanceStats.Late) / totalClasses * 100)
    : 0;

  const pieData = [
    { id: 0, value: attendanceStats.Present, label: 'Present', color: '#4caf50' },
    { id: 1, value: attendanceStats.Absent, label: 'Absent', color: '#f44336' },
    { id: 2, value: attendanceStats.Late, label: 'Late', color: '#ff9800' },
    { id: 3, value: attendanceStats.Excused, label: 'Excused', color: '#2196f3' },
  ].filter(item => item.value > 0);

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
        Attendance Record
      </Typography>

      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h3" color="primary.main" sx={{ fontWeight: 'bold' }}>
                {attendanceRate.toFixed(1)}%
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Attendance Rate
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h3" color="success.main" sx={{ fontWeight: 'bold' }}>
                {attendanceStats.Present}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Present
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h3" color="error.main" sx={{ fontWeight: 'bold' }}>
                {attendanceStats.Absent}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Absent
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h3" color="warning.main" sx={{ fontWeight: 'bold' }}>
                {attendanceStats.Late}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Late
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Attendance Chart */}
      {pieData.length > 0 && (
        <Card elevation={2} sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" component="h2" gutterBottom sx={{ fontWeight: 'bold' }}>
              Attendance Overview
            </Typography>
            <Box display="flex" justifyContent="center" sx={{ height: 300 }}>
              <PieChart
                series={[
                  {
                    data: pieData,
                    highlightScope: { faded: 'global', highlighted: 'item' },
                  },
                ]}
                height={300}
              />
            </Box>
          </CardContent>
        </Card>
      )}

      {/* Search and Filter */}
      <Card elevation={2} sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12} md={8}>
              <TextField
                fullWidth
                label="Search subjects"
                variant="outlined"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Filter by Status</InputLabel>
                <Select
                  value={statusFilter}
                  label="Filter by Status"
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <MenuItem value="All">All Status</MenuItem>
                  <MenuItem value="Present">Present</MenuItem>
                  <MenuItem value="Absent">Absent</MenuItem>
                  <MenuItem value="Late">Late</MenuItem>
                  <MenuItem value="Excused">Excused</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Attendance Table */}
      <Card elevation={2}>
        <CardContent>
          <Typography variant="h6" component="h2" gutterBottom sx={{ fontWeight: 'bold' }}>
            Attendance Records
          </Typography>
          
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: 'grey.50' }}>
                  <TableCell sx={{ fontWeight: 'bold' }}>Date</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Subject</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredAttendance.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={3} align="center">
                      <Typography color="text.secondary" sx={{ py: 4 }}>
                        {searchTerm || statusFilter !== 'All' 
                          ? 'No attendance records found matching your search' 
                          : 'No attendance records available'}
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredAttendance
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map((record) => (
                      <TableRow key={record.id} hover>
                        <TableCell>
                          <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                            {formatDate(record.date)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body2" color="text.secondary">
                            {getSubjectName(record.subject_id)}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <Chip
                            label={record.status}
                            color={getStatusColor(record.status)}
                            size="small"
                            sx={{ fontWeight: 'bold' }}
                          />
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Box>
  );
};