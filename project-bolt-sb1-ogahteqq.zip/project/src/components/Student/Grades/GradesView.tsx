import React, { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Box,
  TextField,
  Grid,
  LinearProgress
} from '@mui/material';
import { useStudent } from '../context/StudentContext';
import { useData } from '../../../context/DataContext';

export const GradesView: React.FC = () => {
  const { studentData } = useStudent();
  const { subjects, teachers } = useData();
  const [searchTerm, setSearchTerm] = useState('');

  if (!studentData) {
    return (
      <Typography variant="h6" color="error">
        No student data available
      </Typography>
    );
  }

  const getSubjectName = (subjectId: number) => {
    return subjects.find(s => s.id === subjectId)?.name || 'Unknown Subject';
  };

  const getTeacherName = (subjectId: number) => {
    const subject = subjects.find(s => s.id === subjectId);
    if (!subject) return 'Unknown Teacher';
    
    const teacher = teachers.find(t => t.department_id === subject.department_id);
    return teacher ? `${teacher.first_name} ${teacher.last_name}` : 'Unknown Teacher';
  };

  const getGradeColor = (grade: number) => {
    if (grade >= 90) return 'success';
    if (grade >= 80) return 'info';
    if (grade >= 70) return 'warning';
    return 'error';
  };

  const getGradeLetter = (grade: number) => {
    if (grade >= 90) return 'A';
    if (grade >= 80) return 'B';
    if (grade >= 70) return 'C';
    if (grade >= 60) return 'D';
    return 'F';
  };

  const filteredGrades = studentData.grades.filter(grade => {
    const subjectName = getSubjectName(grade.subject_id).toLowerCase();
    const teacherName = getTeacherName(grade.subject_id).toLowerCase();
    const search = searchTerm.toLowerCase();
    
    return subjectName.includes(search) || teacherName.includes(search);
  });

  const averageGrade = studentData.grades.length > 0 
    ? studentData.grades.reduce((sum, g) => sum + g.grade, 0) / studentData.grades.length
    : 0;

  const gpa = (averageGrade / 100) * 4; // Convert to 4.0 scale

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
        Academic Grades
      </Typography>

      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={4}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h3" color="primary.main" sx={{ fontWeight: 'bold' }}>
                {averageGrade.toFixed(1)}%
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Overall Average
              </Typography>
              <LinearProgress 
                variant="determinate" 
                value={averageGrade} 
                sx={{ mt: 1, height: 8, borderRadius: 4 }}
                color={getGradeColor(averageGrade)}
              />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h3" color="info.main" sx={{ fontWeight: 'bold' }}>
                {gpa.toFixed(2)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                GPA (4.0 Scale)
              </Typography>
              <Chip 
                label={getGradeLetter(averageGrade)} 
                color={getGradeColor(averageGrade)}
                sx={{ mt: 1, fontSize: '1rem', fontWeight: 'bold' }}
              />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h3" color="success.main" sx={{ fontWeight: 'bold' }}>
                {studentData.grades.length}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Subjects Graded
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                of {studentData.subjects.length} enrolled
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Search and Filter */}
      <Card elevation={2} sx={{ mb: 3 }}>
        <CardContent>
          <TextField
            fullWidth
            label="Search subjects or teachers"
            variant="outlined"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            sx={{ mb: 2 }}
          />
        </CardContent>
      </Card>

      {/* Grades Table */}
      <Card elevation={2}>
        <CardContent>
          <Typography variant="h6" component="h2" gutterBottom sx={{ fontWeight: 'bold' }}>
            Subject Grades
          </Typography>
          
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: 'grey.50' }}>
                  <TableCell sx={{ fontWeight: 'bold' }}>Subject</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Teacher</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Grade</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Letter</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Performance</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredGrades.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} align="center">
                      <Typography color="text.secondary" sx={{ py: 4 }}>
                        {searchTerm ? 'No grades found matching your search' : 'No grades available'}
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredGrades.map((grade) => (
                    <TableRow key={grade.id} hover>
                      <TableCell>
                        <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                          {getSubjectName(grade.subject_id)}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="text.secondary">
                          {getTeacherName(grade.subject_id)}
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <Typography 
                          variant="h6" 
                          sx={{ 
                            fontWeight: 'bold',
                            color: `${getGradeColor(grade.grade)}.main`
                          }}
                        >
                          {grade.grade}%
                        </Typography>
                      </TableCell>
                      <TableCell align="center">
                        <Chip
                          label={getGradeLetter(grade.grade)}
                          color={getGradeColor(grade.grade)}
                          size="small"
                          sx={{ fontWeight: 'bold' }}
                        />
                      </TableCell>
                      <TableCell align="center">
                        <Box sx={{ width: 100 }}>
                          <LinearProgress
                            variant="determinate"
                            value={grade.grade}
                            color={getGradeColor(grade.grade)}
                            sx={{ height: 6, borderRadius: 3 }}
                          />
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Box>
  );
};