import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  Grid,
  Box,
  Chip,
  Paper,
  List,
  ListItem,
  ListItemText,
  Divider
} from '@mui/material';
import {
  AccessTime as TimeIcon,
  Person as PersonIcon,
  Room as RoomIcon
} from '@mui/icons-material';
import { useStudent } from '../context/StudentContext';
import { useData } from '../../../context/DataContext';

export const ScheduleView: React.FC = () => {
  const { studentData } = useStudent();
  const { subjects, teachers, classrooms } = useData();

  if (!studentData) {
    return (
      <Typography variant="h6" color="error">
        No student data available
      </Typography>
    );
  }

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const getScheduleForDay = (day: string) => {
    return studentData.schedule
      .filter(s => s.day_of_week === day)
      .sort((a, b) => a.start_time.localeCompare(b.start_time));
  };

  const getSubjectName = (subjectId: number) => {
    return subjects.find(s => s.id === subjectId)?.name || 'Unknown Subject';
  };

  const getTeacherName = (teacherId: number) => {
    const teacher = teachers.find(t => t.id === teacherId);
    return teacher ? `${teacher.first_name} ${teacher.last_name}` : 'Unknown Teacher';
  };

  const getClassroomName = (classroomId: number) => {
    return classrooms.find(c => c.id === classroomId)?.name || 'Unknown Room';
  };

  const formatTime = (time: string) => {
    const [hours, minutes] = time.split(':');
    const hour24 = parseInt(hours);
    const hour12 = hour24 > 12 ? hour24 - 12 : hour24 === 0 ? 12 : hour24;
    const ampm = hour24 >= 12 ? 'PM' : 'AM';
    return `${hour12}:${minutes} ${ampm}`;
  };

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
        Weekly Schedule
      </Typography>

      <Grid container spacing={3}>
        {daysOfWeek.map(day => {
          const daySchedule = getScheduleForDay(day);
          return (
            <Grid item xs={12} sm={6} md={4} key={day}>
              <Card elevation={2} sx={{ height: '100%' }}>
                <CardContent>
                  <Typography 
                    variant="h6" 
                    component="h2" 
                    gutterBottom 
                    sx={{ 
                      fontWeight: 'bold',
                      color: 'primary.main',
                      borderBottom: '2px solid',
                      borderColor: 'primary.light',
                      pb: 1,
                      mb: 2
                    }}
                  >
                    {day}
                  </Typography>

                  {daySchedule.length === 0 ? (
                    <Typography color="text.secondary" fontStyle="italic">
                      No classes scheduled
                    </Typography>
                  ) : (
                    <List dense sx={{ p: 0 }}>
                      {daySchedule.map((schedule, index) => (
                        <Box key={schedule.id}>
                          <ListItem sx={{ px: 0 }}>
                            <Paper 
                              elevation={1} 
                              sx={{ 
                                p: 2, 
                                width: '100%',
                                backgroundColor: 'background.default',
                                border: '1px solid',
                                borderColor: 'divider'
                              }}
                            >
                              <Typography 
                                variant="subtitle1" 
                                sx={{ fontWeight: 'bold', mb: 1 }}
                              >
                                {getSubjectName(schedule.subject_id)}
                              </Typography>
                              
                              <Box display="flex" alignItems="center" gap={1} mb={1}>
                                <TimeIcon fontSize="small" color="primary" />
                                <Typography variant="body2">
                                  {formatTime(schedule.start_time)} - {formatTime(schedule.end_time)}
                                </Typography>
                              </Box>
                              
                              <Box display="flex" alignItems="center" gap={1} mb={1}>
                                <PersonIcon fontSize="small" color="primary" />
                                <Typography variant="body2">
                                  {getTeacherName(schedule.teacher_id)}
                                </Typography>
                              </Box>
                              
                              <Box display="flex" alignItems="center" gap={1}>
                                <RoomIcon fontSize="small" color="primary" />
                                <Typography variant="body2">
                                  {getClassroomName(schedule.classroom_id)}
                                </Typography>
                              </Box>
                            </Paper>
                          </ListItem>
                          {index < daySchedule.length - 1 && <Divider sx={{ my: 1 }} />}
                        </Box>
                      ))}
                    </List>
                  )}
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>

      {/* Weekly Summary */}
      <Card elevation={2} sx={{ mt: 3 }}>
        <CardContent>
          <Typography variant="h6" component="h3" gutterBottom sx={{ fontWeight: 'bold' }}>
            Weekly Summary
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={6} sm={3}>
              <Box textAlign="center" p={2}>
                <Typography variant="h4" color="primary.main" sx={{ fontWeight: 'bold' }}>
                  {studentData.schedule.length}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Classes
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={6} sm={3}>
              <Box textAlign="center" p={2}>
                <Typography variant="h4" color="success.main" sx={{ fontWeight: 'bold' }}>
                  {studentData.subjects.length}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Subjects
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={6} sm={3}>
              <Box textAlign="center" p={2}>
                <Typography variant="h4" color="info.main" sx={{ fontWeight: 'bold' }}>
                  {new Set(studentData.schedule.map(s => s.teacher_id)).size}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Teachers
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={6} sm={3}>
              <Box textAlign="center" p={2}>
                <Typography variant="h4" color="warning.main" sx={{ fontWeight: 'bold' }}>
                  {new Set(studentData.schedule.map(s => s.classroom_id)).size}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Classrooms
                </Typography>
              </Box>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
};