import React, { createContext, useContext, useState, ReactNode } from 'react';
import { StudentData } from '../../../types';
import { useData } from '../../../context/DataContext';

interface StudentContextType {
  currentStudentId: number;
  setCurrentStudentId: (id: number) => void;
  studentData: StudentData | null;
  availableStudents: Array<{id: number, name: string}>;
}

const StudentContext = createContext<StudentContextType | undefined>(undefined);

export const useStudent = () => {
  const context = useContext(StudentContext);
  if (context === undefined) {
    throw new Error('useStudent must be used within a StudentProvider');
  }
  return context;
};

interface StudentProviderProps {
  children: ReactNode;
  initialStudentId?: number;
}

export const StudentProvider: React.FC<StudentProviderProps> = ({ 
  children, 
  initialStudentId 
}) => {
  const [currentStudentId, setCurrentStudentId] = useState<number>(initialStudentId || 1);
  const { 
    students, 
    departments, 
    classrooms, 
    generations, 
    subjects, 
    teachers, 
    schedule, 
    enrollment, 
    attendance, 
    grades, 
    fees 
  } = useData();

  const getStudentData = (studentId: number): StudentData | null => {
    const student = students.find(s => s.id === studentId);
    if (!student) return null;

    const department = departments.find(d => d.id === student.department_id)!;
    const classroom = classrooms.find(c => c.id === student.classroom_id)!;
    const generation = generations.find(g => g.id === student.generation_id)!;

    // Get enrolled subjects
    const studentEnrollments = enrollment.filter(e => e.student_id === studentId);
    const enrolledSubjects = subjects.filter(s => 
      studentEnrollments.some(e => e.subject_id === s.id)
    );

    // Get teachers for enrolled subjects
    const enrolledTeachers = teachers.filter(t => 
      enrolledSubjects.some(s => s.department_id === t.department_id)
    );

    // Get schedule for enrolled subjects
    const studentSchedule = schedule.filter(s => 
      enrolledSubjects.some(sub => sub.id === s.subject_id)
    );

    // Get attendance records
    const studentAttendance = attendance.filter(a => a.student_id === studentId);

    // Get grades
    const studentGrades = grades.filter(g => g.student_id === studentId);

    // Get fees
    const studentFees = fees.filter(f => f.student_id === studentId);

    return {
      student,
      department,
      classroom,
      generation,
      subjects: enrolledSubjects,
      teachers: enrolledTeachers,
      schedule: studentSchedule,
      attendance: studentAttendance,
      grades: studentGrades,
      fees: studentFees
    };
  };

  const availableStudents = students.map(s => ({
    id: s.id,
    name: `${s.first_name} ${s.last_name}`
  }));

  const studentData = getStudentData(currentStudentId);

  return (
    <StudentContext.Provider 
      value={{ 
        currentStudentId, 
        setCurrentStudentId, 
        studentData, 
        availableStudents 
      }}
    >
      {children}
    </StudentContext.Provider>
  );
};