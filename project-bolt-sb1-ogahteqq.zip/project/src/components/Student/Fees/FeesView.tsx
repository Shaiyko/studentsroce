import React, { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Box,
  Grid,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Alert
} from '@mui/material';
import { useStudent } from '../context/StudentContext';

export const FeesView: React.FC = () => {
  const { studentData } = useStudent();
  const [statusFilter, setStatusFilter] = useState('All');

  if (!studentData) {
    return (
      <Typography variant="h6" color="error">
        No student data available
      </Typography>
    );
  }

  const getStatusColor = (status: string) => {
    return status === 'Paid' ? 'success' : 'error';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const isOverdue = (dueDateString: string, status: string) => {
    if (status === 'Paid') return false;
    const dueDate = new Date(dueDateString);
    const today = new Date();
    return dueDate < today;
  };

  const filteredFees = studentData.fees.filter(fee => {
    return statusFilter === 'All' || fee.status === statusFilter;
  });

  // Calculate fee statistics
  const totalFees = studentData.fees.reduce((sum, fee) => sum + fee.amount, 0);
  const paidFees = studentData.fees
    .filter(fee => fee.status === 'Paid')
    .reduce((sum, fee) => sum + fee.amount, 0);
  const unpaidFees = studentData.fees
    .filter(fee => fee.status === 'Unpaid')
    .reduce((sum, fee) => sum + fee.amount, 0);
  const overdueFees = studentData.fees
    .filter(fee => fee.status === 'Unpaid' && isOverdue(fee.due_date, fee.status))
    .reduce((sum, fee) => sum + fee.amount, 0);

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
        Fee Management
      </Typography>

      {/* Outstanding Balance Alert */}
      {unpaidFees > 0 && (
        <Alert 
          severity={overdueFees > 0 ? "error" : "warning"} 
          sx={{ mb: 3 }}
        >
          <Typography variant="body1">
            {overdueFees > 0 
              ? `You have overdue fees totaling ${formatCurrency(overdueFees)}. Please settle your outstanding balance.`
              : `You have unpaid fees totaling ${formatCurrency(unpaidFees)}. Please review your payment schedule.`
            }
          </Typography>
        </Alert>
      )}

      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="primary.main" sx={{ fontWeight: 'bold' }}>
                {formatCurrency(totalFees)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Total Fees
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="success.main" sx={{ fontWeight: 'bold' }}>
                {formatCurrency(paidFees)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Paid
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="error.main" sx={{ fontWeight: 'bold' }}>
                {formatCurrency(unpaidFees)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Outstanding
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card elevation={2}>
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="h4" color="warning.main" sx={{ fontWeight: 'bold' }}>
                {formatCurrency(overdueFees)}
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Overdue
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Filter */}
      <Card elevation={2} sx={{ mb: 3 }}>
        <CardContent>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Filter by Status</InputLabel>
                <Select
                  value={statusFilter}
                  label="Filter by Status"
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <MenuItem value="All">All Status</MenuItem>
                  <MenuItem value="Paid">Paid</MenuItem>
                  <MenuItem value="Unpaid">Unpaid</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Fees Table */}
      <Card elevation={2}>
        <CardContent>
          <Typography variant="h6" component="h2" gutterBottom sx={{ fontWeight: 'bold' }}>
            Fee Records
          </Typography>
          
          <TableContainer component={Paper} elevation={0}>
            <Table>
              <TableHead>
                <TableRow sx={{ backgroundColor: 'grey.50' }}>
                  <TableCell sx={{ fontWeight: 'bold' }}>Amount</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>Due Date</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Status</TableCell>
                  <TableCell align="center" sx={{ fontWeight: 'bold' }}>Remarks</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredFees.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} align="center">
                      <Typography color="text.secondary" sx={{ py: 4 }}>
                        {statusFilter !== 'All' 
                          ? `No ${statusFilter.toLowerCase()} fees found` 
                          : 'No fee records available'}
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredFees
                    .sort((a, b) => new Date(b.due_date).getTime() - new Date(a.due_date).getTime())
                    .map((fee) => (
                      <TableRow 
                        key={fee.id} 
                        hover
                        sx={{
                          backgroundColor: isOverdue(fee.due_date, fee.status) 
                            ? 'error.light' 
                            : 'inherit'
                        }}
                      >
                        <TableCell>
                          <Typography 
                            variant="h6" 
                            sx={{ 
                              fontWeight: 'bold',
                              color: fee.status === 'Paid' ? 'success.main' : 'error.main'
                            }}
                          >
                            {formatCurrency(fee.amount)}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                            {formatDate(fee.due_date)}
                          </Typography>
                        </TableCell>
                        <TableCell align="center">
                          <Chip
                            label={fee.status}
                            color={getStatusColor(fee.status)}
                            size="small"
                            sx={{ fontWeight: 'bold' }}
                          />
                        </TableCell>
                        <TableCell align="center">
                          {isOverdue(fee.due_date, fee.status) && (
                            <Chip
                              label="OVERDUE"
                              color="error"
                              size="small"
                              variant="outlined"
                              sx={{ fontWeight: 'bold' }}
                            />
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* Payment Summary */}
      <Card elevation={2} sx={{ mt: 3 }}>
        <CardContent>
          <Typography variant="h6" component="h3" gutterBottom sx={{ fontWeight: 'bold' }}>
            Payment Summary
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <Box display="flex" justifyContent="space-between" mb={1}>
                <Typography variant="body1">Total Fees:</Typography>
                <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                  {formatCurrency(totalFees)}
                </Typography>
              </Box>
              <Box display="flex" justifyContent="space-between" mb={1}>
                <Typography variant="body1" color="success.main">Amount Paid:</Typography>
                <Typography variant="body1" sx={{ fontWeight: 'bold' }} color="success.main">
                  {formatCurrency(paidFees)}
                </Typography>
              </Box>
              <Box display="flex" justifyContent="space-between" mb={1}>
                <Typography variant="body1" color="error.main">Outstanding Balance:</Typography>
                <Typography variant="body1" sx={{ fontWeight: 'bold' }} color="error.main">
                  {formatCurrency(unpaidFees)}
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Box display="flex" justifyContent="space-between" mb={1}>
                <Typography variant="body1">Payment Progress:</Typography>
                <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                  {totalFees > 0 ? ((paidFees / totalFees) * 100).toFixed(1) : 0}%
                </Typography>
              </Box>
              <Box display="flex" justifyContent="space-between" mb={1}>
                <Typography variant="body1">Total Transactions:</Typography>
                <Typography variant="body1" sx={{ fontWeight: 'bold' }}>
                  {studentData.fees.length}
                </Typography>
              </Box>
              {overdueFees > 0 && (
                <Box display="flex" justifyContent="space-between" mb={1}>
                  <Typography variant="body1" color="warning.main">Overdue Amount:</Typography>
                  <Typography variant="body1" sx={{ fontWeight: 'bold' }} color="warning.main">
                    {formatCurrency(overdueFees)}
                  </Typography>
                </Box>
              )}
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
};