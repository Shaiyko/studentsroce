import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box
} from '@mui/material';
import { School as SchoolIcon } from '@mui/icons-material';
import { useStudent } from '../context/StudentContext';

export const StudentSelector: React.FC = () => {
  const { currentStudentId, setCurrentStudentId, availableStudents } = useStudent();

  return (
    <Card elevation={2} sx={{ mb: 3 }}>
      <CardContent>
        <Box display="flex" alignItems="center" gap={2}>
          <SchoolIcon color="primary" />
          <Typography variant="h6" component="h2" sx={{ fontWeight: 'bold', flexGrow: 1 }}>
            Select Student
          </Typography>
          <FormControl sx={{ minWidth: 200 }}>
            <InputLabel>Student</InputLabel>
            <Select
              value={currentStudentId}
              label="Student"
              onChange={(e) => setCurrentStudentId(Number(e.target.value))}
            >
              {availableStudents.map((student) => (
                <MenuItem key={student.id} value={student.id}>
                  {student.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>
      </CardContent>
    </Card>
  );
};