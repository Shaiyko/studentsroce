import React, { useState } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { CssBaseline } from '@mui/material';
import { StudentProvider } from './context/StudentContext';
import { AppLayout } from './Layout/AppLayout';
import { StudentSelector } from './StudentSelector/StudentSelector';
import { ProfileView } from './Profile/ProfileView';
import { ScheduleView } from './Schedule/ScheduleView';
import { GradesView } from './Grades/GradesView';
import { AttendanceView } from './Attendance/AttendanceView';
import { FeesView } from './Fees/FeesView';
import { useAuth } from '../../context/AuthContext';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          textTransform: 'none',
        },
      },
    },
  },
});

export const StudentDashboard: React.FC = () => {
  const [currentTab, setCurrentTab] = useState(0);
  const { user } = useAuth();

  const renderCurrentView = () => {
    switch (currentTab) {
      case 0:
        return <ProfileView />;
      case 1:
        return <ScheduleView />;
      case 2:
        return <GradesView />;
      case 3:
        return <AttendanceView />;
      case 4:
        return <FeesView />;
      default:
        return <ProfileView />;
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <StudentProvider initialStudentId={user?.student_id}>
        <AppLayout currentTab={currentTab} onTabChange={setCurrentTab}>
          {!user?.student_id && <StudentSelector />}
          {renderCurrentView()}
        </AppLayout>
      </StudentProvider>
    </ThemeProvider>
  );
};