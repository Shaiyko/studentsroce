import React from 'react';
import {
  Card,
  CardContent,
  Typography,
  Grid,
  Avatar,
  Box,
  Chip,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import {
  Person as PersonIcon,
  School as SchoolIcon,
  Class as ClassIcon,
  CalendarToday as CalendarIcon,
  Wc as GenderIcon
} from '@mui/icons-material';
import { useStudent } from '../context/StudentContext';

export const ProfileView: React.FC = () => {
  const { studentData } = useStudent();

  if (!studentData) {
    return (
      <Typography variant="h6" color="error">
        No student data available
      </Typography>
    );
  }

  const { student, department, classroom, generation } = studentData;

  const getAvatarLetter = () => {
    return student.first_name.charAt(0).toUpperCase();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const calculateAge = (dateString: string) => {
    const today = new Date();
    const birthDate = new Date(dateString);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <Box>
      <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
        Student Profile
      </Typography>

      <Grid container spacing={3}>
        {/* Personal Information Card */}
        <Grid item xs={12} md={6}>
          <Card elevation={2} sx={{ height: '100%' }}>
            <CardContent>
              <Box display="flex" alignItems="center" mb={3}>
                <Avatar
                  sx={{
                    width: 80,
                    height: 80,
                    bgcolor: 'primary.main',
                    fontSize: '2rem',
                    mr: 3
                  }}
                >
                  {getAvatarLetter()}
                </Avatar>
                <Box>
                  <Typography variant="h5" component="h2" sx={{ fontWeight: 'bold' }}>
                    {student.first_name} {student.last_name}
                  </Typography>
                  <Chip
                    label={`Student ID: ${student.id}`}
                    color="primary"
                    variant="outlined"
                    size="small"
                  />
                </Box>
              </Box>

              <Divider sx={{ my: 2 }} />

              <List dense>
                <ListItem>
                  <ListItemIcon>
                    <GenderIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText
                    primary="Gender"
                    secondary={student.gender}
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <CalendarIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText
                    primary="Date of Birth"
                    secondary={`${formatDate(student.dob)} (Age: ${calculateAge(student.dob)})`}
                  />
                </ListItem>
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Academic Information Card */}
        <Grid item xs={12} md={6}>
          <Card elevation={2} sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" component="h3" gutterBottom sx={{ fontWeight: 'bold' }}>
                Academic Information
              </Typography>

              <List dense>
                <ListItem>
                  <ListItemIcon>
                    <SchoolIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText
                    primary="Department"
                    secondary={department.name}
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <ClassIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText
                    primary="Classroom"
                    secondary={classroom.name}
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <PersonIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText
                    primary="Generation"
                    secondary={`${generation.name} (${generation.start_year} - ${generation.end_year})`}
                  />
                </ListItem>
              </List>
            </CardContent>
          </Card>
        </Grid>

        {/* Quick Stats Card */}
        <Grid item xs={12}>
          <Card elevation={2}>
            <CardContent>
              <Typography variant="h6" component="h3" gutterBottom sx={{ fontWeight: 'bold' }}>
                Quick Statistics
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center" p={2}>
                    <Typography variant="h4" color="primary.main" sx={{ fontWeight: 'bold' }}>
                      {studentData.subjects.length}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Enrolled Subjects
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center" p={2}>
                    <Typography variant="h4" color="success.main" sx={{ fontWeight: 'bold' }}>
                      {studentData.attendance.filter(a => a.status === 'Present').length}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Classes Attended
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center" p={2}>
                    <Typography variant="h4" color="info.main" sx={{ fontWeight: 'bold' }}>
                      {studentData.grades.length > 0 
                        ? (studentData.grades.reduce((sum, g) => sum + g.grade, 0) / studentData.grades.length).toFixed(1)
                        : 'N/A'
                      }
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Average Grade
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6} sm={3}>
                  <Box textAlign="center" p={2}>
                    <Typography variant="h4" color="warning.main" sx={{ fontWeight: 'bold' }}>
                      ${studentData.fees.filter(f => f.status === 'Unpaid').reduce((sum, f) => sum + f.amount, 0).toFixed(2)}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Outstanding Fees
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};