export interface Generation {
  id: number;
  name: string;
  start_year: number;
  end_year: number;
}

export interface Department {
  id: number;
  name: string;
}

export interface Classroom {
  id: number;
  name: string;
  capacity: number;
  department_id: number;
}

export interface Student {
  id: number;
  first_name: string;
  last_name: string;
  gender: 'Male' | 'Female' | 'Other';
  dob: string;
  department_id: number;
  classroom_id: number;
  generation_id: number;
}

export interface Teacher {
  id: number;
  first_name: string;
  last_name: string;
  department_id: number;
}

export interface Subject {
  id: number;
  name: string;
  department_id: number;
}

export interface Schedule {
  id: number;
  subject_id: number;
  teacher_id: number;
  classroom_id: number;
  day_of_week: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';
  start_time: string;
  end_time: string;
}

export interface Enrollment {
  id: number;
  student_id: number;
  subject_id: number;
}

export interface Attendance {
  id: number;
  student_id: number;
  subject_id: number;
  schedule_id: number;
  date: string;
  status: 'Present' | 'Absent' | 'Late' | 'Excused';
}

export interface Grade {
  id: number;
  student_id: number;
  subject_id: number;
  attendance_id: number;
  grade: number;
}

export interface Fee {
  id: number;
  student_id: number;
  amount: number;
  due_date: string;
  status: 'Paid' | 'Unpaid';
}

export interface StudentData {
  student: Student;
  department: Department;
  classroom: Classroom;
  generation: Generation;
  subjects: Subject[];
  teachers: Teacher[];
  schedule: Schedule[];
  attendance: Attendance[];
  grades: Grade[];
  fees: Fee[];
}

export interface User {
  id: number;
  username: string;
  role: 'admin' | 'student';
  student_id?: number;
}