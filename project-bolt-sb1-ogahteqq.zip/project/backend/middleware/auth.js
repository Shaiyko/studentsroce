const jwt = require('jsonwebtoken');
const { executeQuery } = require('../config/database');

// Verify JWT token
const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ 
      success: false, 
      message: 'Access token required' 
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Get user details from database
    const user = await executeQuery(
      'SELECT id, username, role, student_id, teacher_id FROM users WHERE id = ?',
      [decoded.userId]
    );

    if (user.length === 0) {
      return res.status(401).json({ 
        success: false, 
        message: 'Invalid token' 
      });
    }

    req.user = user[0];
    next();
  } catch (error) {
    return res.status(403).json({ 
      success: false, 
      message: 'Invalid or expired token' 
    });
  }
};

// Check if user has admin role
const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ 
      success: false, 
      message: 'Admin access required' 
    });
  }
  next();
};

// Check if user has student role
const requireStudent = (req, res, next) => {
  if (req.user.role !== 'student') {
    return res.status(403).json({ 
      success: false, 
      message: 'Student access required' 
    });
  }
  next();
};

// Check if user has teacher role
const requireTeacher = (req, res, next) => {
  if (req.user.role !== 'teacher') {
    return res.status(403).json({ 
      success: false, 
      message: 'Teacher access required' 
    });
  }
  next();
};

// Check if user can access student data (admin or own student data)
const canAccessStudent = (req, res, next) => {
  const studentId = parseInt(req.params.studentId || req.body.student_id);
  
  if (req.user.role === 'admin') {
    return next();
  }
  
  if (req.user.role === 'student' && req.user.student_id === studentId) {
    return next();
  }
  
  return res.status(403).json({ 
    success: false, 
    message: 'Access denied' 
  });
};

module.exports = {
  authenticateToken,
  requireAdmin,
  requireStudent,
  requireTeacher,
  canAccessStudent
};