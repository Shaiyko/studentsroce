const { body, param, validationResult } = require('express-validator');

// Handle validation errors
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array()
    });
  }
  next();
};

// Student validation rules
const validateStudent = [
  body('first_name').trim().isLength({ min: 1 }).withMessage('First name is required'),
  body('last_name').trim().isLength({ min: 1 }).withMessage('Last name is required'),
  body('gender').isIn(['Male', 'Female', 'Other']).withMessage('Invalid gender'),
  body('dob').isDate().withMessage('Valid date of birth is required'),
  body('email').optional().isEmail().withMessage('Valid email is required'),
  body('department_id').isInt({ min: 1 }).withMessage('Valid department ID is required'),
  body('classroom_id').isInt({ min: 1 }).withMessage('Valid classroom ID is required'),
  body('generation_id').isInt({ min: 1 }).withMessage('Valid generation ID is required'),
  handleValidationErrors
];

// Teacher validation rules
const validateTeacher = [
  body('first_name').trim().isLength({ min: 1 }).withMessage('First name is required'),
  body('last_name').trim().isLength({ min: 1 }).withMessage('Last name is required'),
  body('email').optional().isEmail().withMessage('Valid email is required'),
  body('department_id').isInt({ min: 1 }).withMessage('Valid department ID is required'),
  handleValidationErrors
];

// Department validation rules
const validateDepartment = [
  body('name').trim().isLength({ min: 1 }).withMessage('Department name is required'),
  body('description').optional().trim(),
  handleValidationErrors
];

// Classroom validation rules
const validateClassroom = [
  body('name').trim().isLength({ min: 1 }).withMessage('Classroom name is required'),
  body('capacity').isInt({ min: 1 }).withMessage('Valid capacity is required'),
  body('department_id').isInt({ min: 1 }).withMessage('Valid department ID is required'),
  handleValidationErrors
];

// Subject validation rules
const validateSubject = [
  body('name').trim().isLength({ min: 1 }).withMessage('Subject name is required'),
  body('code').optional().trim(),
  body('credits').optional().isInt({ min: 1 }).withMessage('Valid credits required'),
  body('department_id').isInt({ min: 1 }).withMessage('Valid department ID is required'),
  handleValidationErrors
];

// Schedule validation rules
const validateSchedule = [
  body('subject_id').isInt({ min: 1 }).withMessage('Valid subject ID is required'),
  body('teacher_id').isInt({ min: 1 }).withMessage('Valid teacher ID is required'),
  body('classroom_id').isInt({ min: 1 }).withMessage('Valid classroom ID is required'),
  body('day_of_week').isIn(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']).withMessage('Invalid day of week'),
  body('start_time').matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).withMessage('Valid start time is required (HH:MM)'),
  body('end_time').matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).withMessage('Valid end time is required (HH:MM)'),
  handleValidationErrors
];

// Enrollment validation rules
const validateEnrollment = [
  body('student_id').isInt({ min: 1 }).withMessage('Valid student ID is required'),
  body('subject_id').isInt({ min: 1 }).withMessage('Valid subject ID is required'),
  handleValidationErrors
];

// Attendance validation rules
const validateAttendance = [
  body('student_id').isInt({ min: 1 }).withMessage('Valid student ID is required'),
  body('subject_id').isInt({ min: 1 }).withMessage('Valid subject ID is required'),
  body('schedule_id').isInt({ min: 1 }).withMessage('Valid schedule ID is required'),
  body('date').isDate().withMessage('Valid date is required'),
  body('status').isIn(['Present', 'Absent', 'Late', 'Excused']).withMessage('Invalid status'),
  handleValidationErrors
];

// Grade validation rules
const validateGrade = [
  body('student_id').isInt({ min: 1 }).withMessage('Valid student ID is required'),
  body('subject_id').isInt({ min: 1 }).withMessage('Valid subject ID is required'),
  body('grade').isFloat({ min: 0, max: 100 }).withMessage('Grade must be between 0 and 100'),
  body('grade_type').optional().isIn(['Quiz', 'Midterm', 'Final', 'Assignment', 'Project']).withMessage('Invalid grade type'),
  handleValidationErrors
];

// Fee validation rules
const validateFee = [
  body('student_id').isInt({ min: 1 }).withMessage('Valid student ID is required'),
  body('amount').isFloat({ min: 0.01 }).withMessage('Valid amount is required'),
  body('fee_type').optional().isIn(['Tuition', 'Library', 'Lab', 'Sports', 'Other']).withMessage('Invalid fee type'),
  body('due_date').isDate().withMessage('Valid due date is required'),
  body('status').optional().isIn(['Paid', 'Unpaid', 'Overdue']).withMessage('Invalid status'),
  handleValidationErrors
];

// ID parameter validation
const validateId = [
  param('id').isInt({ min: 1 }).withMessage('Valid ID is required'),
  handleValidationErrors
];

module.exports = {
  validateStudent,
  validateTeacher,
  validateDepartment,
  validateClassroom,
  validateSubject,
  validateSchedule,
  validateEnrollment,
  validateAttendance,
  validateGrade,
  validateFee,
  validateId,
  handleValidationErrors
};