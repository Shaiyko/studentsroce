# School Management System - Backend API

A comprehensive Node.js backend API for the School Management System with MySQL database integration.

## 🚀 Features

- **Authentication & Authorization**: JWT-based authentication with role-based access control
- **Complete CRUD Operations**: Full Create, Read, Update, Delete operations for all entities
- **Database Integration**: MySQL database with proper relationships and constraints
- **Data Validation**: Comprehensive input validation using express-validator
- **Security**: Helmet, CORS, rate limiting, and password hashing
- **Error Handling**: Centralized error handling with proper HTTP status codes
- **Database Transactions**: Atomic operations for data consistency

## 🛠 Technologies

- **Node.js**: Runtime environment
- **Express.js**: Web framework
- **MySQL**: Database
- **JWT**: Authentication tokens
- **bcryptjs**: Password hashing
- **express-validator**: Input validation
- **helmet**: Security headers
- **cors**: Cross-origin resource sharing

## 📋 Prerequisites

- Node.js (v14 or higher)
- MySQL (v8.0 or higher)
- npm or yarn

## 🔧 Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   ```bash
   cp .env.example .env
   ```
   
   Update the `.env` file with your configuration:
   ```env
   # Database Configuration
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=your_password
   DB_NAME=school_management

   # Server Configuration
   PORT=5000
   NODE_ENV=development

   # JWT Configuration
   JWT_SECRET=your_super_secret_jwt_key_here
   JWT_EXPIRES_IN=24h

   # CORS Configuration
   FRONTEND_URL=http://localhost:5173
   ```

4. **Database Setup**
   
   Create MySQL database and run migrations:
   ```bash
   # Create database and tables
   npm run migrate
   ```

5. **Start the server**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

## 📊 Database Schema

The system includes the following entities:

- **Users**: Authentication and user management
- **Students**: Student information and profiles
- **Teachers**: Teacher information and assignments
- **Departments**: Academic departments
- **Classrooms**: Physical classroom management
- **Subjects**: Course/subject management
- **Schedule**: Class scheduling
- **Enrollment**: Student-subject enrollment
- **Attendance**: Attendance tracking
- **Grades**: Grade management
- **Fees**: Fee and payment tracking
- **Generations**: Academic year/batch management

## 🔐 Authentication

### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "password"
}
```

### Demo Accounts
- **Admin**: `admin` / `password`
- **Student**: `john.doe` / `password`
- **Teacher**: `dr.wilson` / `password`

## 📚 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/change-password` - Change password

### Students (Admin Only)
- `GET /api/students` - Get all students (with pagination and search)
- `GET /api/students/:id` - Get student by ID
- `POST /api/students` - Create new student
- `PUT /api/students/:id` - Update student
- `DELETE /api/students/:id` - Delete student

### Student Portal
- `GET /api/students/:studentId/academic-data` - Get student's academic data

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: bcrypt for secure password storage
- **Rate Limiting**: Prevent API abuse
- **CORS Protection**: Configured for frontend integration
- **Input Validation**: Comprehensive validation for all inputs
- **SQL Injection Prevention**: Parameterized queries
- **Role-Based Access**: Admin, Student, and Teacher roles

## 📝 Request/Response Examples

### Create Student
```http
POST /api/students
Authorization: Bearer <jwt_token>
Content-Type: application/json

{
  "first_name": "John",
  "last_name": "Doe",
  "gender": "Male",
  "dob": "2001-05-15",
  "email": "john.doe@school.edu",
  "phone": "555-0101",
  "department_id": 1,
  "classroom_id": 1,
  "generation_id": 2
}
```

### Response
```json
{
  "success": true,
  "data": {
    "id": 1,
    "first_name": "John",
    "last_name": "Doe",
    "gender": "Male",
    "dob": "2001-05-15",
    "email": "john.doe@school.edu",
    "phone": "555-0101",
    "department_id": 1,
    "classroom_id": 1,
    "generation_id": 2,
    "department_name": "Computer Science",
    "classroom_name": "CS-101",
    "generation_name": "2021-2025",
    "created_at": "2024-01-15T10:30:00.000Z",
    "updated_at": "2024-01-15T10:30:00.000Z"
  }
}
```

## 🚦 Error Handling

All API responses follow a consistent format:

### Success Response
```json
{
  "success": true,
  "data": { ... },
  "message": "Operation successful"
}
```

### Error Response
```json
{
  "success": false,
  "message": "Error description",
  "errors": [ ... ] // For validation errors
}
```

## 🔄 Database Migrations

The migration script creates the complete database schema and seeds initial data:

```bash
npm run migrate
```

This will:
1. Create the `school_management` database
2. Create all tables with proper relationships
3. Insert sample data for testing

## 📈 Performance Features

- **Connection Pooling**: Efficient database connection management
- **Indexing**: Optimized database queries with proper indexes
- **Pagination**: Large dataset handling with pagination
- **Caching**: Response caching for frequently accessed data

## 🧪 Testing

The API includes comprehensive sample data for testing:
- 10 students across different departments
- 8 teachers with department assignments
- Complete academic records (grades, attendance, fees)
- Realistic schedule and enrollment data

## 🔧 Development

### Adding New Endpoints

1. Create controller in `controllers/`
2. Add routes in `routes/`
3. Include validation in `middleware/validation.js`
4. Update authentication middleware if needed

### Database Changes

1. Update schema in `database/schema.sql`
2. Update seed data in `database/seed.sql`
3. Run migration: `npm run migrate`

## 📞 Support

For issues and questions:
1. Check the error logs in the console
2. Verify database connection
3. Ensure all environment variables are set
4. Check API endpoint documentation

## 🚀 Deployment

For production deployment:

1. Set `NODE_ENV=production`
2. Use a process manager (PM2)
3. Configure reverse proxy (Nginx)
4. Set up SSL certificates
5. Configure database backup strategy

```bash
# Using PM2
npm install -g pm2
pm2 start server.js --name "school-api"
```