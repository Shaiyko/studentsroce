const { executeQuery, getConnection } = require('../config/database');

// Get all schedule
const getAllSchedule = async (req, res) => {
  try {
    const { day_of_week = '', teacher_id = '' } = req.query;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (day_of_week) {
      whereClause += ' AND sc.day_of_week = ?';
      params.push(day_of_week);
    }

    if (teacher_id) {
      whereClause += ' AND sc.teacher_id = ?';
      params.push(teacher_id);
    }

    const query = `
      SELECT sc.*, 
             s.name as subject_name,
             CONCAT(t.first_name, ' ', t.last_name) as teacher_name,
             c.name as classroom_name,
             d.name as department_name
      FROM schedule sc
      LEFT JOIN subjects s ON sc.subject_id = s.id
      LEFT JOIN teachers t ON sc.teacher_id = t.id
      LEFT JOIN classrooms c ON sc.classroom_id = c.id
      LEFT JOIN departments d ON s.department_id = d.id
      ${whereClause}
      ORDER BY 
        FIELD(sc.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
        sc.start_time
    `;

    const schedule = await executeQuery(query, params);

    res.json({
      success: true,
      data: schedule
    });

  } catch (error) {
    console.error('Get schedule error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get schedule by ID
const getScheduleById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT sc.*, 
             s.name as subject_name,
             CONCAT(t.first_name, ' ', t.last_name) as teacher_name,
             c.name as classroom_name,
             d.name as department_name
      FROM schedule sc
      LEFT JOIN subjects s ON sc.subject_id = s.id
      LEFT JOIN teachers t ON sc.teacher_id = t.id
      LEFT JOIN classrooms c ON sc.classroom_id = c.id
      LEFT JOIN departments d ON s.department_id = d.id
      WHERE sc.id = ?
    `;

    const schedule = await executeQuery(query, [id]);

    if (schedule.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Schedule not found'
      });
    }

    res.json({
      success: true,
      data: schedule[0]
    });

  } catch (error) {
    console.error('Get schedule error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new schedule
const createSchedule = async (req, res) => {
  try {
    const { subject_id, teacher_id, classroom_id, day_of_week, start_time, end_time, semester } = req.body;

    // Check for time conflicts in the same classroom
    const conflictQuery = `
      SELECT id FROM schedule 
      WHERE classroom_id = ? AND day_of_week = ? 
      AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))
    `;

    const conflicts = await executeQuery(conflictQuery, [
      classroom_id, day_of_week, start_time, start_time, end_time, end_time
    ]);

    if (conflicts.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Time conflict: Classroom is already booked for this time slot'
      });
    }

    // Check for teacher conflicts
    const teacherConflictQuery = `
      SELECT id FROM schedule 
      WHERE teacher_id = ? AND day_of_week = ? 
      AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))
    `;

    const teacherConflicts = await executeQuery(teacherConflictQuery, [
      teacher_id, day_of_week, start_time, start_time, end_time, end_time
    ]);

    if (teacherConflicts.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Time conflict: Teacher is already assigned for this time slot'
      });
    }

    // Insert schedule
    const insertQuery = `
      INSERT INTO schedule (subject_id, teacher_id, classroom_id, day_of_week, start_time, end_time, semester) 
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    const result = await executeQuery(insertQuery, [
      subject_id, teacher_id, classroom_id, day_of_week, start_time, end_time, semester || 'Fall 2024'
    ]);

    const scheduleId = result.insertId;

    // Get the created schedule
    const newSchedule = await getScheduleById({ params: { id: scheduleId } }, res);

  } catch (error) {
    console.error('Create schedule error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Update schedule
const updateSchedule = async (req, res) => {
  try {
    const { id } = req.params;
    const { subject_id, teacher_id, classroom_id, day_of_week, start_time, end_time, semester } = req.body;

    // Check if schedule exists
    const existingSchedule = await executeQuery(
      'SELECT id FROM schedule WHERE id = ?',
      [id]
    );

    if (existingSchedule.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Schedule not found'
      });
    }

    // Check for time conflicts in the same classroom (excluding current schedule)
    const conflictQuery = `
      SELECT id FROM schedule 
      WHERE classroom_id = ? AND day_of_week = ? AND id != ?
      AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))
    `;

    const conflicts = await executeQuery(conflictQuery, [
      classroom_id, day_of_week, id, start_time, start_time, end_time, end_time
    ]);

    if (conflicts.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Time conflict: Classroom is already booked for this time slot'
      });
    }

    // Check for teacher conflicts (excluding current schedule)
    const teacherConflictQuery = `
      SELECT id FROM schedule 
      WHERE teacher_id = ? AND day_of_week = ? AND id != ?
      AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))
    `;

    const teacherConflicts = await executeQuery(teacherConflictQuery, [
      teacher_id, day_of_week, id, start_time, start_time, end_time, end_time
    ]);

    if (teacherConflicts.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Time conflict: Teacher is already assigned for this time slot'
      });
    }

    // Update schedule
    const updateQuery = `
      UPDATE schedule SET
        subject_id = ?, teacher_id = ?, classroom_id = ?, day_of_week = ?, 
        start_time = ?, end_time = ?, semester = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await executeQuery(updateQuery, [
      subject_id, teacher_id, classroom_id, day_of_week, start_time, end_time, 
      semester || 'Fall 2024', id
    ]);

    // Get the updated schedule
    const updatedSchedule = await getScheduleById({ params: { id } }, res);

  } catch (error) {
    console.error('Update schedule error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Delete schedule
const deleteSchedule = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;

    // Check if schedule exists
    const existingSchedule = await executeQuery(
      'SELECT id FROM schedule WHERE id = ?',
      [id]
    );

    if (existingSchedule.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Schedule not found'
      });
    }

    // Delete related attendance records
    await connection.execute('DELETE FROM attendance WHERE schedule_id = ?', [id]);
    
    // Delete schedule
    await connection.execute('DELETE FROM schedule WHERE id = ?', [id]);

    await connection.commit();

    res.json({
      success: true,
      message: 'Schedule deleted successfully'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Delete schedule error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

module.exports = {
  getAllSchedule,
  getScheduleById,
  createSchedule,
  updateSchedule,
  deleteSchedule
};