const { executeQuery, getConnection } = require('../config/database');

// Get all teachers (admin only)
const getAllTeachers = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '', department_id = '' } = req.query;
    const offset = (page - 1) * limit;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (search) {
      whereClause += ' AND (t.first_name LIKE ? OR t.last_name LIKE ? OR t.email LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (department_id) {
      whereClause += ' AND t.department_id = ?';
      params.push(department_id);
    }

    const query = `
      SELECT t.*, d.name as department_name
      FROM teachers t
      LEFT JOIN departments d ON t.department_id = d.id
      ${whereClause}
      ORDER BY t.created_at DESC
      LIMIT ? OFFSET ?
    `;

    const countQuery = `
      SELECT COUNT(*) as total
      FROM teachers t
      ${whereClause}
    `;

    const teachers = await executeQuery(query, [...params, parseInt(limit), parseInt(offset)]);
    const countResult = await executeQuery(countQuery, params);
    const total = countResult[0].total;

    res.json({
      success: true,
      data: {
        teachers,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('Get teachers error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get teacher by ID
const getTeacherById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT t.*, d.name as department_name
      FROM teachers t
      LEFT JOIN departments d ON t.department_id = d.id
      WHERE t.id = ?
    `;

    const teachers = await executeQuery(query, [id]);

    if (teachers.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Teacher not found'
      });
    }

    res.json({
      success: true,
      data: teachers[0]
    });

  } catch (error) {
    console.error('Get teacher error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new teacher
const createTeacher = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const {
      first_name,
      last_name,
      email,
      phone,
      department_id
    } = req.body;

    // Check if email already exists
    if (email) {
      const existingTeacher = await executeQuery(
        'SELECT id FROM teachers WHERE email = ?',
        [email]
      );

      if (existingTeacher.length > 0) {
        await connection.rollback();
        return res.status(400).json({
          success: false,
          message: 'Email already exists'
        });
      }
    }

    // Insert teacher
    const insertQuery = `
      INSERT INTO teachers (
        first_name, last_name, email, phone, department_id
      ) VALUES (?, ?, ?, ?, ?)
    `;

    const result = await connection.execute(insertQuery, [
      first_name, last_name, email, phone, department_id
    ]);

    const teacherId = result[0].insertId;

    await connection.commit();

    // Get the created teacher with related data
    const newTeacher = await getTeacherById({ params: { id: teacherId } }, res);

  } catch (error) {
    await connection.rollback();
    console.error('Create teacher error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

// Update teacher
const updateTeacher = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;
    const {
      first_name,
      last_name,
      email,
      phone,
      department_id,
      status
    } = req.body;

    // Check if teacher exists
    const existingTeacher = await executeQuery(
      'SELECT id FROM teachers WHERE id = ?',
      [id]
    );

    if (existingTeacher.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Teacher not found'
      });
    }

    // Check if email already exists (excluding current teacher)
    if (email) {
      const emailCheck = await executeQuery(
        'SELECT id FROM teachers WHERE email = ? AND id != ?',
        [email, id]
      );

      if (emailCheck.length > 0) {
        await connection.rollback();
        return res.status(400).json({
          success: false,
          message: 'Email already exists'
        });
      }
    }

    // Update teacher
    const updateQuery = `
      UPDATE teachers SET
        first_name = ?, last_name = ?, email = ?, phone = ?,
        department_id = ?, status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await connection.execute(updateQuery, [
      first_name, last_name, email, phone, department_id, status || 'Active', id
    ]);

    await connection.commit();

    // Get the updated teacher
    const updatedTeacher = await getTeacherById({ params: { id } }, res);

  } catch (error) {
    await connection.rollback();
    console.error('Update teacher error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

// Delete teacher
const deleteTeacher = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;

    // Check if teacher exists
    const existingTeacher = await executeQuery(
      'SELECT id FROM teachers WHERE id = ?',
      [id]
    );

    if (existingTeacher.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Teacher not found'
      });
    }

    // Delete related records
    await connection.execute('DELETE FROM schedule WHERE teacher_id = ?', [id]);
    await connection.execute('UPDATE users SET teacher_id = NULL WHERE teacher_id = ?', [id]);
    
    // Delete teacher
    await connection.execute('DELETE FROM teachers WHERE id = ?', [id]);

    await connection.commit();

    res.json({
      success: true,
      message: 'Teacher deleted successfully'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Delete teacher error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

module.exports = {
  getAllTeachers,
  getTeacherById,
  createTeacher,
  updateTeacher,
  deleteTeacher
};