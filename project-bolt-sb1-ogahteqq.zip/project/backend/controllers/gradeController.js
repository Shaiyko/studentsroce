const { executeQuery, getConnection } = require('../config/database');

// Get all grades
const getAllGrades = async (req, res) => {
  try {
    const { student_id = '', subject_id = '', grade_type = '' } = req.query;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (student_id) {
      whereClause += ' AND g.student_id = ?';
      params.push(student_id);
    }

    if (subject_id) {
      whereClause += ' AND g.subject_id = ?';
      params.push(subject_id);
    }

    if (grade_type) {
      whereClause += ' AND g.grade_type = ?';
      params.push(grade_type);
    }

    const query = `
      SELECT g.*, 
             CONCAT(st.first_name, ' ', st.last_name) as student_name,
             s.name as subject_name,
             d.name as department_name
      FROM grades g
      LEFT JOIN students st ON g.student_id = st.id
      LEFT JOIN subjects s ON g.subject_id = s.id
      LEFT JOIN departments d ON s.department_id = d.id
      ${whereClause}
      ORDER BY g.date_recorded DESC, st.first_name, st.last_name
    `;

    const grades = await executeQuery(query, params);

    res.json({
      success: true,
      data: grades
    });

  } catch (error) {
    console.error('Get grades error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get grade by ID
const getGradeById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT g.*, 
             CONCAT(st.first_name, ' ', st.last_name) as student_name,
             s.name as subject_name,
             d.name as department_name
      FROM grades g
      LEFT JOIN students st ON g.student_id = st.id
      LEFT JOIN subjects s ON g.subject_id = s.id
      LEFT JOIN departments d ON s.department_id = d.id
      WHERE g.id = ?
    `;

    const grades = await executeQuery(query, [id]);

    if (grades.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Grade not found'
      });
    }

    res.json({
      success: true,
      data: grades[0]
    });

  } catch (error) {
    console.error('Get grade error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new grade
const createGrade = async (req, res) => {
  try {
    const { student_id, subject_id, attendance_id, grade, grade_type, notes } = req.body;

    // Verify that the student is enrolled in the subject
    const enrollmentCheck = await executeQuery(
      'SELECT id FROM enrollment WHERE student_id = ? AND subject_id = ? AND status = "Enrolled"',
      [student_id, subject_id]
    );

    if (enrollmentCheck.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Student is not enrolled in this subject'
      });
    }

    // Insert grade
    const insertQuery = `
      INSERT INTO grades (student_id, subject_id, attendance_id, grade, grade_type, notes) 
      VALUES (?, ?, ?, ?, ?, ?)
    `;

    const result = await executeQuery(insertQuery, [
      student_id, subject_id, attendance_id, grade, grade_type, notes
    ]);

    const gradeId = result.insertId;

    // Get the created grade
    const newGrade = await getGradeById({ params: { id: gradeId } }, res);

  } catch (error) {
    console.error('Create grade error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Update grade
const updateGrade = async (req, res) => {
  try {
    const { id } = req.params;
    const { student_id, subject_id, attendance_id, grade, grade_type, notes } = req.body;

    // Check if grade exists
    const existingGrade = await executeQuery(
      'SELECT id FROM grades WHERE id = ?',
      [id]
    );

    if (existingGrade.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Grade not found'
      });
    }

    // Verify that the student is enrolled in the subject
    const enrollmentCheck = await executeQuery(
      'SELECT id FROM enrollment WHERE student_id = ? AND subject_id = ? AND status = "Enrolled"',
      [student_id, subject_id]
    );

    if (enrollmentCheck.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Student is not enrolled in this subject'
      });
    }

    // Update grade
    const updateQuery = `
      UPDATE grades SET
        student_id = ?, subject_id = ?, attendance_id = ?, grade = ?, grade_type = ?, notes = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await executeQuery(updateQuery, [
      student_id, subject_id, attendance_id, grade, grade_type, notes, id
    ]);

    // Get the updated grade
    const updatedGrade = await getGradeById({ params: { id } }, res);

  } catch (error) {
    console.error('Update grade error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Delete grade
const deleteGrade = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if grade exists
    const existingGrade = await executeQuery(
      'SELECT id FROM grades WHERE id = ?',
      [id]
    );

    if (existingGrade.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Grade not found'
      });
    }

    // Delete grade
    await executeQuery('DELETE FROM grades WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Grade deleted successfully'
    });

  } catch (error) {
    console.error('Delete grade error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

module.exports = {
  getAllGrades,
  getGradeById,
  createGrade,
  updateGrade,
  deleteGrade
};