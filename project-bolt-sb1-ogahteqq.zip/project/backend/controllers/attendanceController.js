const { executeQuery, getConnection } = require('../config/database');

// Get all attendance records
const getAllAttendance = async (req, res) => {
  try {
    const { student_id = '', subject_id = '', date = '', status = '' } = req.query;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (student_id) {
      whereClause += ' AND a.student_id = ?';
      params.push(student_id);
    }

    if (subject_id) {
      whereClause += ' AND a.subject_id = ?';
      params.push(subject_id);
    }

    if (date) {
      whereClause += ' AND a.date = ?';
      params.push(date);
    }

    if (status) {
      whereClause += ' AND a.status = ?';
      params.push(status);
    }

    const query = `
      SELECT a.*, 
             CONCAT(st.first_name, ' ', st.last_name) as student_name,
             s.name as subject_name,
             d.name as department_name
      FROM attendance a
      LEFT JOIN students st ON a.student_id = st.id
      LEFT JOIN subjects s ON a.subject_id = s.id
      LEFT JOIN departments d ON s.department_id = d.id
      ${whereClause}
      ORDER BY a.date DESC, st.first_name, st.last_name
    `;

    const attendance = await executeQuery(query, params);

    res.json({
      success: true,
      data: attendance
    });

  } catch (error) {
    console.error('Get attendance error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get attendance by ID
const getAttendanceById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT a.*, 
             CONCAT(st.first_name, ' ', st.last_name) as student_name,
             s.name as subject_name,
             d.name as department_name
      FROM attendance a
      LEFT JOIN students st ON a.student_id = st.id
      LEFT JOIN subjects s ON a.subject_id = s.id
      LEFT JOIN departments d ON s.department_id = d.id
      WHERE a.id = ?
    `;

    const attendance = await executeQuery(query, [id]);

    if (attendance.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Attendance record not found'
      });
    }

    res.json({
      success: true,
      data: attendance[0]
    });

  } catch (error) {
    console.error('Get attendance error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new attendance record
const createAttendance = async (req, res) => {
  try {
    const { student_id, subject_id, schedule_id, date, status, notes } = req.body;

    // Check if attendance already exists for this student, subject, and date
    const existingAttendance = await executeQuery(
      'SELECT id FROM attendance WHERE student_id = ? AND subject_id = ? AND date = ?',
      [student_id, subject_id, date]
    );

    if (existingAttendance.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Attendance already recorded for this student on this date'
      });
    }

    // Insert attendance
    const insertQuery = `
      INSERT INTO attendance (student_id, subject_id, schedule_id, date, status, notes) 
      VALUES (?, ?, ?, ?, ?, ?)
    `;

    const result = await executeQuery(insertQuery, [
      student_id, subject_id, schedule_id, date, status, notes
    ]);

    const attendanceId = result.insertId;

    // Get the created attendance
    const newAttendance = await getAttendanceById({ params: { id: attendanceId } }, res);

  } catch (error) {
    console.error('Create attendance error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Update attendance
const updateAttendance = async (req, res) => {
  try {
    const { id } = req.params;
    const { student_id, subject_id, schedule_id, date, status, notes } = req.body;

    // Check if attendance exists
    const existingAttendance = await executeQuery(
      'SELECT id FROM attendance WHERE id = ?',
      [id]
    );

    if (existingAttendance.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Attendance record not found'
      });
    }

    // Check if another attendance record exists for the same student, subject, and date (excluding current record)
    const duplicateCheck = await executeQuery(
      'SELECT id FROM attendance WHERE student_id = ? AND subject_id = ? AND date = ? AND id != ?',
      [student_id, subject_id, date, id]
    );

    if (duplicateCheck.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Attendance already recorded for this student on this date'
      });
    }

    // Update attendance
    const updateQuery = `
      UPDATE attendance SET
        student_id = ?, subject_id = ?, schedule_id = ?, date = ?, status = ?, notes = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await executeQuery(updateQuery, [
      student_id, subject_id, schedule_id, date, status, notes, id
    ]);

    // Get the updated attendance
    const updatedAttendance = await getAttendanceById({ params: { id } }, res);

  } catch (error) {
    console.error('Update attendance error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Delete attendance
const deleteAttendance = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;

    // Check if attendance exists
    const existingAttendance = await executeQuery(
      'SELECT id FROM attendance WHERE id = ?',
      [id]
    );

    if (existingAttendance.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Attendance record not found'
      });
    }

    // Delete related grades (set attendance_id to NULL)
    await connection.execute('UPDATE grades SET attendance_id = NULL WHERE attendance_id = ?', [id]);
    
    // Delete attendance
    await connection.execute('DELETE FROM attendance WHERE id = ?', [id]);

    await connection.commit();

    res.json({
      success: true,
      message: 'Attendance record deleted successfully'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Delete attendance error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

module.exports = {
  getAllAttendance,
  getAttendanceById,
  createAttendance,
  updateAttendance,
  deleteAttendance
};