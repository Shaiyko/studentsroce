const { executeQuery, getConnection } = require('../config/database');

// Get all subjects
const getAllSubjects = async (req, res) => {
  try {
    const { department_id = '' } = req.query;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (department_id) {
      whereClause += ' AND s.department_id = ?';
      params.push(department_id);
    }

    const query = `
      SELECT s.*, d.name as department_name,
        (SELECT COUNT(*) FROM enrollment WHERE subject_id = s.id) as enrollment_count
      FROM subjects s
      LEFT JOIN departments d ON s.department_id = d.id
      ${whereClause}
      ORDER BY d.name, s.name
    `;

    const subjects = await executeQuery(query, params);

    res.json({
      success: true,
      data: subjects
    });

  } catch (error) {
    console.error('Get subjects error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get subject by ID
const getSubjectById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT s.*, d.name as department_name,
        (SELECT COUNT(*) FROM enrollment WHERE subject_id = s.id) as enrollment_count
      FROM subjects s
      LEFT JOIN departments d ON s.department_id = d.id
      WHERE s.id = ?
    `;

    const subjects = await executeQuery(query, [id]);

    if (subjects.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Subject not found'
      });
    }

    res.json({
      success: true,
      data: subjects[0]
    });

  } catch (error) {
    console.error('Get subject error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new subject
const createSubject = async (req, res) => {
  try {
    const { name, code, credits, description, department_id } = req.body;

    // Check if subject name already exists in the same department
    const existingSubject = await executeQuery(
      'SELECT id FROM subjects WHERE name = ? AND department_id = ?',
      [name, department_id]
    );

    if (existingSubject.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Subject name already exists in this department'
      });
    }

    // Check if code already exists (if provided)
    if (code) {
      const existingCode = await executeQuery(
        'SELECT id FROM subjects WHERE code = ?',
        [code]
      );

      if (existingCode.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Subject code already exists'
        });
      }
    }

    // Insert subject
    const insertQuery = `
      INSERT INTO subjects (name, code, credits, description, department_id) 
      VALUES (?, ?, ?, ?, ?)
    `;

    const result = await executeQuery(insertQuery, [name, code, credits, description, department_id]);
    const subjectId = result.insertId;

    // Get the created subject
    const newSubject = await getSubjectById({ params: { id: subjectId } }, res);

  } catch (error) {
    console.error('Create subject error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Update subject
const updateSubject = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, code, credits, description, department_id } = req.body;

    // Check if subject exists
    const existingSubject = await executeQuery(
      'SELECT id FROM subjects WHERE id = ?',
      [id]
    );

    if (existingSubject.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Subject not found'
      });
    }

    // Check if name already exists in the same department (excluding current subject)
    const nameCheck = await executeQuery(
      'SELECT id FROM subjects WHERE name = ? AND department_id = ? AND id != ?',
      [name, department_id, id]
    );

    if (nameCheck.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Subject name already exists in this department'
      });
    }

    // Check if code already exists (excluding current subject)
    if (code) {
      const codeCheck = await executeQuery(
        'SELECT id FROM subjects WHERE code = ? AND id != ?',
        [code, id]
      );

      if (codeCheck.length > 0) {
        return res.status(400).json({
          success: false,
          message: 'Subject code already exists'
        });
      }
    }

    // Update subject
    const updateQuery = `
      UPDATE subjects SET
        name = ?, code = ?, credits = ?, description = ?, department_id = ?, 
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await executeQuery(updateQuery, [name, code, credits, description, department_id, id]);

    // Get the updated subject
    const updatedSubject = await getSubjectById({ params: { id } }, res);

  } catch (error) {
    console.error('Update subject error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Delete subject
const deleteSubject = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;

    // Check if subject exists
    const existingSubject = await executeQuery(
      'SELECT id FROM subjects WHERE id = ?',
      [id]
    );

    if (existingSubject.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Subject not found'
      });
    }

    // Check if subject has enrollments
    const enrollmentCount = await executeQuery(
      'SELECT COUNT(*) as count FROM enrollment WHERE subject_id = ?',
      [id]
    );

    if (enrollmentCount[0].count > 0) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: 'Cannot delete subject with existing enrollments'
      });
    }

    // Delete related records
    await connection.execute('DELETE FROM schedule WHERE subject_id = ?', [id]);
    await connection.execute('DELETE FROM grades WHERE subject_id = ?', [id]);
    await connection.execute('DELETE FROM attendance WHERE subject_id = ?', [id]);
    
    // Delete subject
    await connection.execute('DELETE FROM subjects WHERE id = ?', [id]);

    await connection.commit();

    res.json({
      success: true,
      message: 'Subject deleted successfully'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Delete subject error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

module.exports = {
  getAllSubjects,
  getSubjectById,
  createSubject,
  updateSubject,
  deleteSubject
};