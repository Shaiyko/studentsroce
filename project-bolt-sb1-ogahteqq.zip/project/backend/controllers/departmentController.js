const { executeQuery, getConnection } = require('../config/database');

// Get all departments
const getAllDepartments = async (req, res) => {
  try {
    const query = `
      SELECT d.*,
        (SELECT COUNT(*) FROM students WHERE department_id = d.id) as student_count,
        (SELECT COUNT(*) FROM teachers WHERE department_id = d.id) as teacher_count,
        (SELECT COUNT(*) FROM subjects WHERE department_id = d.id) as subject_count,
        (SELECT COUNT(*) FROM classrooms WHERE department_id = d.id) as classroom_count
      FROM departments d
      ORDER BY d.name
    `;

    const departments = await executeQuery(query);

    res.json({
      success: true,
      data: departments
    });

  } catch (error) {
    console.error('Get departments error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get department by ID
const getDepartmentById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT d.*,
        (SELECT COUNT(*) FROM students WHERE department_id = d.id) as student_count,
        (SELECT COUNT(*) FROM teachers WHERE department_id = d.id) as teacher_count,
        (SELECT COUNT(*) FROM subjects WHERE department_id = d.id) as subject_count,
        (SELECT COUNT(*) FROM classrooms WHERE department_id = d.id) as classroom_count
      FROM departments d
      WHERE d.id = ?
    `;

    const departments = await executeQuery(query, [id]);

    if (departments.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Department not found'
      });
    }

    res.json({
      success: true,
      data: departments[0]
    });

  } catch (error) {
    console.error('Get department error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new department
const createDepartment = async (req, res) => {
  try {
    const { name, description } = req.body;

    // Check if department name already exists
    const existingDepartment = await executeQuery(
      'SELECT id FROM departments WHERE name = ?',
      [name]
    );

    if (existingDepartment.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Department name already exists'
      });
    }

    // Insert department
    const insertQuery = `
      INSERT INTO departments (name, description) VALUES (?, ?)
    `;

    const result = await executeQuery(insertQuery, [name, description]);
    const departmentId = result.insertId;

    // Get the created department
    const newDepartment = await getDepartmentById({ params: { id: departmentId } }, res);

  } catch (error) {
    console.error('Create department error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Update department
const updateDepartment = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description } = req.body;

    // Check if department exists
    const existingDepartment = await executeQuery(
      'SELECT id FROM departments WHERE id = ?',
      [id]
    );

    if (existingDepartment.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Department not found'
      });
    }

    // Check if name already exists (excluding current department)
    const nameCheck = await executeQuery(
      'SELECT id FROM departments WHERE name = ? AND id != ?',
      [name, id]
    );

    if (nameCheck.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Department name already exists'
      });
    }

    // Update department
    const updateQuery = `
      UPDATE departments SET
        name = ?, description = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await executeQuery(updateQuery, [name, description, id]);

    // Get the updated department
    const updatedDepartment = await getDepartmentById({ params: { id } }, res);

  } catch (error) {
    console.error('Update department error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Delete department
const deleteDepartment = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;

    // Check if department exists
    const existingDepartment = await executeQuery(
      'SELECT id FROM departments WHERE id = ?',
      [id]
    );

    if (existingDepartment.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Department not found'
      });
    }

    // Check if department has students or teachers
    const studentCount = await executeQuery(
      'SELECT COUNT(*) as count FROM students WHERE department_id = ?',
      [id]
    );

    const teacherCount = await executeQuery(
      'SELECT COUNT(*) as count FROM teachers WHERE department_id = ?',
      [id]
    );

    if (studentCount[0].count > 0 || teacherCount[0].count > 0) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: 'Cannot delete department with existing students or teachers'
      });
    }

    // Delete department (cascading will handle subjects and classrooms)
    await connection.execute('DELETE FROM departments WHERE id = ?', [id]);

    await connection.commit();

    res.json({
      success: true,
      message: 'Department deleted successfully'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Delete department error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

module.exports = {
  getAllDepartments,
  getDepartmentById,
  createDepartment,
  updateDepartment,
  deleteDepartment
};