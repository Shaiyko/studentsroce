const { executeQuery, getConnection } = require('../config/database');

// Get all fees
const getAllFees = async (req, res) => {
  try {
    const { student_id = '', status = '', fee_type = '' } = req.query;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (student_id) {
      whereClause += ' AND f.student_id = ?';
      params.push(student_id);
    }

    if (status) {
      whereClause += ' AND f.status = ?';
      params.push(status);
    }

    if (fee_type) {
      whereClause += ' AND f.fee_type = ?';
      params.push(fee_type);
    }

    const query = `
      SELECT f.*, 
             CONCAT(st.first_name, ' ', st.last_name) as student_name,
             d.name as department_name
      FROM fees f
      LEFT JOIN students st ON f.student_id = st.id
      LEFT JOIN departments d ON st.department_id = d.id
      ${whereClause}
      ORDER BY f.due_date DESC, st.first_name, st.last_name
    `;

    const fees = await executeQuery(query, params);

    res.json({
      success: true,
      data: fees
    });

  } catch (error) {
    console.error('Get fees error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get fee by ID
const getFeeById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT f.*, 
             CONCAT(st.first_name, ' ', st.last_name) as student_name,
             d.name as department_name
      FROM fees f
      LEFT JOIN students st ON f.student_id = st.id
      LEFT JOIN departments d ON st.department_id = d.id
      WHERE f.id = ?
    `;

    const fees = await executeQuery(query, [id]);

    if (fees.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Fee record not found'
      });
    }

    res.json({
      success: true,
      data: fees[0]
    });

  } catch (error) {
    console.error('Get fee error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new fee
const createFee = async (req, res) => {
  try {
    const { student_id, amount, fee_type, due_date, notes } = req.body;

    // Insert fee
    const insertQuery = `
      INSERT INTO fees (student_id, amount, fee_type, due_date, notes) 
      VALUES (?, ?, ?, ?, ?)
    `;

    const result = await executeQuery(insertQuery, [
      student_id, amount, fee_type || 'Tuition', due_date, notes
    ]);

    const feeId = result.insertId;

    // Get the created fee
    const newFee = await getFeeById({ params: { id: feeId } }, res);

  } catch (error) {
    console.error('Create fee error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Update fee
const updateFee = async (req, res) => {
  try {
    const { id } = req.params;
    const { student_id, amount, fee_type, due_date, paid_date, status, payment_method, notes } = req.body;

    // Check if fee exists
    const existingFee = await executeQuery(
      'SELECT id FROM fees WHERE id = ?',
      [id]
    );

    if (existingFee.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Fee record not found'
      });
    }

    // Update fee
    const updateQuery = `
      UPDATE fees SET
        student_id = ?, amount = ?, fee_type = ?, due_date = ?, paid_date = ?, 
        status = ?, payment_method = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await executeQuery(updateQuery, [
      student_id, amount, fee_type, due_date, paid_date, status, payment_method, notes, id
    ]);

    // Get the updated fee
    const updatedFee = await getFeeById({ params: { id } }, res);

  } catch (error) {
    console.error('Update fee error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Delete fee
const deleteFee = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if fee exists
    const existingFee = await executeQuery(
      'SELECT id FROM fees WHERE id = ?',
      [id]
    );

    if (existingFee.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Fee record not found'
      });
    }

    // Delete fee
    await executeQuery('DELETE FROM fees WHERE id = ?', [id]);

    res.json({
      success: true,
      message: 'Fee record deleted successfully'
    });

  } catch (error) {
    console.error('Delete fee error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

module.exports = {
  getAllFees,
  getFeeById,
  createFee,
  updateFee,
  deleteFee
};