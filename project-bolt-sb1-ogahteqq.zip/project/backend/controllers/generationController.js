const { executeQuery } = require('../config/database');

// Get all generations
const getAllGenerations = async (req, res) => {
  try {
    const query = `
      SELECT g.*,
        (SELECT COUNT(*) FROM students WHERE generation_id = g.id) as student_count
      FROM generations g
      ORDER BY g.start_year DESC
    `;

    const generations = await executeQuery(query);

    res.json({
      success: true,
      data: generations
    });

  } catch (error) {
    console.error('Get generations error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

module.exports = {
  getAllGenerations
};