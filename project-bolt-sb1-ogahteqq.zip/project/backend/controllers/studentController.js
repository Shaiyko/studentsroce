const { executeQuery, getConnection } = require('../config/database');

// Get all students (admin only)
const getAllStudents = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = '', department_id = '' } = req.query;
    const offset = (page - 1) * limit;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (search) {
      whereClause += ' AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.email LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (department_id) {
      whereClause += ' AND s.department_id = ?';
      params.push(department_id);
    }

    const query = `
      SELECT s.*, 
             d.name as department_name,
             c.name as classroom_name,
             g.name as generation_name
      FROM students s
      LEFT JOIN departments d ON s.department_id = d.id
      LEFT JOIN classrooms c ON s.classroom_id = c.id
      LEFT JOIN generations g ON s.generation_id = g.id
      ${whereClause}
      ORDER BY s.created_at DESC
      LIMIT ? OFFSET ?
    `;

    const countQuery = `
      SELECT COUNT(*) as total
      FROM students s
      ${whereClause}
    `;

    const students = await executeQuery(query, [...params, parseInt(limit), parseInt(offset)]);
    const countResult = await executeQuery(countQuery, params);
    const total = countResult[0].total;

    res.json({
      success: true,
      data: {
        students,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      }
    });

  } catch (error) {
    console.error('Get students error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get student by ID
const getStudentById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT s.*, 
             d.name as department_name,
             c.name as classroom_name,
             g.name as generation_name
      FROM students s
      LEFT JOIN departments d ON s.department_id = d.id
      LEFT JOIN classrooms c ON s.classroom_id = c.id
      LEFT JOIN generations g ON s.generation_id = g.id
      WHERE s.id = ?
    `;

    const students = await executeQuery(query, [id]);

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }

    res.json({
      success: true,
      data: students[0]
    });

  } catch (error) {
    console.error('Get student error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new student
const createStudent = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const {
      first_name,
      last_name,
      gender,
      dob,
      email,
      phone,
      address,
      department_id,
      classroom_id,
      generation_id
    } = req.body;

    // Check if email already exists
    if (email) {
      const existingStudent = await executeQuery(
        'SELECT id FROM students WHERE email = ?',
        [email]
      );

      if (existingStudent.length > 0) {
        await connection.rollback();
        return res.status(400).json({
          success: false,
          message: 'Email already exists'
        });
      }
    }

    // Insert student
    const insertQuery = `
      INSERT INTO students (
        first_name, last_name, gender, dob, email, phone, address,
        department_id, classroom_id, generation_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const result = await connection.execute(insertQuery, [
      first_name, last_name, gender, dob, email, phone, address,
      department_id, classroom_id, generation_id
    ]);

    const studentId = result[0].insertId;

    await connection.commit();

    // Get the created student with related data
    const newStudent = await getStudentById({ params: { id: studentId } }, res);

  } catch (error) {
    await connection.rollback();
    console.error('Create student error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

// Update student
const updateStudent = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;
    const {
      first_name,
      last_name,
      gender,
      dob,
      email,
      phone,
      address,
      department_id,
      classroom_id,
      generation_id,
      status
    } = req.body;

    // Check if student exists
    const existingStudent = await executeQuery(
      'SELECT id FROM students WHERE id = ?',
      [id]
    );

    if (existingStudent.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }

    // Check if email already exists (excluding current student)
    if (email) {
      const emailCheck = await executeQuery(
        'SELECT id FROM students WHERE email = ? AND id != ?',
        [email, id]
      );

      if (emailCheck.length > 0) {
        await connection.rollback();
        return res.status(400).json({
          success: false,
          message: 'Email already exists'
        });
      }
    }

    // Update student
    const updateQuery = `
      UPDATE students SET
        first_name = ?, last_name = ?, gender = ?, dob = ?,
        email = ?, phone = ?, address = ?, department_id = ?,
        classroom_id = ?, generation_id = ?, status = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await connection.execute(updateQuery, [
      first_name, last_name, gender, dob, email, phone, address,
      department_id, classroom_id, generation_id, status || 'Active', id
    ]);

    await connection.commit();

    // Get the updated student
    const updatedStudent = await getStudentById({ params: { id } }, res);

  } catch (error) {
    await connection.rollback();
    console.error('Update student error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

// Delete student
const deleteStudent = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;

    // Check if student exists
    const existingStudent = await executeQuery(
      'SELECT id FROM students WHERE id = ?',
      [id]
    );

    if (existingStudent.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }

    // Delete related records (cascading delete)
    await connection.execute('DELETE FROM fees WHERE student_id = ?', [id]);
    await connection.execute('DELETE FROM grades WHERE student_id = ?', [id]);
    await connection.execute('DELETE FROM attendance WHERE student_id = ?', [id]);
    await connection.execute('DELETE FROM enrollment WHERE student_id = ?', [id]);
    await connection.execute('UPDATE users SET student_id = NULL WHERE student_id = ?', [id]);
    
    // Delete student
    await connection.execute('DELETE FROM students WHERE id = ?', [id]);

    await connection.commit();

    res.json({
      success: true,
      message: 'Student deleted successfully'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Delete student error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

// Get student academic data (for student portal)
const getStudentAcademicData = async (req, res) => {
  try {
    const studentId = req.user.student_id || req.params.studentId;

    if (!studentId) {
      return res.status(400).json({
        success: false,
        message: 'Student ID is required'
      });
    }

    // Get student basic info
    const studentQuery = `
      SELECT s.*, 
             d.name as department_name,
             c.name as classroom_name,
             g.name as generation_name
      FROM students s
      LEFT JOIN departments d ON s.department_id = d.id
      LEFT JOIN classrooms c ON s.classroom_id = c.id
      LEFT JOIN generations g ON s.generation_id = g.id
      WHERE s.id = ?
    `;

    const students = await executeQuery(studentQuery, [studentId]);

    if (students.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Student not found'
      });
    }

    const student = students[0];

    // Get enrolled subjects
    const subjectsQuery = `
      SELECT s.*, d.name as department_name
      FROM subjects s
      JOIN enrollment e ON s.id = e.subject_id
      LEFT JOIN departments d ON s.department_id = d.id
      WHERE e.student_id = ? AND e.status = 'Enrolled'
    `;

    const subjects = await executeQuery(subjectsQuery, [studentId]);

    // Get schedule
    const scheduleQuery = `
      SELECT sc.*, s.name as subject_name, 
             CONCAT(t.first_name, ' ', t.last_name) as teacher_name,
             c.name as classroom_name
      FROM schedule sc
      JOIN subjects s ON sc.subject_id = s.id
      JOIN teachers t ON sc.teacher_id = t.id
      JOIN classrooms c ON sc.classroom_id = c.id
      JOIN enrollment e ON s.id = e.subject_id
      WHERE e.student_id = ? AND e.status = 'Enrolled'
      ORDER BY 
        FIELD(sc.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'),
        sc.start_time
    `;

    const schedule = await executeQuery(scheduleQuery, [studentId]);

    // Get attendance
    const attendanceQuery = `
      SELECT a.*, s.name as subject_name
      FROM attendance a
      JOIN subjects s ON a.subject_id = s.id
      WHERE a.student_id = ?
      ORDER BY a.date DESC
    `;

    const attendance = await executeQuery(attendanceQuery, [studentId]);

    // Get grades
    const gradesQuery = `
      SELECT g.*, s.name as subject_name
      FROM grades g
      JOIN subjects s ON g.subject_id = s.id
      WHERE g.student_id = ?
      ORDER BY g.date_recorded DESC
    `;

    const grades = await executeQuery(gradesQuery, [studentId]);

    // Get fees
    const feesQuery = `
      SELECT * FROM fees
      WHERE student_id = ?
      ORDER BY due_date DESC
    `;

    const fees = await executeQuery(feesQuery, [studentId]);

    res.json({
      success: true,
      data: {
        student,
        subjects,
        schedule,
        attendance,
        grades,
        fees
      }
    });

  } catch (error) {
    console.error('Get student academic data error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

module.exports = {
  getAllStudents,
  getStudentById,
  createStudent,
  updateStudent,
  deleteStudent,
  getStudentAcademicData
};