const { executeQuery, getConnection } = require('../config/database');

// Get all classrooms
const getAllClassrooms = async (req, res) => {
  try {
    const { department_id = '' } = req.query;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (department_id) {
      whereClause += ' AND c.department_id = ?';
      params.push(department_id);
    }

    const query = `
      SELECT c.*, d.name as department_name,
        (SELECT COUNT(*) FROM students WHERE classroom_id = c.id) as student_count
      FROM classrooms c
      LEFT JOIN departments d ON c.department_id = d.id
      ${whereClause}
      ORDER BY d.name, c.name
    `;

    const classrooms = await executeQuery(query, params);

    res.json({
      success: true,
      data: classrooms
    });

  } catch (error) {
    console.error('Get classrooms error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get classroom by ID
const getClassroomById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT c.*, d.name as department_name,
        (SELECT COUNT(*) FROM students WHERE classroom_id = c.id) as student_count
      FROM classrooms c
      LEFT JOIN departments d ON c.department_id = d.id
      WHERE c.id = ?
    `;

    const classrooms = await executeQuery(query, [id]);

    if (classrooms.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    res.json({
      success: true,
      data: classrooms[0]
    });

  } catch (error) {
    console.error('Get classroom error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new classroom
const createClassroom = async (req, res) => {
  try {
    const { name, capacity, department_id } = req.body;

    // Check if classroom name already exists in the same department
    const existingClassroom = await executeQuery(
      'SELECT id FROM classrooms WHERE name = ? AND department_id = ?',
      [name, department_id]
    );

    if (existingClassroom.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Classroom name already exists in this department'
      });
    }

    // Insert classroom
    const insertQuery = `
      INSERT INTO classrooms (name, capacity, department_id) VALUES (?, ?, ?)
    `;

    const result = await executeQuery(insertQuery, [name, capacity, department_id]);
    const classroomId = result.insertId;

    // Get the created classroom
    const newClassroom = await getClassroomById({ params: { id: classroomId } }, res);

  } catch (error) {
    console.error('Create classroom error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Update classroom
const updateClassroom = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, capacity, department_id } = req.body;

    // Check if classroom exists
    const existingClassroom = await executeQuery(
      'SELECT id FROM classrooms WHERE id = ?',
      [id]
    );

    if (existingClassroom.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    // Check if name already exists in the same department (excluding current classroom)
    const nameCheck = await executeQuery(
      'SELECT id FROM classrooms WHERE name = ? AND department_id = ? AND id != ?',
      [name, department_id, id]
    );

    if (nameCheck.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Classroom name already exists in this department'
      });
    }

    // Update classroom
    const updateQuery = `
      UPDATE classrooms SET
        name = ?, capacity = ?, department_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await executeQuery(updateQuery, [name, capacity, department_id, id]);

    // Get the updated classroom
    const updatedClassroom = await getClassroomById({ params: { id } }, res);

  } catch (error) {
    console.error('Update classroom error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Delete classroom
const deleteClassroom = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;

    // Check if classroom exists
    const existingClassroom = await executeQuery(
      'SELECT id FROM classrooms WHERE id = ?',
      [id]
    );

    if (existingClassroom.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Classroom not found'
      });
    }

    // Check if classroom has students
    const studentCount = await executeQuery(
      'SELECT COUNT(*) as count FROM students WHERE classroom_id = ?',
      [id]
    );

    if (studentCount[0].count > 0) {
      await connection.rollback();
      return res.status(400).json({
        success: false,
        message: 'Cannot delete classroom with existing students'
      });
    }

    // Delete related schedule records
    await connection.execute('DELETE FROM schedule WHERE classroom_id = ?', [id]);
    
    // Delete classroom
    await connection.execute('DELETE FROM classrooms WHERE id = ?', [id]);

    await connection.commit();

    res.json({
      success: true,
      message: 'Classroom deleted successfully'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Delete classroom error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

module.exports = {
  getAllClassrooms,
  getClassroomById,
  createClassroom,
  updateClassroom,
  deleteClassroom
};