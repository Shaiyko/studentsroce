const { executeQuery, getConnection } = require('../config/database');

// Get all enrollments
const getAllEnrollments = async (req, res) => {
  try {
    const { student_id = '', subject_id = '' } = req.query;

    let whereClause = 'WHERE 1=1';
    let params = [];

    if (student_id) {
      whereClause += ' AND e.student_id = ?';
      params.push(student_id);
    }

    if (subject_id) {
      whereClause += ' AND e.subject_id = ?';
      params.push(subject_id);
    }

    const query = `
      SELECT e.*, 
             CONCAT(st.first_name, ' ', st.last_name) as student_name,
             s.name as subject_name,
             d.name as department_name
      FROM enrollment e
      LEFT JOIN students st ON e.student_id = st.id
      LEFT JOIN subjects s ON e.subject_id = s.id
      LEFT JOIN departments d ON s.department_id = d.id
      ${whereClause}
      ORDER BY e.enrollment_date DESC
    `;

    const enrollments = await executeQuery(query, params);

    res.json({
      success: true,
      data: enrollments
    });

  } catch (error) {
    console.error('Get enrollments error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Get enrollment by ID
const getEnrollmentById = async (req, res) => {
  try {
    const { id } = req.params;

    const query = `
      SELECT e.*, 
             CONCAT(st.first_name, ' ', st.last_name) as student_name,
             s.name as subject_name,
             d.name as department_name
      FROM enrollment e
      LEFT JOIN students st ON e.student_id = st.id
      LEFT JOIN subjects s ON e.subject_id = s.id
      LEFT JOIN departments d ON s.department_id = d.id
      WHERE e.id = ?
    `;

    const enrollments = await executeQuery(query, [id]);

    if (enrollments.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Enrollment not found'
      });
    }

    res.json({
      success: true,
      data: enrollments[0]
    });

  } catch (error) {
    console.error('Get enrollment error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Create new enrollment
const createEnrollment = async (req, res) => {
  try {
    const { student_id, subject_id } = req.body;

    // Check if enrollment already exists
    const existingEnrollment = await executeQuery(
      'SELECT id FROM enrollment WHERE student_id = ? AND subject_id = ?',
      [student_id, subject_id]
    );

    if (existingEnrollment.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Student is already enrolled in this subject'
      });
    }

    // Insert enrollment
    const insertQuery = `
      INSERT INTO enrollment (student_id, subject_id) VALUES (?, ?)
    `;

    const result = await executeQuery(insertQuery, [student_id, subject_id]);
    const enrollmentId = result.insertId;

    // Get the created enrollment
    const newEnrollment = await getEnrollmentById({ params: { id: enrollmentId } }, res);

  } catch (error) {
    console.error('Create enrollment error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Update enrollment
const updateEnrollment = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    // Check if enrollment exists
    const existingEnrollment = await executeQuery(
      'SELECT id FROM enrollment WHERE id = ?',
      [id]
    );

    if (existingEnrollment.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Enrollment not found'
      });
    }

    // Update enrollment
    const updateQuery = `
      UPDATE enrollment SET
        status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;

    await executeQuery(updateQuery, [status, id]);

    // Get the updated enrollment
    const updatedEnrollment = await getEnrollmentById({ params: { id } }, res);

  } catch (error) {
    console.error('Update enrollment error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
};

// Delete enrollment
const deleteEnrollment = async (req, res) => {
  const connection = await getConnection();
  
  try {
    await connection.beginTransaction();

    const { id } = req.params;

    // Check if enrollment exists
    const existingEnrollment = await executeQuery(
      'SELECT student_id, subject_id FROM enrollment WHERE id = ?',
      [id]
    );

    if (existingEnrollment.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: 'Enrollment not found'
      });
    }

    const { student_id, subject_id } = existingEnrollment[0];

    // Delete related records
    await connection.execute(
      'DELETE FROM attendance WHERE student_id = ? AND subject_id = ?', 
      [student_id, subject_id]
    );
    await connection.execute(
      'DELETE FROM grades WHERE student_id = ? AND subject_id = ?', 
      [student_id, subject_id]
    );
    
    // Delete enrollment
    await connection.execute('DELETE FROM enrollment WHERE id = ?', [id]);

    await connection.commit();

    res.json({
      success: true,
      message: 'Enrollment deleted successfully'
    });

  } catch (error) {
    await connection.rollback();
    console.error('Delete enrollment error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  } finally {
    connection.release();
  }
};

module.exports = {
  getAllEnrollments,
  getEnrollmentById,
  createEnrollment,
  updateEnrollment,
  deleteEnrollment
};