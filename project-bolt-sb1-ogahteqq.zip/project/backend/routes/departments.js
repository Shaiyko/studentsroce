const express = require('express');
const {
  getAllDepartments,
  getDepartmentById,
  createDepartment,
  updateDepartment,
  deleteDepartment
} = require('../controllers/departmentController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { validateDepartment, validateId } = require('../middleware/validation');
const router = express.Router();

// All department routes require admin access
router.get('/', authenticateToken, requireAdmin, getAllDepartments);
router.get('/:id', authenticateToken, requireAdmin, validateId, getDepartmentById);
router.post('/', authenticateToken, requireAdmin, validateDepartment, createDepartment);
router.put('/:id', authenticateToken, requireAdmin, validateId, validateDepartment, updateDepartment);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteDepartment);

module.exports = router;