const express = require('express');
const {
  getAllSubjects,
  getSubjectById,
  createSubject,
  updateSubject,
  deleteSubject
} = require('../controllers/subjectController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { validateSubject, validateId } = require('../middleware/validation');
const router = express.Router();

// All subject routes require admin access
router.get('/', authenticateToken, requireAdmin, getAllSubjects);
router.get('/:id', authenticateToken, requireAdmin, validateId, getSubjectById);
router.post('/', authenticateToken, requireAdmin, validateSubject, createSubject);
router.put('/:id', authenticateToken, requireAdmin, validateId, validateSubject, updateSubject);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteSubject);

module.exports = router;