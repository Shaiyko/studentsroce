const express = require('express');
const {
  getAllFees,
  getFeeById,
  createFee,
  updateFee,
  deleteFee
} = require('../controllers/feeController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { validateFee, validateId } = require('../middleware/validation');
const router = express.Router();

// All fee routes require admin access
router.get('/', authenticateToken, requireAdmin, getAllFees);
router.get('/:id', authenticateToken, requireAdmin, validateId, getFeeById);
router.post('/', authenticateToken, requireAdmin, validateFee, createFee);
router.put('/:id', authenticateToken, requireAdmin, validateId, validateFee, updateFee);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteFee);

module.exports = router;