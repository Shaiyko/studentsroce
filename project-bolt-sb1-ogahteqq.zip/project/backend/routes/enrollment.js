const express = require('express');
const {
  getAllEnrollments,
  getEnrollmentById,
  createEnrollment,
  updateEnrollment,
  deleteEnrollment
} = require('../controllers/enrollmentController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { validateEnrollment, validateId } = require('../middleware/validation');
const router = express.Router();

// All enrollment routes require admin access
router.get('/', authenticateToken, requireAdmin, getAllEnrollments);
router.get('/:id', authenticateToken, requireAdmin, validateId, getEnrollmentById);
router.post('/', authenticateToken, requireAdmin, validateEnrollment, createEnrollment);
router.put('/:id', authenticateToken, requireAdmin, validateId, updateEnrollment);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteEnrollment);

module.exports = router;