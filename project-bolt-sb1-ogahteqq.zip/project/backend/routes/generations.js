const express = require('express');
const { getAllGenerations } = require('../controllers/generationController');
const { authenticateToken } = require('../middleware/auth');
const router = express.Router();

// Get all generations (accessible to all authenticated users)
router.get('/', authenticateToken, getAllGenerations);

module.exports = router;