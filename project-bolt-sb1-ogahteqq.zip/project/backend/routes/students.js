const express = require('express');
const {
  getAllStudents,
  getStudentById,
  createStudent,
  updateStudent,
  deleteStudent,
  getStudentAcademicData
} = require('../controllers/studentController');
const { authenticateToken, requireAdmin, canAccessStudent } = require('../middleware/auth');
const { validateStudent, validateId } = require('../middleware/validation');
const router = express.Router();

// Admin routes
router.get('/', authenticateToken, requireAdmin, getAllStudents);
router.get('/:id', authenticateToken, requireAdmin, validateId, getStudentById);
router.post('/', authenticateToken, requireAdmin, validateStudent, createStudent);
router.put('/:id', authenticateToken, requireAdmin, validateId, validateStudent, updateStudent);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteStudent);

// Student portal routes
router.get('/:studentId/academic-data', authenticateToken, canAccessStudent, getStudentAcademicData);

module.exports = router;