const express = require('express');
const {
  getAllTeachers,
  getTeacherById,
  createTeacher,
  updateTeacher,
  deleteTeacher
} = require('../controllers/teacherController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { validateTeacher, validateId } = require('../middleware/validation');
const router = express.Router();

// All teacher routes require admin access
router.get('/', authenticateToken, requireAdmin, getAllTeachers);
router.get('/:id', authenticateToken, requireAdmin, validateId, getTeacherById);
router.post('/', authenticateToken, requireAdmin, validateTeacher, createTeacher);
router.put('/:id', authenticateToken, requireAdmin, validateId, validateTeacher, updateTeacher);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteTeacher);

module.exports = router;