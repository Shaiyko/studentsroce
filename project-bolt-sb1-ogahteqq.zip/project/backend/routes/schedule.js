const express = require('express');
const {
  getAllSchedule,
  getScheduleById,
  createSchedule,
  updateSchedule,
  deleteSchedule
} = require('../controllers/scheduleController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { validateSchedule, validateId } = require('../middleware/validation');
const router = express.Router();

// All schedule routes require admin access
router.get('/', authenticateToken, requireAdmin, getAllSchedule);
router.get('/:id', authenticateToken, requireAdmin, validateId, getScheduleById);
router.post('/', authenticateToken, requireAdmin, validateSchedule, createSchedule);
router.put('/:id', authenticateToken, requireAdmin, validateId, validateSchedule, updateSchedule);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteSchedule);

module.exports = router;