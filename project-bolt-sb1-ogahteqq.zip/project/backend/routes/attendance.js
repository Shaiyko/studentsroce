const express = require('express');
const {
  getAllAttendance,
  getAttendanceById,
  createAttendance,
  updateAttendance,
  deleteAttendance
} = require('../controllers/attendanceController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { validateAttendance, validateId } = require('../middleware/validation');
const router = express.Router();

// All attendance routes require admin access
router.get('/', authenticateToken, requireAdmin, getAllAttendance);
router.get('/:id', authenticateToken, requireAdmin, validateId, getAttendanceById);
router.post('/', authenticateToken, requireAdmin, validateAttendance, createAttendance);
router.put('/:id', authenticateToken, requireAdmin, validateId, validateAttendance, updateAttendance);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteAttendance);

module.exports = router;