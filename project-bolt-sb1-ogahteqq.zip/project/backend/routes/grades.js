const express = require('express');
const {
  getAllGrades,
  getGradeById,
  createGrade,
  updateGrade,
  deleteGrade
} = require('../controllers/gradeController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { validateGrade, validateId } = require('../middleware/validation');
const router = express.Router();

// All grade routes require admin access
router.get('/', authenticateToken, requireAdmin, getAllGrades);
router.get('/:id', authenticateToken, requireAdmin, validateId, getGradeById);
router.post('/', authenticateToken, requireAdmin, validateGrade, createGrade);
router.put('/:id', authenticateToken, requireAdmin, validateId, validateGrade, updateGrade);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteGrade);

module.exports = router;