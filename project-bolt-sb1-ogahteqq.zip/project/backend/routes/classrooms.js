const express = require('express');
const {
  getAllClassrooms,
  getClassroomById,
  createClassroom,
  updateClassroom,
  deleteClassroom
} = require('../controllers/classroomController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { validateClassroom, validateId } = require('../middleware/validation');
const router = express.Router();

// All classroom routes require admin access
router.get('/', authenticateToken, requireAdmin, getAllClassrooms);
router.get('/:id', authenticateToken, requireAdmin, validateId, getClassroomById);
router.post('/', authenticateToken, requireAdmin, validateClassroom, createClassroom);
router.put('/:id', authenticateToken, requireAdmin, validateId, validateClassroom, updateClassroom);
router.delete('/:id', authenticateToken, requireAdmin, validateId, deleteClassroom);

module.exports = router;