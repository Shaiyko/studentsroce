-- Sample data for School Management System
USE school_management;

-- Insert Generations
INSERT INTO generations (name, start_year, end_year) VALUES
('2020-2024', 2020, 2024),
('2021-2025', 2021, 2025),
('2022-2026', 2022, 2026),
('2023-2027', 2023, 2027);

-- Insert Departments
INSERT INTO departments (name, description) VALUES
('Computer Science', 'Department of Computer Science and Information Technology'),
('Mathematics', 'Department of Mathematics and Statistics'),
('Physics', 'Department of Physics and Applied Sciences'),
('Chemistry', 'Department of Chemistry and Chemical Engineering'),
('Biology', 'Department of Biology and Life Sciences'),
('English', 'Department of English Literature and Language'),
('Business', 'Department of Business Administration');

-- Insert Classrooms
INSERT INTO classrooms (name, capacity, department_id) VALUES
('CS-101', 30, 1),
('CS-102', 25, 1),
('MATH-201', 40, 2),
('MATH-202', 35, 2),
('PHY-301', 25, 3),
('PHY-302', 30, 3),
('CHEM-401', 35, 4),
('CHEM-402', 28, 4),
('BIO-501', 28, 5),
('BIO-502', 32, 5),
('ENG-601', 45, 6),
('BUS-701', 50, 7);

-- Insert Students
INSERT INTO students (first_name, last_name, gender, dob, email, phone, department_id, classroom_id, generation_id) VALUES
('John', 'Doe', 'Male', '2001-05-15', 'john.doe@school.edu', '555-0101', 1, 1, 2),
('Jane', 'Smith', 'Female', '2000-08-22', 'jane.smith@school.edu', '555-0102', 1, 1, 2),
('Mike', 'Johnson', 'Male', '2002-01-10', 'mike.johnson@school.edu', '555-0103', 2, 3, 3),
('Sarah', 'Williams', 'Female', '2001-11-03', 'sarah.williams@school.edu', '555-0104', 3, 5, 2),
('David', 'Brown', 'Male', '2000-07-18', 'david.brown@school.edu', '555-0105', 4, 7, 1),
('Emily', 'Davis', 'Female', '2002-03-25', 'emily.davis@school.edu', '555-0106', 5, 9, 3),
('Alex', 'Wilson', 'Other', '2001-09-12', 'alex.wilson@school.edu', '555-0107', 1, 2, 2),
('Lisa', 'Anderson', 'Female', '2000-12-08', 'lisa.anderson@school.edu', '555-0108', 2, 4, 1),
('Chris', 'Taylor', 'Male', '2002-06-30', 'chris.taylor@school.edu', '555-0109', 6, 11, 3),
('Maria', 'Garcia', 'Female', '2001-04-17', 'maria.garcia@school.edu', '555-0110', 7, 12, 2);

-- Insert Teachers
INSERT INTO teachers (first_name, last_name, email, phone, department_id) VALUES
('Dr. Sarah', 'Wilson', 'sarah.wilson@school.edu', '555-1001', 1),
('Prof. David', 'Brown', 'david.brown@school.edu', '555-1002', 1),
('Dr. Lisa', 'Anderson', 'lisa.anderson@school.edu', '555-1003', 2),
('Prof. Robert', 'Taylor', 'robert.taylor@school.edu', '555-1004', 3),
('Dr. Emily', 'Davis', 'emily.davis@school.edu', '555-1005', 4),
('Prof. Michael', 'Miller', 'michael.miller@school.edu', '555-1006', 5),
('Dr. Jennifer', 'White', 'jennifer.white@school.edu', '555-1007', 6),
('Prof. James', 'Clark', 'james.clark@school.edu', '555-1008', 7);

-- Insert Subjects
INSERT INTO subjects (name, code, credits, description, department_id) VALUES
('Data Structures', 'CS101', 3, 'Introduction to data structures and algorithms', 1),
('Algorithms', 'CS102', 3, 'Advanced algorithms and complexity analysis', 1),
('Database Systems', 'CS201', 4, 'Database design and management systems', 1),
('Web Development', 'CS301', 3, 'Modern web development technologies', 1),
('Linear Algebra', 'MATH101', 3, 'Vectors, matrices, and linear transformations', 2),
('Calculus II', 'MATH201', 4, 'Integral calculus and applications', 2),
('Statistics', 'MATH301', 3, 'Probability and statistical analysis', 2),
('Quantum Physics', 'PHY301', 4, 'Introduction to quantum mechanics', 3),
('Classical Mechanics', 'PHY101', 3, 'Newtonian mechanics and dynamics', 3),
('Organic Chemistry', 'CHEM201', 4, 'Organic compounds and reactions', 4),
('Cell Biology', 'BIO101', 3, 'Structure and function of cells', 5),
('English Literature', 'ENG101', 3, 'Survey of English literature', 6),
('Business Management', 'BUS101', 3, 'Principles of business management', 7);

-- Insert Schedule
INSERT INTO schedule (subject_id, teacher_id, classroom_id, day_of_week, start_time, end_time) VALUES
(1, 1, 1, 'Monday', '09:00:00', '10:30:00'),
(2, 2, 1, 'Monday', '11:00:00', '12:30:00'),
(3, 1, 2, 'Tuesday', '09:00:00', '10:30:00'),
(4, 2, 2, 'Tuesday', '14:00:00', '15:30:00'),
(5, 3, 3, 'Wednesday', '09:00:00', '10:30:00'),
(6, 3, 4, 'Wednesday', '14:00:00', '15:30:00'),
(7, 3, 3, 'Thursday', '11:00:00', '12:30:00'),
(8, 4, 5, 'Friday', '09:00:00', '10:30:00'),
(9, 4, 6, 'Friday', '14:00:00', '15:30:00'),
(10, 5, 7, 'Monday', '14:00:00', '15:30:00'),
(11, 6, 9, 'Tuesday', '11:00:00', '12:30:00'),
(12, 7, 11, 'Wednesday', '11:00:00', '12:30:00'),
(13, 8, 12, 'Thursday', '09:00:00', '10:30:00');

-- Insert Enrollment
INSERT INTO enrollment (student_id, subject_id) VALUES
(1, 1), (1, 2), (1, 3), (1, 5),
(2, 1), (2, 2), (2, 4), (2, 5),
(3, 5), (3, 6), (3, 7),
(4, 8), (4, 9),
(5, 10),
(6, 11),
(7, 1), (7, 3), (7, 4),
(8, 5), (8, 6), (8, 7),
(9, 12),
(10, 13);

-- Insert Attendance
INSERT INTO attendance (student_id, subject_id, schedule_id, date, status) VALUES
(1, 1, 1, '2024-01-15', 'Present'),
(1, 2, 2, '2024-01-15', 'Present'),
(1, 3, 3, '2024-01-16', 'Absent'),
(1, 1, 1, '2024-01-22', 'Late'),
(1, 5, 5, '2024-01-17', 'Present'),
(2, 1, 1, '2024-01-15', 'Present'),
(2, 2, 2, '2024-01-15', 'Absent'),
(2, 4, 4, '2024-01-16', 'Present'),
(3, 5, 5, '2024-01-17', 'Present'),
(3, 6, 6, '2024-01-17', 'Present'),
(4, 8, 8, '2024-01-19', 'Present'),
(5, 10, 10, '2024-01-15', 'Present'),
(6, 11, 11, '2024-01-16', 'Present'),
(7, 1, 1, '2024-01-15', 'Present'),
(8, 5, 5, '2024-01-17', 'Late'),
(9, 12, 12, '2024-01-17', 'Present'),
(10, 13, 13, '2024-01-18', 'Present');

-- Insert Grades
INSERT INTO grades (student_id, subject_id, attendance_id, grade, grade_type) VALUES
(1, 1, 1, 85.5, 'Midterm'),
(1, 2, 2, 92.0, 'Final'),
(1, 3, 3, 78.5, 'Assignment'),
(1, 5, 5, 88.0, 'Quiz'),
(2, 1, 6, 91.5, 'Midterm'),
(2, 2, 7, 76.0, 'Assignment'),
(2, 4, 8, 89.0, 'Project'),
(3, 5, 9, 94.5, 'Final'),
(3, 6, 10, 87.0, 'Midterm'),
(4, 8, 11, 82.5, 'Assignment'),
(5, 10, 12, 90.0, 'Final'),
(6, 11, 13, 86.5, 'Quiz'),
(7, 1, 14, 79.0, 'Assignment'),
(8, 5, 15, 93.5, 'Project'),
(9, 12, 16, 88.5, 'Midterm'),
(10, 13, 17, 91.0, 'Final');

-- Insert Fees
INSERT INTO fees (student_id, amount, fee_type, due_date, status, paid_date, payment_method) VALUES
(1, 2500.00, 'Tuition', '2024-01-15', 'Paid', '2024-01-10', 'Bank Transfer'),
(1, 2500.00, 'Tuition', '2024-04-15', 'Unpaid', NULL, NULL),
(1, 500.00, 'Lab', '2024-02-01', 'Paid', '2024-01-25', 'Card'),
(2, 2500.00, 'Tuition', '2024-01-15', 'Paid', '2024-01-12', 'Online'),
(2, 2500.00, 'Tuition', '2024-04-15', 'Unpaid', NULL, NULL),
(2, 300.00, 'Library', '2024-03-01', 'Overdue', NULL, NULL),
(3, 2500.00, 'Tuition', '2024-01-15', 'Paid', '2024-01-08', 'Cash'),
(3, 400.00, 'Sports', '2024-02-15', 'Unpaid', NULL, NULL),
(4, 2500.00, 'Tuition', '2024-01-15', 'Paid', '2024-01-14', 'Bank Transfer'),
(5, 2500.00, 'Tuition', '2024-01-15', 'Overdue', NULL, NULL),
(6, 2500.00, 'Tuition', '2024-01-15', 'Paid', '2024-01-11', 'Online'),
(7, 2500.00, 'Tuition', '2024-01-15', 'Unpaid', NULL, NULL),
(8, 2500.00, 'Tuition', '2024-01-15', 'Paid', '2024-01-13', 'Card'),
(9, 2500.00, 'Tuition', '2024-01-15', 'Unpaid', NULL, NULL),
(10, 2500.00, 'Tuition', '2024-01-15', 'Paid', '2024-01-09', 'Bank Transfer');

-- Insert Users (passwords are hashed for 'password')
INSERT INTO users (username, password, role, student_id, teacher_id) VALUES
('admin', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', NULL, NULL),
('john.doe', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 1, NULL),
('jane.smith', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 2, NULL),
('mike.johnson', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 3, NULL),
('sarah.williams', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student', 4, NULL),
('dr.wilson', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'teacher', NULL, 1),
('prof.brown', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'teacher', NULL, 2);